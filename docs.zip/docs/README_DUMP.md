# Step 1 — dump your muddy project's assets

File: `SquadAI_DumpProjectAssets.py` (read-only, changes nothing).

1. Open the **other (muddy) project** in UE 5.7.
2. Enable **Python Editor Script Plugin** (Edit > Plugins), restart if asked.
3. Save the script to e.g. `C:\dumps\SquadAI_DumpProjectAssets.py`.
4. Output Log > switch `Cmd` dropdown to `Python`, run:
   `exec(open(r"C:\dumps\SquadAI_DumpProjectAssets.py").read())`
5. Result: `<Project>/Saved/AssetDump/ProjectAssetDump.txt` (path printed as `[DUMP] WROTE ...`).

Progress prints every 200 assets. Big libraries (Megascans etc.) can take a few minutes.

If the txt is too huge to upload, re-run with either:
- `SCAN_PATHS = ["/Game/<folder with the trench/field props>"]`, or
- `DEEP_LOAD = False` for a fast index first (then we deep-dump only the folders we need).

## What it records
- **Static meshes**: LOD count, tris/verts per LOD, bounds + real size in cm, UV channels, lightmap settings, Nanite on/off, collision prims + complexity, every material slot (name + assigned material), sockets.
- **Skeletal meshes**: skeleton, bounds, material slots.
- **Materials**: domain, blend mode, shading model, two-sided, used-with-ISM/Nanite flags, all used textures, every scalar/vector/texture/switch parameter with defaults.
- **Material instances**: parent, base-property overrides, each parameter default vs instance override.
- **Textures**: resolution, compression, sRGB, LOD group, mip gen, tiling, source file.
- Everything else: class, package, asset-registry tags, and `/Game` dependency list.

## Why those fields (what step 2 needs)
The trench dresser `ATrenchDetailSplineActor` has:
- 6 optional mesh slots: `CustomDuckboardMesh, CustomRevetmentMesh, CustomBarrelMesh, CustomAmmoCanMesh, CustomStakeMesh, CustomTarpMesh` (engine Cube/Cylinder/Plane/Sphere otherwise) — so I need **real cm sizes, pivots/bounds, tri counts and collision** to pick and scale replacements.
- 10 material slots auto-filled from `/Game/SquadAI/TrenchMaterials`: `M_TrenchWood, M_TrenchMetal, M_TrenchCanvas, M_TrenchEarth, M_TrenchScorch, M_TrenchCorrugated, M_TrenchDrum, M_TrenchAmmoCan, M_TrenchRug, M_TrenchNetting`.
- It tints via a **dynamic material instance** setting vector params named `Color / BaseColor / Tint / BaseColorTint / Albedo / Colour`, and uses HISMs — so candidate materials must expose one of those param names and be **Used with Instanced Static Meshes**. That's exactly why the dump lists parameter names and the ISM flag.

Send me `ProjectAssetDump.txt` and I'll write step 2: a script that picks/copies the right muddy meshes + materials into the trench builder's slots.
