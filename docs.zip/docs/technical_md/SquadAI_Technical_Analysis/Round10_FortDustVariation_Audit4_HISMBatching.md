# SquadAI — Round 10 — All Three Tracks

## Track A — Remaining generator variation (S6-Q, S6-D)

**QuickFortificationSpawnerActor** (h+cpp) — was the worst offender: dead-straight
bag rank, NO ground traces at all (floated on slopes), single tier, no flanks.
Now:
- REAL FIX (S6-Q): MG/ammo/medic/bag spawns all ground-trace (`FortGroundSnap`).
- Crescent arc formation: bag line bows forward (~130° span, middle protrudes
  ~1.3m, each bag angled tangent) — real MG-nest shape.
- Seeded jitter (pos/angle/scale) via `FortSeed`+`bSeededVariation`, 40% centre
  double-tier, backward-bending flank-return bags at both ends, one warm DMI
  batch tone per build. All flags OFF → old straight rank byte-identical.

**AtmosphericDustScatterer** (h+cpp) — ditch fog volumes spawned at fixed scale,
zero rotation (one flat sheet). S6-D: per-volume stable seed (position xor
`DitchVariationSeed`) drives ±15–20% scale + random yaw; shape persists across
cull/respawn cycles (no popping).

## Track B — Structural audit of the last four files (2575 lines)

| File | Verdict |
|---|---|
| CoverSystemSubsystem (567) | CLEAN — async trace pipeline, budgeted queues, self-gating `IsTickable`, weak-ptr queriers, null-checked controllers |
| SquadAIAudioSubsystem (886) | CLEAN — WorldSubsystem lifecycle, all timers cleared in Deinitialize, voiceline cooldown ladder, defensive `IsValid()` on deferred audio fires |
| SquadAIAdapterComponent (743) | CLEAN — tick disabled; reflection bridge is event-driven |
| EnemyFireteamSubsystem (379) | ONE GAP — `CompactTeam` self-heals memberships, but pooled enemy reuse left stale `bInEnemyFireteam/FireteamRole/FireteamMoveGoal` on the controller between prune and next wave registration. FIXED as **S6-A1**: `ResetCombatState()` (batch-2) now mirrors the full `OnUnPossess` fireteam reset |

## Track C — Village V2 props HISM batching (S7-H, optional, default ON)

Every V2 prop pass previously spawned `AStaticMeshActor`s (~40–60 actors/village).
New: `SpawnVillageProp` gained a batch-kind arg (1 Road / 2 Scorch / 3 WallProps /
4 WoodProps) and, when `ADestroyedVillageCompoundActor::bBatchV2PropsIntoHISM`,
routes into lazily-created shared HISM components (`HISM_V2_Road/Scorch/Wall/Wood`)
— one DMI per batch instead of per prop, instanced rendering instead of actors.
- Courtyard walls, gate posts/lintels, poles, stumps, shafts, well frame, beams,
  buckets, crossbars → batched.
- Road/alley/plaza ribbons (one shared `RoadTint` DMI on the batch) and scorch
  patches (one `ScorchTint` DMI) → batched.
- Lights stay actors (they're lights); tinted-per-prop pieces would only fall back
  if batching is disabled (full actor path preserved and still tinted).
- `ClearVillage` now also clears `HISM_V2_*` instances — rebuild-safe.
- Collision: Road/Scorch batches NoCollision, Wall/Wood BlockAllDynamic — matches
  the previous per-actor profiles exactly.

## Verification
All 7 touched files braces/parens balanced; 15 batch-routing markers; 3 fort
PlaceBag sites; S6-A1 mirrors present; audit files read in full.

_Delta: `SoldierAIController.cpp`, `QuickFortificationSpawnerActor.{h,cpp}`,
`AtmosphericDustScatterer.{h,cpp}`, `DestroyedVillageCompoundActor.{h,cpp}`._
