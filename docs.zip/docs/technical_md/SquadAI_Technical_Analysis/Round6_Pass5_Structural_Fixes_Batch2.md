# SquadAI Module — Round 6, Pass 5 (Structural), Batch 2

Second pass-5 batch: **3 structural items fixed** (pool reuse, HUD cache staleness, WP ownership). One item scoped down, one deferred to batch 3 (save-compat design decisionneeded).

## ✅ #6 — HUD chain cache never revalidated after completion (QuestNativeHUD.cpp)

`FindQuestChain()` cached the FIRST chain found (or null) and never looked again: if chains were authoritative (a level with zone-less chain(s)), HUD header/progress stayed stuck on the last completed chain — or on "no objective" — forever.

**Fix** (S5-11a): keep CachedChain only while `!bIsCompleted`; on completion drop it and re-resolve `AQuestChain::FindPreferred`. Preserves smooth zone-ordered chains (linear fallback still uses `!DidItem` gates).

## ✅ #4 — Pooled enemies wake with stale brains / sleep with a live lifespan (EnemyPool.cpp + SoldierAIController.{h,cpp})

Three defects at the sleep/wake boundary:

| Defect | Fix |
|---|---|
| Corpse `SetLifeSpan(10s)` kept ticking in the pool → pooled pawn destroyed mid-wait, entry became a silent leak (prewarm wasted, pool shrank over a session) | **S5-13**: `SetLifeSpan(0.f)` on sleep |
| Hours of AI state survived reuse → pooled enemy "remembers" old hostiles, walks to the PREVIOUS objective, zones fights from stale caches | **S5-12**: new `ASoldierAIController::ResetCombatState()` clears Memory, zone/chain/LOS caches, fire-team threat, pathing + hesitation timers, sprint tracker; stops movement and clears focus. Called on wake AND defensively on sleep. Only clears members actually declared in the header (compile-verified against it). |
| (existing gap) snapshot restore didn't reset counts | existing: `ResetSoldierStateSnapshot` + health/armor visual resets already in place |

Behavior unchanged for non-pooled enemies.

## ✅ #11 (bounded) — World Partition ownership for procedural children

World Partition places runtime- and streamedactors under their **owner**; children spawned with default `Owner == nullptr` can fail placement or outlive their streamed cell.

- **S5-14a**: `ADestroyedVillageCompoundActor::BuildCompound` — one shared `SpawnParams` now sets `Owner = this` → covers buildings, walls, sandbags, craters, barrels, cables, catwalks, gate share, cover-gen, encounter manager, and the 9 new detail/ambience passes.
- **S5-14b**: `ADestroyedBuildingActor` — all 7 internal spawn sites set `SpawnParams.Owner = this`.
- AutoSpawnZone village/spawner deferred spawns already pass `this` as owner (√ via batch 1 signatures).
- **Intentionally untouched**: generic `AQuestZone` utility spawners and gameplay-actor spawns whose lifetime should track zone semantics rather than WP cells (ownership there is a per-system design choice). Remaining spawns from quest actors ignore WP impact deliberately.

## Verification (mechanical)

- All 6 touched files: braces/parens balanced after string/comment stripping.
- `ResetCombatState()` referenced 2× in pool (S5-12 sleeps + wakes) and clears only members present in the public header (machine-checked name-by-name); no phantom `PrimaryThreatCache/CacheClearCount` left.
- `SpawnParams.Owner = this;` exactly 7× in building actor (one per spawn site), once in village shared params.

## Still open / deferred

1. **#5 — Save/restore orders vs stable mission identity** (batch 3): save games store wrapper/parent info as transient pointers and restore behavior depends on spawn ORDER. Proper fix needs save-format decisions (version bump vs. back-compat migration). Recommendation: batch 3 = save-version bump + persistent-guid for chains/zones. Needs your call on whether old saves must load.

_Batch 2 files (deltas only, on top of batch 1): `Private/HUD/QuestNativeHUD.cpp`, `Public/AI/SoldierAIController.h`, `Private/AI/SoldierAIController.cpp`, `Private/Quest/EnemyPool.cpp`, `Private/Environment/DestroyedVillageCompoundActor.cpp`, `Private/Environment/DestroyedBuildingActor.cpp`._
