# SquadAI — Pass 6 Sweep + Batch 4 (2 fixes)

## Pass-6 sweep coverage (verified clean, no changes)
- Delegate bindings (11 files): bind-once or Remove→Add; no double-fire paths.
- Pool↔significance/registry re-registration: `AddUnique`-based, dedupe-safe.
- Container mutation inside range-loops: zero hits tree-wide.
- Division guards / CDO GetWorld derefs / editor-only API gating: clean.
- Ammo truth source: pack fire logic (reflection); native CurrentClipAmmo is a mirror — design note only.
- Subsystem Deinitialize timer omissions: benign on modern UE (dead-object callbacks skipped with warning).

## Batch-4 fixes

### S5-15b — Stable save identity upgraded to ActorGuid backing (SaveLoadSubsystem.cpp)
Batch-3's minted `ChainSaveId` only persists for editor-re-saved placed chains (cooked builds skip OnConstruction reruns); BeginPlay minting gives random session IDs. Now:
- **Save**: `SavedChainId = ChainSaveId.IsValid() ? ChainSaveId : GetActorGuid()` — `ActorGuid` is persistent for EVERY placed actor in every level (cooked included), editor regenerates it on duplicate.
- **Restore**: GUID-match checks `ChainSaveId == saved || GetActorGuid() == saved`.
- Effect: identity matching works immediately on all placed chains with zero level re-saving; `ChainSaveId` remains a designer override; name-match + legacy order fallbacks unchanged.

### S5-16 — Packaged-build hard-stop for editor auto-setup (SquadAIAutoSetupManager.cpp)
`bRunOnBeginPlay && !bRunInEditorOnly` previously ran the 1100-line level/asset mutation routine in packaged builds if a level flipped the flags. The `RunEditorAutoSetup()` call site is now `#if WITH_EDITOR`-gated with a clear warning in runtime builds. The F-C3 runtime FX-manager wiring still executes in ALL builds (not gated — required for packaged FX defaults).

## Verification
Both touched files: braces/parens balanced after string/comment stripping; markers S5-15b (2×) and S5-16 present; `GetActorGuid()` is public AActor API (UE 5.x).

_Delta: `Private/SaveSystem/SquadAISaveLoadSubsystem.cpp`, `Private/Actors/SquadAIAutoSetupManager.cpp` on top of batches 1–3._
