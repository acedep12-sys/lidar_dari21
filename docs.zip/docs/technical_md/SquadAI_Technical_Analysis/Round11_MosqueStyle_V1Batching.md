# SquadAI — Round 11 — Mosque Style + Complete Village Batching

## S6-M — New building style: VillageMosque (enum appended, serialization-safe)

`EBuildingStyle::VillageMosque` + `ConstructVillageMosque`:
- Prayer hall: qibla wall, two walls with high window slits, archway front door,
  mihrab alcove, charred rafters.
- Flat roof: 75% intact slab / 25% shell-blasted front corner (two partial slabs
  leave a notch).
- Buttressed square minaret beside the hall (mirrorable side): solid shaft, 4 base
  buttresses, muezzin balcony with battle-broken parapet stubs, occasional shed
  wooden beams + base rubble.
- Participates in the S6-B variation: mirror + dimension jitter + rafter seeds.
- Village rotation: `bIncludeMosque` (default ON) → 6-style rotation with the
  mosque at slot 4 (appears even at default BuildingCount 5). OFF → original
  5-style cycle, byte-identical composition.

## S7-H2 — V1 village passes join the batch system

The pre-V2 passes (built before the batch helper existed) converted to
`SpawnVillageProp` with four new batch kinds:
5 `HISM_V2_Rubble` (blocking mounds), 6 `HISM_V2_Sandbag` (barricades + perimeter
arcs), 7 `HISM_V2_RubbleNC`, 8 `HISM_V2_WoodNC` (walkover mounds + cart planks,
NoCollision). Converted sites (7): plaza barricades, perimeter walls, catwalks,
well ring, rubble mounds (collision-aware split), street clutter (collision-aware
split), perimeter sandbag arcs. Explosive barrels, monument column/cap (dynamic
material choice), buildings, encounter and cover-gen stay real actors.

Impact: a full village previously spawned roughly 70–110 individual
AStaticMeshActors; with batching it now produces ~10 actors + up to 8 shared HISM
components (+2 lights). One DMI per batch instead of one per tinted prop.

## Lift-correctness fixes
Two conversion sites originally re-snap-corrected manually: plaza barricades
(terrain lift +20 preserved) and well ring (+40) — both now pass their explicit
ZLift so the batched positions match the pre-conversion transforms exactly.

## Verification
All 4 touched files braces/parens balanced; 7 S7-H2 markers + 15 S7-H markers;
21 helper call sites; batch-name table exhaustive; mosque enum/decl/case/wiring
machine-checked.

_Delta: `DestroyedBuildingActor.{h,cpp}`, `DestroyedVillageCompoundActor.{h,cpp}`._
