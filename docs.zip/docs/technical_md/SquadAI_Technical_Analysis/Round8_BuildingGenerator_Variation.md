# SquadAI — Round 8 — DestroyedBuildingActor Seeded Variation (S6-B)

## The finding
`GenerationSeed` was **dead**: all five construct blueprints (TwoStoryRuins,
Mudbrick, WalledCourtyard, MarketStalls, OutpostTower) consumed zero Stream draws —
every building of a style was pixel-identical. The biggest single realism defect in
the village pipeline.

## Fixes (2 files; zero new assets)

| Marker | Change |
|---|---|
| S6-B1 | **Seeded mirror** — each construct coin-flips its `Right` axis: windows/breaches/doors swap sides; silhouette variety ×2 with zero alignment risk (all placements share the same axis set) |
| S6-B2 | **Per-build variation state** — `PieceStream` (seeded from GenerationSeed*31+7) + `CurrentToneOffset` re-derived every `BuildBuilding`; `ToneCache` reset |
| S6-B4 | **Whole-building warm tone via ONE runtime DMI per material per building** (`GetTonedMaterial`, cached in `ToneCache`) — all 21 `SetMaterial` sites (13 HISM + 8 actor-path) now route through it; silent no-op on colour-param-less materials; mudbrick plaster varies subtly building-to-building |
| S6-B5 | **Per-piece angle jitter** in `SpawnWallSegment` (±`PieceAngleJitterDeg` = 0.6° default, seeded) applied to BOTH HISM instances and spawned actors — the CAD-perfect 90° look is gone |
| S6-B6 + dims | **Seeded dimension jitter** per blueprint (±4–8% on widths/depths/heights — proportional, so joints stay tight) and seeded rafter count (was constant 7) |

New tunables (header, *Building Variation*): `bSeededVariation` (default ON),
`ToneJitter` (0.05), `PieceAngleJitterDeg` (0.6). All OFF-safe: jitter factor
fall-through reproduces the old exact constants when disabled.

## Compile-safety details
- Header gains `#include "Math/RandomStream.h"` (FRandomStream member) and a
  `class UMaterialInstanceDynamic;` forward declaration (TObjectPtr member).
- DMIs are created per build via `UMaterialInstanceDynamic::Create(Base, this)` —
  runtime objects, never assets.
- All previous fix lines (S5-14 ownership, etc.) untouched; balance + marker
  checks PASS tree-wide.

_Delta on batches 1–4 + Round 7: `DestroyedBuildingActor.{h,cpp}`._
