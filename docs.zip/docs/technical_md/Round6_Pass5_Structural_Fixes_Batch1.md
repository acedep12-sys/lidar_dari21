# Round 6 — Pass 5 structural fixes, batch 1 (mission/spawner/fire/barrage)

Continues the deferred "Pass 5 structural work" from `PASS5_MISSIONS_OPEN_WORLD.md` /
`PROJECT_STUDY_NOTES.md` §Pass 5. Seven findings fixed, all surgical, all inside
`Source/SquadAI`, all UE 5.7-safe (only pre-existing module APIs + standard engine calls).

| # | Finding (from Pass 5) | Fix |
|---|---|---|
| 1 | `AAutoSpawnZone` configured zone/spawner children **after** their `BeginPlay` → tags never registered, default box shape, spawner never auto-started | Deferred spawning for both (`SpawnActorDeferred` → configure → `UGameplayStatics::FinishSpawningActor`) so `BeginPlay` sees full config (`AutoSpawnZone.cpp`) |
| 2 | `AWaveSpawner::StopWaves()` cleared timers only — old live enemies kept this spawner's death binding and corrupted the NEW run; empty/malformed waves stalled forever | `StopWaves(bool bReleaseLiveEnemies)` severs death bindings + optionally releases leftovers to the pool; resets board counters; `StartWaves` retries use `true`. Empty/no-batch/no-class waves fast-forward to `OnWaveCleared` (`WaveSpawner.cpp/h`, 3 MissionZone call sites) |
| 3 | Legacy `AEnemyWaveSpawner` stopped health polling at final spawn — late pack deaths froze `AliveEnemyCount` and stalled Clear | `PollLatePackDeaths()` 1.5 s loop after `OnSpawnerAllWavesDone` until zero alive (`EnemyWaveSpawner.cpp/h`) |
| 7a | `STTask_EnemyMission` hunted the player with ZERO perception within 12,000 cm before mission movement | Removed the unconditional player-fallback branch; perceived threats still hunt, everyone else advances on the active mission zone (`STTask_EnemyMission.cpp`) |
| 7b | mission-pathing fallback used a function-static `AQuestZone` shared across controllers/worlds | Per-controller `CachedFallbackQuestZone` member with world check (`SoldierAIController.cpp/h`) |
| 8 | `ASceneDecorator` fire couldn't damage a native player (native `UHealthComponent` matched by name then routed only through missing pack reflection fns); overlapping fires raced non-refcounted burn booleans | `ApplyFireDamageToActor` calls `NativeHC->ApplyExternalDamage(...)` FIRST (pack path only when no native comp); burn overlay/status now `GBurnVisualRefCount` reference counting in `Enter/LeaveBurnVisualState` (`SceneDecorator.cpp/h`) |
| 9 | `APathExplosionBarrage` damaged players twice (direct + registry pass); generic path combined `UGameplayStatics::ApplyDamage` with direct reflected HP subtraction | Registry pass skips the player pawn; pack `BPC_Health` carriers take reflection-only damage, otherwise engine-only (`PathExplosionBarrage.cpp`) |
| 10 | Sandstorm manual Trigger/Stop stalled with auto-cycle disabled (timer never decremented) | Phase timer runs for any active phase; auto-cycle gating only blocks storm *creation* from Clear (`SandstormWeatherDirector.cpp`) |

**Verified:** braces/parens balanced on all 13 touched files; markers present; no new engine APIs
deferred-spawn is the canonical 5.7 pattern.

## Remaining Pass 5 items (batch 2 candidates)
- Pooling wake/release deep reset (native death lifespan, pack state, AI commands/memory/cover/timers).
- Save-game stable chain/mission identity + restore-safe spawner cleanup.
- `AQuestNativeHUD` single-chain caching (later mission authorities invisible).
- World-Partition ownership/EndPlay for procedural children; building/trench cover creation;
  barrel physics impulse/AI suppression (needs design decisions first).
