# Pass 4 — AI Brain, StateTree, Threat Memory, Fireteams, Cover, and AI LOD

Date of static review: 2026-09-21  
Source reviewed: `extracted/source-full/Source/SquadAI/`  
Scope rule: study only; no `Source/SquadAI` files were modified.

## 1. Scope and confidence boundary

This pass traced the native AI/cover loop across:

- `ASoldierAIController`, perception, threat memory, suppression, direct combat, direct enemy movement, direct leader movement, command and adapter presentation paths;
- every native StateTree evaluator and task;
- `UCoverSystemSubsystem`, `FCoverScanner`, reservations, async query lifetime, tactical cover generator, and EQS helpers;
- `USharedThreatMemorySubsystem`, `UEnemyFireteamSubsystem`, and `AEnemyAttackCoordinator`;
- `USoldierRegistrySubsystem` smoke/suppression/spatial queries;
- `UAISignificanceManager` and the LOD fields it drives;
- tactical squad commands, tactical pings, and the SquadAI adapter's move/aim/fire behavior;
- StateTree start/restart/death/pool call sites and cover-release call sites.

The C++ task implementations are now understood. The actual StateTree asset, its state hierarchy, transitions, conditions, bindings, and any Blueprint overrides are host-project Content and are not present in the supplied module archives. Therefore:

- native task behavior can be stated confidently;
- which task is active in the user's real project at any moment cannot be proven from this archive;
- external Blueprint/StateTree logic could consume exposed properties that have no C++ consumer;
- the host asset cannot fix controller-tick movement commands issued after/beside StateTree tasks unless it explicitly disables those native paths.

## 2. Executive conclusion

The current AI is not governed by one brain. It is a stack of overlapping safety nets accumulated around a StateTree:

1. Unreal perception and manual registry polling populate controller memory.
2. StateTree evaluators expose a simplified threat/suppression/health view.
3. StateTree tasks issue movement, cover, aim, and fire operations.
4. The controller tick independently aims, fires, throws grenades, chases enemies, and paths the leader.
5. The fireteam subsystem injects shared threat memory and computes tactical role goals.
6. Tactical commands and pings issue additional one-shot movement/aim/fire operations.
7. The adapter mirrors the most recent aim command into native or pack presentation.
8. Every movement producer ultimately writes to the same `PathFollowingComponent`; the newest request wins.

There is no movement-intent owner, priority, generation number, or cancellation contract. There is also no aim/fire owner: `SetCombatAimTarget`, `TryStartBurstAtCurrentAim`, and `StopCombatPresentation` are shared last-writer operations.

The most consequential result is that enemy cover and fireteam behavior can be calculated correctly and still never control the pawn. While an enemy has any remembered threat, `RunDirectEnemyMovement()` executes before considering its fireteam goal and can overwrite TakeCover/EnemyMission movement with a direct move toward the threat. The direct combat fallback can issue another `MoveToActor` and restarts bursts every second. This makes StateTree, cover, and fireteam logic advisory rather than authoritative.

## 3. Runtime authority map

### 3.1 Movement writers

| Writer | Trigger | Operation | Main conflict |
|---|---|---|---|
| `FSTTask_TakeCover` | StateTree cover state | `MoveToLocation(CoverGoal)` | Direct enemy movement replaces it while threat memory exists |
| `FSTTask_EnemyMission` | Enemy mission state | `MoveToLocation(Goal)` | Threat override uses live target; controller direct movement also writes |
| `FSTTask_LeaderPath` | Leader path state | `UAITask_MoveTo` and direct cover `MoveToLocation` | Controller leader path writes independently |
| `FSTTask_FollowLeader` | Ally follow state | `MoveToLocation(Slot)` / `MoveToActor(Downed)` | Tactical regroup and any following task tick can replace each other |
| Direct combat fallback | Threat, non-hold role, range | `MoveToActor(Threat)` | Can overwrite cover and mission moves |
| Direct enemy movement | Enemy controller tick | threat, fireteam, player, or zone `MoveToLocation` | Threat branch preempts fireteam role goal and cover |
| Direct leader mission path | Leader controller tick | mission `MoveToLocation` | Can replace StateTree combat-cover/path requests |
| Tactical command | One-shot | `MoveToActor(Player)` or async cover request | No persistent command ownership; normal AI immediately resumes |

The adapter's `SetMoveCommand` only stores data. Nothing in `USquadAIAdapterComponent` executes movement. Controller `SetMoveCommand` changes `CurrentGoalLocation`; StateTree/direct leader code must later consume that goal.

### 3.2 Aim/fire writers

- Direct combat fallback: tracks and starts a burst every hard-coded 1.0 seconds.
- `EngageTarget`: aim tracking and one burst per peek/open-ground cycle.
- `FollowLeader`: opportunistic burst every 2.5 seconds.
- `LeaderPath` close-combat branch: sets aim while requesting cover.
- `HoldPosition`: sets aim but does not itself fire.
- Tactical suppress command: sets an investigate-location aim and starts one burst.
- Tactical ping: every nearby ally sets an investigate-location aim, regardless of ping type.

A later `StopCombatPresentation()` clears the shared adapter command and can stop presentation started by another producer. Conversely, direct fallback can restart a burst during `EngageTarget`, despite the task deliberately avoiding per-tick `StartBurst` calls because restarting resets shot count and animation.

## 4. Perception and threat memory

### 4.1 Sense type is lost

`OnPerceptionUpdated` forwards only `Stimulus.WasSuccessfullySensed()` to `UpsertPerceivedHostile`. It does not inspect whether the stimulus was sight, hearing, or damage.

Consequences:

- successful hearing is marked `bCurrentlyVisible=true`;
- successful damage sense is marked visible;
- either can create a new full-confidence (`1.0`) visible memory;
- either can set StateTree `bHasVisibleEnemy=true`;
- a failed hearing/damage stimulus can clear visibility even while sight remains active;
- every existing-memory update, including a failed stimulus, writes the actor's current live location into `LastKnownLocation`.

The manual sight poll can restore sight visibility on a later controller tick, but ordering between sense events, manual polling, and StateTree evaluation can still produce false transitions.

### 4.2 Registry close-range recognition bypasses LOS and smoke

The source defaults are:

- engine sight: 3,500 cm;
- manual combat detection: 15,000 cm;
- close-range override: 1,800 cm;
- direct fallback fire range: 8,000 cm;
- fallback fire enabled.

`PollRegistryForHostiles` marks any hostile inside 1,800 cm visible without calling `HasLineOfSightTo`. Direct fallback and `EngageTarget` also accept `HasLineOfSightTo(...) || distance <= 1,800`.

That workaround avoids face-to-face stalls, but it also bypasses walls, terrain, and tactical smoke for recognition and firing decisions within 18 meters. A physical bullet trace may still hit the wall, but AI will know, aim, reveal itself, spend bursts, and accurately track through smoke. Smoke therefore is not a reliable visual blocker at close range.

### 4.3 Stored memory is scored, but actions use the live actor

`GetPrimaryThreat` scores candidates using `FPerceivedTarget::LastKnownLocation`, but returns only the live actor pointer. Nearly every consumer then calls `Threat->GetActorLocation()`:

- StateTree threat evaluator;
- `TakeCover` threat location;
- `EngageTarget` aim and range;
- `EnemyMission` pursuit;
- direct enemy movement;
- direct fallback;
- fireteam threat aggregation and role geometry;
- follower opportunistic fire.

Thus a remembered, nonvisible target is tracked in real time through the actor pointer. `LastKnownLocation` determines selection but not pursuit/aim location. The StateTree evaluator even names its output `LastKnownEnemyLoc` while assigning the actor's current location.

### 4.4 Memory fields and decay

- `FPerceivedTarget::LastSeenTime` has no writer in this source.
- Visible entries never decay; they continuously copy live actor location.
- Nonvisible entries decay at `MemoryDecayRate` and are removed at zero.
- `GetCurrentlyVisibleHostiles` trusts the memory flag and does not recheck hostility, life, or LOS.
- `GetPrimaryThreat` does recheck hostility/alive/spawn grace.
- Threat distance scoring uses `distanceSquared * 0.001`; at normal combat distances the nearest entry dominates confidence strongly.

### 4.5 Shared-threat subsystem is write-only in native gameplay

New local memories report into `USharedThreatMemorySubsystem`, but no C++ gameplay code calls `GetKnownThreatsForTeam` or `GetBestKnownThreat`. The subsystem's comments promise squad-wide awareness, yet its only readers are its own methods. It is currently a decaying write-only store unless external Blueprint code reads it.

It also reports only when a controller creates a new local memory. Continued sight refreshes do not update shared location/time. For an existing shared record, equal-confidence reports are ignored because update requires strictly higher confidence.

## 5. Fireteams and attack coordination

### 5.1 Fireteam memory can become permanent and omniscient

Every 0.5 seconds, `UEnemyFireteamSubsystem::AssignTeam`:

1. asks every member for `GetPrimaryThreat`;
2. takes the highest-confidence actor;
3. reads that actor's current live location;
4. injects it into every member with confidence `max(0.55, BestConfidence * 0.85)`.

`IngestSharedThreat` always updates `LastKnownLocation` and takes the max of existing and injected confidence. Between 0.5-second assignments, normal memory decays by about 0.1 at default settings; assignment then restores at least 0.55. Once a valid fireteam contact exists, the group can self-refresh it indefinitely without any new perception. It also refreshes the target's live location through walls.

This is independent of `USharedThreatMemorySubsystem`; it is an internal feedback loop among controller memories.

### 5.2 Tactical role goals are preempted during contact

The subsystem computes useful-looking goals for Lead, Suppress, FlankLeft, FlankRight, and Assault. However:

- direct enemy movement checks remembered threat first;
- only when there is no qualifying threat does it use `FireteamMoveGoal`;
- `EnemyMission` also replaces its initial effective goal with the live threat location;
- the fireteam's injected confidence floor keeps the threat qualifying.

Therefore contact is exactly when role movement is least likely to execute. Suppress/flank roles affect the direct fallback's preferred firing range, but the separate direct enemy movement still pushes them toward a generic 550 cm stopping behavior.

### 5.3 Attack coordinator is not a native runtime authority

`AEnemyAttackCoordinator` writes `AEnemySoldier::AssignedAttackPoint` and `CurrentPhase`, but there are no C++ readers of either field outside the coordinator. `Aggression` and `AttackPointLeash` likewise have no native behavior reader.

`AAutoSpawnZone` can spawn and link a coordinator, and `AWaveSpawner` can add enemies, but no C++ caller invokes `BeginAttack`. As native code stands, auto-spawned coordinators remain Idle. A host Blueprint may call `BeginAttack` or bind pawn properties directly in its StateTree, but that dependency is external and unverified.

## 6. StateTree lifecycle and asset dependency

### 6.1 Asset assignment is external

The controller creates `UStateTreeAIComponent` and starts/restarts it on possession, revive, pool wake, and mission recovery. No C++ code assigns a StateTree asset. The controller's direct behavior is therefore not just a safety net for a stalled tree; it is the only native behavior if the host Blueprint component has no asset.

Starting logic does not prove that a valid asset and bindings exist. The 2-second safety timer retries `StartLogic`, but it cannot supply an asset.

### 6.2 StateTree restart and pool state

Pool sleep/wake stops/restarts the StateTree but does not reset controller memory, suppression, `bHasCover`, pending query flags/results, active cover goal, aim/move commands, LOS cache, direct-combat timers, or mission-path timers. This extends the Pass 3 pool finding: a reacquired pawn can wake with an old target, stale cover state, or a callback from its previous life.

The async cover callback captures a weak controller, not a request generation or pawn identity. A sleeping/unpossessed-but-still-valid controller can receive a late result and carry it into reuse.

### 6.3 Significance does not explicitly throttle StateTree

`UAISignificanceManager` changes controller, pawn, character-movement, mesh, and aim behavior, but never changes `StateTreeComp->PrimaryComponentTick`. Unreal actor components have their own tick functions, so the intended controller LOD does not statically guarantee that StateTree evaluators/tasks are reduced to the controller's tick rate. This needs PIE profiling/engine-version confirmation.

## 7. Native StateTree task findings

### 7.1 `TakeCover`

Positive behavior:

- resumes controller-level active cover goals across task re-entry;
- debounces repeated async requests;
- transfers successful reservations to controller ownership when moving/engaging;
- uses fallback bounds rather than freezing forever;
- smoothly rotates after real-cover arrival;
- times out failed movement after eight seconds.

Problems:

1. **Reservation failure is ignored.** If `ReserveCover` returns false, the task still assigns that cover, marks it as real, and moves to it. Two soldiers can converge on a point despite the reservation system.
2. **Direct enemy movement ignores the active cover goal.** It can replace the cover `MoveTo`; TakeCover sees that path following is still Moving and does not reissue its own request until timeout.
3. `AcceptanceRadius` defaults to 600 cm, large enough to call a pawn arrived several meters from the generated point.
4. The fallback and query threat position is the live actor location even for memory-only contacts.
5. Fallback natural-cover traces do not ignore the threat actor and accept any blocking actor/geometry; dynamic actors or the trace's starting actor can be mistaken for protection.
6. `LeaderPath` can create an active goal flagged as real cover without reserving it or initializing `CurrentCover`; a later TakeCover re-entry can resume that goal and mark cover using default/stale metadata.
7. Query result/pending state has no request ID and is not cleared comprehensively on reuse.

### 7.2 `EngageTarget`

- The effective range is `max(task MaxEngageRange, global MaxEngageRange)`, so the task asset cannot lower the source default below 8,000 cm.
- It uses the same 1,800 cm no-LOS override as direct combat.
- `ShotsPerBurst` is exposed but never read; actual burst size is owned by `UWeaponComponent`.
- `MaxCycles` is checked only in the real-cover Cooldown branch. Open-ground engagement increments cycles but never exits because of the cycle count; it runs until threat/range/LOS changes.
- Direct fallback can start additional bursts every second and reset weapon burst state while Engage is active.
- In pack-safe mode, `StopBurstAndClearAim` stops visual flags/aim but does not call native `WeaponComponent->StopFiring`; gameplay shots already queued can continue after the pawn ducks behind cover.
- Adapter pack `IsBurstFiring` uses a sticky presentation flag rather than native shot completion, so it does not describe actual burst state until an explicit stop.

### 7.3 `FollowLeader`

- `FSTTask_FollowLeaderData::MoveTask` is declared/cancelled but never assigned; actual moves use the controller directly.
- Exit does not stop the path-following request.
- A re-path clears soldier cover presentation but does not clear controller `bHasCover` or release its held reservation.
- Opportunistic firing requires confidence but not current visibility, LOS, or range and aims at the live actor location.
- Revive selection uses first registry order rather than nearest/best casualty; multiple allies can converge and stack progress.
- At revive range it crouches and applies progress but does not explicitly stop an earlier movement request.

### 7.4 `LeaderPath`

- Native direct leader pathing runs in parallel with this task.
- Combat-cover results are not reserved and are not copied into `CurrentCover`/soldier cover metadata.
- On arrival it deliberately sets `bHasCover=false` and clears cover, so the cover system is used as a reposition-point generator rather than a held cover contract.
- If the task enters while the controller already has an active cover goal, instance `CombatCoverGoal` can still be zero; distance is then measured to world origin and the branch can remain Running.
- An active goal created here is marked `bUsesRealCover=true`; TakeCover can later inherit it as though fully initialized.
- Outside combat it clears soldier cover but not controller `bHasCover` or held reservation.

### 7.5 `EnemyMission`

- Threat pursuit is limited to 12,000 cm, an improvement over the old unlimited behavior.
- It still uses the threat actor's live location when memory-only.
- If there is no memory/effective goal, it directly discovers and pursues the player inside 12,000 cm without perception.
- Exit clears only task bookkeeping; it does not stop movement.
- Fireteam role goal is not directly consumed by this task.

### 7.6 `HoldPosition`

`HoldPosition` does not call `StopMovement` on enter or tick. It can inherit and continue the prior task's movement while named “Hold Position.” It aims at any primary memory actor but does not fire; direct fallback is what normally produces shooting.

### 7.7 Evaluators

- Threat evaluator writes live actor position to `LastKnownEnemyLoc`.
- Its visible flag inherits the sense-type bug.
- When no threat exists, it clears `bHasVisibleEnemy` but leaves the prior location intact.
- Health evaluator has no `else` assignment when controller lookup fails, so instance health can remain stale.

## 8. Cover scanner and query pipeline

### 8.1 Cost model

Source defaults produce:

- 6 × 6 floor samples per chunk;
- 8 directions × 5 heights per sample;
- **1,440 async visibility traces per chunk**;
- one full chunk started per frame;
- configured trace budget: 96, used only for warning/tracking, not enforcement.

A normal 3,500 cm search spans up to roughly 8 × 8 = 64 XY chunks, or approximately **92,160 async traces** plus 2,304 synchronous ground traces for an uncached query footprint. Queries may resolve partially after 0.6 seconds, but the remaining scan queue is not cancelled when the query resolves and continues filling the cache.

The source reduced maximum chunk starts from two to one per frame, but each started chunk still exceeds the configured budget by 15×. This remains a first-contact/open-world hitch risk.

### 8.2 Generated point quality

- Scanner probes can hit any object on `ECC_Visibility`; the querying pawn, other soldiers, and movable actors are not ignored.
- `MinCoverThickness` is cached but never used; a thin pole or character can qualify.
- `HitActors` is recorded but never used to reject dynamic/invalid cover.
- The best obstacle may be up to 450 cm away, but the generated stand point is always floor sample minus a fixed 70 cm. It ignores actual hit distance.
- The 70 cm offset point is not reprojected to NavMesh.
- Query scoring treats real body protection and peek shot as bonuses, not hard requirements. Any classified point with a positive base score can win even if both validation checks fail.
- `ResolveSingleQuery` does not call `FCoverPoint::IsValid`; an arc-score-zero point can still participate.
- Protection/peek traces receive only a threat location, not actor identity, so they cannot ignore the threat actor and can count unrelated dynamic blockers.
- Candidate scoring uses straight-line distance, not navigation path cost/reachability.
- Different normals at nearly the same floor sample can evade the 25 cm/similar-normal deduplication and create occupancy conflicts.

Combined with TakeCover's 600 cm acceptance, a pawn can be marked in real cover while physically far from the obstacle.

### 8.3 XY-only cache

`ChunkSizeZ` exists in tuning but is unused. Cache keys are `FIntPoint`; one XY chunk stores one altitude band's samples. The most recent request's Z reference wins before scan. This cannot correctly represent stacked interiors, bridges, cliffs, trenches at different elevations, or World Partition cells sharing XY at different heights.

### 8.4 Rescan/invalidation and reservation identity

On revalidation, `KickChunkScan` empties all points and restarts local IDs at zero. Existing occupants/controllers are not notified. This causes two related failures:

1. occupied cover becomes immediately available to new queries because its reservation vanished;
2. the old controller still holds `(ChunkKey, LocalID)`. A later `ReleaseCover` clears that ID without checking the claimer, so it can release a different soldier's newly assigned reservation after IDs are reused.

`InvalidateArea` similarly removes chunks without invalidating held controller tokens. It also does not remove/cancel pending sample indices or async trace contexts. Invalidating/restarting a chunk while traces are in flight can reuse the same sample keys and mix old callbacks into new sample storage.

### 8.5 Async lifetime

- Pending queries do not drop invalid queriers early.
- A destroyed/sleeping actor's query can continue scanning until timeout and invoke its callback.
- Callback identity has no monotonically increasing request generation.
- `FCoverScanner` binds async trace delegates with `BindRaw(this)`.
- Subsystem deinitialization clears subsystem maps but has no scanner reset/cancellation for `PendingTraceMap`/`InFlightSamples`.

Whether world teardown cancels every callback before subsystem destruction is engine-dependent; the raw delegate makes this a lifecycle risk worth fixing rather than assuming.

### 8.6 Tactical generator and EQS

`ATacticalCoverGeneratorActor::BakeCoverPoints` does not bake/register the cover locations found by its own grid. It:

- calls `ForceScanArea` asynchronously;
- performs a separate synchronous grid only to increment `GeneratedCoverCount`;
- discards `CoverSpot` and height classification;
- reports a count unrelated to the subsystem's eventual usable point count.

`ClearCoverPoints` only resets the count; it does not clear subsystem cover. Unscaled box extents and axis-aligned logic also ignore actor/component scale and rotation.

The EQS generator emits only already-cached points and does not request a scan. The score test defaults `ThreatContext` to Querier, hard-codes a 3,000 cm matching lookup, and matches points by location within 50 cm, losing normal/ID identity. There are no native runtime EQS callers; host assets may use it.

## 9. Reservation and cover-state ownership

There are at least four cover states:

1. subsystem reservation on a cached `FCoverPoint`;
2. controller `CurrentCover` and `bHasCover`;
3. controller active move goal and real/fallback flag;
4. soldier `CurrentCoverPoint`, `bIsInCover`, crouch/cover presentation.

They do not share a single transition function. Examples:

- Follow/LeaderPath call `Soldier->ClearCover()` but leave controller `bHasCover` true.
- Clearing soldier cover does not release controller-held reservation, despite the controller header comment saying cover clear releases it.
- Engage trusts both controller and soldier booleans.
- LeaderPath marks an active goal real without a reservation/current-cover record.
- Reservations are released on native death/end-play through `SoldierCharacter::UnregisterFromSystems`, but not explicitly in controller `OnUnPossess` or controller `EndPlay`.
- Leaving combat/cover for mission/follow movement has no general release call, so abandoned points can remain reserved until a new cover is secured, a fallback path releases it, or the soldier dies/unregisters.

The earlier archived Step 4 document said TakeCover always released its reservation on exit. That is no longer true: current code transfers the reservation to the controller. That old bug was partially fixed, but the new controller-held lifetime is incomplete.

## 10. Significance and registry

### 10.1 Decay time is slowed twice

The controller tick already receives elapsed real game time according to its larger tick interval. It then calculates:

`EffectiveDeltaTime = DeltaTime * SignificanceUpdateMultiplier`

The multiplier drops to 0.2 for Dormant. Memory and suppression therefore decay up to five times slower in real time for distant AI. A confidence-one nonvisible contact that should last about five seconds can persist around 25 seconds, before considering fireteam refresh.

### 10.2 Player and active-combat prioritization

Every `ASoldierCharacter` registers, including a native player-controlled soldier. The significance manager has no player exclusion. A native player evaluates Critical due to zero distance, but Critical still sets:

- pawn actor tick to 0.10 seconds;
- non-AI controller (including a PlayerController) tick to 0.05 seconds.

If the host player is a native `ASoldierCharacter`, this can throttle player actor/controller work. If the host uses a non-soldier pack pawn, it is unaffected.

`bForceFullTick` has no C++ writer and is still subject to the high-fidelity cap. `ForceFullTickUntil` is unused. The evaluator does not prioritize active combat, visible targets, suppression, cover movement, downed/reviving state, leader role, or mission criticality—only player distance/view and the unused force flag.

### 10.3 Unreachable far-poll branch

Controller registry polling contains special Low/far intervals, range, and LOS budget for `CurrentLODBucket >= 3`. But the significance manager also sets `bSkipExpensivePerceptionPolling=true` for bucket 3 and above, and Tick skips the polling function entirely. The internal far-poll tuning branch is therefore normally unreachable.

Engine perception remains configured and active; significance does not disable or retune it by bucket.

### 10.4 Registry notes

The registry's radius query correctly filters by 3D distance after using a 2D spatial hash. Smoke line checks are used by explicit LOS, but not by the close-range override. Suppression applies to all nearby AI except the shooter without team filtering, which may be intended for realistic friendly near-miss suppression.

## 11. Adapter, pack presentation, commands, and pings

### 11.1 Adapter

- Move commands are passive storage only.
- Aim commands are last-writer state mirrored to native aim or pack visual properties.
- Pack safe mode uses native `UWeaponComponent` for gameplay damage and pack components only for visuals.
- `TryStartBurstAtAimCommand` marks pack firing active even when visual start fails, provided a pack weapon target was found.
- Pack firing state remains true until explicit stop; it does not follow native burst completion.
- Pack stop clears presentation but does not stop the native gameplay weapon burst.

### 11.2 Tactical commands are one-shot, not an authority system

`USquadAICommandSubsystem::CurrentCommand` is not read by AI/controller/StateTree C++.

- `FollowLeader`: records/broadcasts only; no behavior change.
- `Assault`: records/broadcasts only; no behavior change.
- `HoldCover`: starts an async query, but does not force/transition TakeCover or consume the result itself.
- `SuppressSector`: one aim + one burst; normal AI can overwrite/clear it immediately.
- `RegroupOnPlayer`: one `MoveToActor`; FollowLeader/StateTree/direct movement can replace it on the next update.

The class description calls this an authority system, but there is no persistent per-soldier command intent or arbitration in native code.

### 11.3 Pings

Every nearby ally treats every ping type the same: set an investigate aim at the location. Ping expiration does not clear that aim. If no StateTree/direct combat path later clears it, the focal point can persist beyond the marker's lifetime.

`SetCombatAimTarget` sets blackboard `bIsInAttackRange?=true` whenever a target location is supplied, including investigate pings with no target actor.

## 12. Current source versus archived Step 4 notes

Several old findings were fixed in the current source and should not be carried forward as active bugs:

- fallback-fire enable/range fields are now read;
- cover sample keys now use an `int64` bit pack rather than the old decimal collision scheme;
- negative Y chunk decoding explicitly sign-extends;
- TakeCover transfers successful reservations to the controller rather than always releasing on exit;
- cover arrival rotation now interpolates;
- perception config starts immediately rather than waiting one second;
- EnemyMission player hunting is capped at 12,000 cm;
- max full-chunk starts was reduced from two to one per frame.

However, the current controller header still says production fallback fire should remain false while `USquadAITuning` defaults it to true with an 8,000 cm range. Runtime uses the tuning value, so direct fallback firing is enabled by default.

The old documentation also described `UPerceptionMemory` and `TerrainCoverHelper`; those files are absent from the current 230-file source snapshot.

## 13. Prioritized risk list

### P0 — establish one behavior authority

1. Direct enemy movement overwrites TakeCover, mission, and fireteam movement while memory exists.
2. Direct fallback and StateTree tasks both own bursts/aim/movement.
3. Direct leader path runs beside `LeaderPath` and can replace combat-cover movement.
4. No owner/priority token exists for movement, aim, fire, or tactical commands.

### P0 — correct threat semantics

5. Hearing/damage are treated as visual contact.
6. Remembered targets are acted on at live actor location.
7. Fireteams self-refresh contact forever with a 0.55 floor and live target location.
8. The 1,800 cm close override bypasses walls and smoke.

### P0/P1 — make cover trustworthy

9. A normal uncached 3,500 cm query can enqueue about 92,160 async probes; the 96 trace budget is not enforced.
10. Failed reservation does not reject the selected point.
11. Base-scored but physically unprotected/unpeekable points can win.
12. Probe hit distance, actor mobility, thickness, final nav projection, and navigation cost are not validated.
13. Revalidation/invalidation destroys reservations and reuses IDs without holder/claimer generations.
14. Controller/soldier/subsystem cover states diverge and abandoned cover may remain reserved.
15. Async query/trace lifetime is not tied to pawn lifecycle or request generations.

### P1 — lifecycle/LOD

16. Pooled controllers retain memory, suppression, cover, commands, and late query results.
17. LOD multiplier slows memory/suppression decay in real time.
18. Native player soldiers can be managed as AI significance entries.
19. StateTree component ticking is not explicitly LOD-controlled.
20. Combat/mission importance does not promote significance; `bForceFullTick` has no native writer.

### P1/P2 — disconnected feature surfaces

21. Shared-threat subsystem has no native reader.
22. Attack coordinator is not started natively and its fields have no C++ consumer.
23. Tactical Follow/Assault commands are behavior no-ops; other commands are transient.
24. Tactical cover “bake” discards its own generated locations.
25. Exposed fields such as `ShotsPerBurst`, `DirectCombatBurstCooldown`, `MinCoverThickness`, `ChunkSizeZ`, `ForceFullTickUntil`, and several task bookkeeping fields are inactive.

## 14. Recommended correction order (after product intent is confirmed)

1. **Choose the authority model.** Recommended: StateTree chooses intents; controller owns one movement/aim/fire arbiter. Direct fallback should run only when no valid StateTree is running or as an explicit lower-priority intent.
2. **Create typed threat records.** Keep sight/hearing/damage timestamps separately; only sight/verified LOS sets visible. Expose selected actor plus immutable `LastKnownLocation`, confidence, sense, and age to consumers.
3. **Stop live tracking of memory.** All nonvisible pursuit, cover, evaluator, and fireteam operations should use stored/predicted location, not actor transform.
4. **Repair fireteam sharing.** Require fresh reporter perception, use a timestamp/TTL, never let shared ingestion serve as its own next report, and make tactical role goal outrank generic pursuit where appropriate.
5. **Gate/remove competing movement paths.** In particular, direct enemy/leader movement must respect active cover/task/command ownership.
6. **Make cover scanning incremental.** Carry a sample/probe queue across frames and enforce the trace budget; cancel unused queued scans where appropriate.
7. **Strengthen cover validity.** Ignore querier/threat/soldiers, reject movable/thin blockers as intended, use hit distance, reproject final point, require protection and a usable peek/escape path, and account for nav path cost.
8. **Use owner-checked reservation tokens.** Include chunk generation and claimer; preserve or explicitly revoke occupants on rescan; never release by key/ID alone.
9. **Unify cover state transitions.** One controller API should enter, leave, abandon, die, unpossess, pool-sleep, and invalidate cover while synchronizing soldier presentation and subsystem reservation.
10. **Reset pooled AI state.** Add a controller reuse reset and invalidate outstanding async generations.
11. **Correct LOD time and scope.** Use real DeltaTime for decay, exclude player-controlled soldiers, promote active combat/cover/revive/leader agents, and explicitly set StateTree/perception tick policy if desired.
12. **Turn tactical commands into persistent intents** or rename them as one-shot requests. Wire coordinator/shared-memory/generator features only if they match the intended game design.

## 15. Questions for later product-intent alignment

These do not block further source study, but they determine the correct fix design:

1. Should enemies use stealth/fog-of-war memory, or is player-location pursuit inside 120 m intentionally arcade-like?
2. Should StateTree be the authoritative combat brain, with direct code only as a missing-asset emergency fallback?
3. Should enemy fireteams hold distinct suppress/flank/assault destinations during contact, or should all enemies aggressively close?
4. Is 18 m wall/smoke recognition intentional anti-stall behavior, and if so should it grant awareness only rather than firing LOS?
5. Should tactical player orders persist until cancelled/changed, or are they intended as short impulses?
6. Does the real host use a native `ASoldierCharacter` player or only an external pack pawn?
7. Are there multi-level combat spaces where the same XY cover chunk can contain multiple floors/elevations?
8. Which host Blueprint assigns the StateTree asset, and what are its actual transitions/bindings?

## 16. Pass result

The AI/cover architecture is now sufficiently mapped to explain common symptoms such as:

- enemies abandoning or never reaching cover;
- squads collapsing into a direct rush instead of flanking;
- AI tracking through walls after brief contact;
- smoke working at range but not close up;
- repeated or snapping bursts despite Engage's one-burst-per-peek logic;
- soldiers crouching at weak/non-cover points;
- two AI selecting one cover point;
- stale behavior after pooled reuse;
- first-contact hitches in uncached terrain;
- tactical commands appearing to acknowledge but not persist.

No source repair should start by tuning distances or StateTree transition thresholds alone. The first repair must define ownership and remove competing movement/threat authorities; otherwise later cover, fireteam, and balance changes remain nondeterministic.
