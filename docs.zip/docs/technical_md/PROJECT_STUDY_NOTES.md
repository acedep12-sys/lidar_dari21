# SquadAI / Lidar Rostami — study notes

Last updated: 2026-09-21
Repository commit inspected: `1578dfb276d153cfac960d41275273339a0484a9`

## Evidence available

The repository contains only three archives:

- `ALL_MARKDOWN_DOCS_2026-09-12.zip` — 48 Markdown files (many are duplicated/archive copies).
- `SquadAI.zip` — module directory intended for `<Project>/Source/SquadAI/`.
- `Source.zip` — the exact same `SquadAI` module plus two target files at `Source/` root.

A recursive diff confirms:

- `Source.zip/Source/SquadAI/` and `SquadAI.zip/SquadAI/` are identical.
- The only functional additions in `Source.zip` are `SquadAI.Target.cs` and `SquadAIEditor.Target.cs`.

No `.uproject`, maps, full `Content/`, or host project's existing targets/modules are present, so exact host-project integration cannot yet be decided from this repository alone.

## Current architecture understanding — pass 1

Identity:

- Unreal Engine 5.7 C++ tactical/open-world FPS module.
- Sacred Defense / Iran–Iraq War setting, Iranian side, 1980–81 Khuzestan.
- Farsi-first/localized experience, though the latest main-menu reference pass intentionally makes the main screen English-only.
- Primary hero: Major Shahid Iraj Rostami; squad includes RPG specialist, G3 marksman, and medic.

Code size:

- 230 `.h/.cpp` files, approximately 57,582 lines in the current archive.
- 235 module files total in `SquadAI.zip`; `Source.zip` adds two targets.
- Not a plugin: it is currently authored as a game module.

Main systems:

- Characters: soldier base, leader, ally, enemy; leader immortality and ally down/revive behavior.
- Combat: health chokepoint, weapon, aim, grenade, effects, TPWCS/third-party-pack bridge.
- AI: controller + StateTree tasks, fireteams, attack coordinator, shared threat, tactical roles.
- Cover: scanning, reservations, EQS nodes, tactical generator.
- Missions/world: quest chains, zones, wave spawners, pools, spline paths, weather, dust/fire, scene decoration.
- Tactical: squad orders, ping, radio chatter, mortar/fire support.
- UI: Canvas-based menu and HUD; legacy UMG path is suppressed. Latest menu has a modern-warfare-style command layout.
- Meta: profiles, XP/progression, inventory, achievements, theaters, save/load/travel restore.
- Runtime services: audio director, significance/LOD, actor registries, asset cache, debug/diagnostics, FX budgets.
- Setup/editor helpers: auto-setup manager and blueprint factories.

Important current facts:

- `SquadAI.cpp` uses `IMPLEMENT_PRIMARY_GAME_MODULE`, so it assumes SquadAI is the project's one primary game module.
- Team 0 and Team 1 are made hostile globally at module startup.
- Documentation states the code was statically validated but never compiled or PIE-tested in UE 5.7.
- The key unresolved integration decision is whether SquadAI is the standalone primary module or an additional module inside an existing project.
- The first serious milestone is a clean local Editor build followed by the documented in-engine checklist.

## Target-file conclusion

The local complete project already works after replacing only `<Project>/Source/SquadAI/`. That working build is the decisive integration evidence: the host project already has the target definitions it needs (whether generated under the same project name or supplied elsewhere).

Therefore:

- `Source.zip/Source/SquadAI/` and `SquadAI.zip/SquadAI/` are interchangeable; their module contents are identical.
- Do **not** copy or replace the two archive-root files `SquadAI.Target.cs` and `SquadAIEditor.Target.cs`.
- Continue all future work by replacing/editing only `<Project>/Source/SquadAI/`, exactly as the user has been doing.
- Do not change module/target identity merely from archive inspection; the working host project is the source of truth and its files are outside the permitted edit scope.

## Study progress

1. Repository/integration inventory — completed.
2. Startup and ownership graph — completed; detailed notes in `PASS2_STARTUP_OWNERSHIP.md`.
3. Player/squad combat loop — completed; detailed notes in `PASS3_PLAYER_SQUAD_COMBAT.md`.
4. AI/cover loop — completed; detailed notes in `PASS4_AI_COVER.md`.
5. Mission/open-world loop — completed; detailed notes in `PASS5_MISSIONS_OPEN_WORLD.md`.
6. UI/assets/localization — completed; detailed notes in `PASS6_UI_ASSETS_LOCALIZATION.md`.
7. Compile-risk pass — pending.
8. Product-intent alignment — pending.

## Pass 2 summary

The module is an integration layer around a host FPS project. It does not define a gameplay GameMode, gameplay PlayerController, player pawn, GameState, or PlayerState. The host project owns those; SquadAI adds behavior through automatic GameInstance/World subsystems, map actors, Canvas HUDs, native soldier classes, and a runtime player combat bridge.

Startup has four layers:

1. Module startup installs the global team-attitude solver.
2. Seven GameInstance subsystems own persistent settings, saves, localization, inventory, progression, difficulty, loading, and quest history.
3. Nineteen World subsystems own AI/performance/cover/audio/FX/quest/tactical runtime services in every map.
4. Map-specific GameModes/HUDs and placed actors activate the menu, missions, environment, characters, and audio configuration.

Main-menu intended path: `ASquadAIMainMenuGameMode` -> SpectatorPawn + `ASquadAIMainMenuHUD`, with `ASquadAIMainMenuSetupActor` as a level director. Gameplay HUD assignment is external; the module expects the host gameplay GameMode to use `AQuestNativeHUD` or a subclass.

Important static findings to revisit:

- The automatic player diagnostic subsystem can attach the gameplay combat bridge to the main-menu SpectatorPawn and remain tickable there.
- Persisted audio volume and FOV are applied too early at GameInstance initialization and are not reliably re-applied when world audio/player camera become available.
- `ASquadAIMainMenuHUD` reads saved language into a local variable but does not initialize `CachedMenuSettings`, so English/Persian decision paths can disagree.
- The default loading `UUserWidget` stores state but has no native visual construction; a UMG Blueprint is required for that layer to render.
- The loading subsystem and gameplay HUD have two independent deployment/keypress gates.
- StateTree tasks are in C++, but the StateTree asset itself must be assigned by the host Blueprint/content setup.
- The MainMenuSetupActor loading texture slot is resolved but not pushed into the loading subsystem.

## Pass 3 summary

The detailed combat/health/revive/inventory/death report is in `PASS3_PLAYER_SQUAD_COMBAT.md`.

The native damage-duplication question is resolved: one normal Unreal damage call does not inherently reduce an `ASoldierCharacter`'s native health twice. `ASoldierCharacter::TakeDamage` handles native health itself and does not call `Super::TakeDamage`. That prevents duplication, but also suppresses Unreal/Blueprint AnyDamage, point-damage, radial-damage, and actor damage-delegate contracts; the class's own `OnTakeAnyDamage` handler is normally inert.

The larger risk is multiple combat authorities: the host weapon, the automatic player camera trace, native health, pack health, direct reflected property writes, and pack-health polling can coexist. The player bridge applies fixed 25-damage camera hits every 0.1 seconds while firing, independent of actual shot/ammo cadence, and may overlap host-weapon or mounted-turret damage.

Important Pass 3 findings:

- Pack-health polling mirrors deltas with a null causer, losing friendly/player attribution. Enemy spawn grace can reject a real player-origin pack delta while the bridge still accepts the lower pack baseline, splitting native and pack state.
- Native direct weapon and player-bridge hits bypass `ASoldierCharacter::TakeDamage`, so they do not report `UAISense_Damage` or record hit-bone/headshot metadata.
- Pure pack kills receive wave/mission credit through spawner polling, but bypass native kill/headshot progression and pack damage/death contracts.
- Ally bleedout never expires; its value slowly falls from 45 to a permanent floor of 15 while the HUD presents it as a bleedout bar.
- Revive progress persists across interrupted attempts and stacks across multiple revivers. The revive-speed upgrade and revive XP/stat function have no callers.
- Allies normally start at 100 current health after their max is raised to 150 in `AAllySoldier::BeginPlay`.
- Mission death recovery is owned by the active `AMissionZone`; the default flow immediately revives the player and retries the mission, with no native game-over screen. A 2026-10-05 source correction routes possessed native Soldiers through mission death handling, clears full downed state on respawn, and resets reflected pack death flags including `bIsDead?`; host-side presentation still requires PIE verification.
- The default failure/retry path revives only the player; downed allies persist. The legacy attempt-restart path revives the squad.
- Grenade inventory has GameInstance and pawn-local authorities. The combat-bridge fallback activates whenever component throw is unavailable (including cooldown), bypasses cooldown, decrements only global inventory, and can later be undone when opening inventory copies local counts back.
- Enemy pooling is not symmetric: wake does not cancel native death lifespan or restore pack health/death state; reset destroys pooled pawns; available counts include invalid entries. Reacquired enemies can remain pack-dead or be destroyed mid-wave.

No `Source/SquadAI` code had been modified at the time of the Pass 3 study; later mission death/respawn changes are recorded above. Other pass sections below retain their own historical snapshot dates.

## Pass 4 summary

The detailed AI, StateTree, fireteam, cover, registry, adapter-command, and significance report is in `PASS4_AI_COVER.md`.

The central AI finding is overlapping authority. StateTree tasks, controller-tick direct fallback combat, direct enemy pursuit, direct leader mission pathing, fireteam goals, tactical commands, and adapter presentation all write to shared movement/aim/fire state without an owner or priority token. In particular, `RunDirectEnemyMovement` checks remembered threat before fireteam goals and does not respect active cover movement, so it can overwrite TakeCover and collapse Suppress/Flank/Assault roles into a generic direct rush.

Important Pass 4 findings:

- Perception discards stimulus type: hearing and damage can be marked currently visible, while a failed non-sight stimulus can clear visibility during active sight.
- Registry recognition and firing use a 1,800 cm close-range override that bypasses LOS and tactical smoke.
- Threat selection scores stored last-known positions but returns a live actor; StateTree tasks, direct movement, cover, and fireteams then consume the actor's current transform, producing real-time tracking of remembered nonvisible targets.
- The native shared-threat subsystem is write-only. Separately, the enemy fireteam subsystem reinjects shared contact every 0.5 seconds with a 0.55 confidence floor and live actor location, allowing a contact to self-sustain indefinitely without fresh perception.
- Fireteam role destinations are normally preempted while contact exists; the direct enemy threat branch runs before `FireteamMoveGoal`.
- The attack coordinator has no native `BeginAttack` caller, and its assigned attack point/phase fields have no C++ consumer; external Blueprint/StateTree Content is the only possible missing integration.
- StateTree assets are not assigned in C++; the host Blueprint/content setup owns the actual asset and transitions, which cannot be verified from the module archive.
- `TakeCover` still moves to a selected point when reservation fails. LeaderPath's combat-cover path does not reserve or initialize cover metadata, and tasks can leave controller/soldier cover flags and held reservations out of sync.
- Cover scanning submits 1,440 async traces per started chunk while the configured 96-trace budget is only observed, not enforced. A normal uncached 3,500 cm footprint can cover about 64 chunks—roughly 92,160 async probes—and queued scans continue after partial query resolution.
- Cover point generation ignores blocker mobility/thickness and actual hit distance, does not reproject the offset stand point, and treats physical protection/peek viability as bonuses rather than requirements.
- Chunk revalidation/invalidation clears reservations and reuses local IDs without holder generations or claimer-checked release. Stale controllers can later release a new occupant's reused ID.
- Async cover requests have no request generation or pawn-lifecycle cancellation; pooled controllers also retain memory, suppression, pending/active cover, commands, and late callbacks.
- Significance already lengthens controller tick intervals, then multiplies elapsed `DeltaTime` by a value as low as 0.2, making distant memory/suppression decay up to five times slower in real time. It does not exclude a native player `ASoldierCharacter` and does not explicitly throttle the StateTree component.
- Tactical squad commands are mostly transient: Follow/Assault have no native behavior effect, HoldCover does not force result consumption, and Regroup/Suppress are immediately overwritable one-shot operations.
- Current source has fixed several issues recorded in older docs (fallback switch use, sample-key packing, reservation transfer, smooth cover rotation, immediate perception setup, and 12,000 cm mission-hunt cap), so the old Step 4 notes must not be treated as the current implementation.

No `Source/SquadAI` code has been modified.

## Pass 5 summary

The detailed mission, spawner, persistence, HUD-goal, spline, environmental-hazard, weather, dust, and procedural open-world report is in `PASS5_MISSIONS_OPEN_WORLD.md`.

The central mission finding is that the module has three independent runtime authorities: `AQuestChain`/`AMissionZone`, `AQuestDirector`/`AQuestMission`, and `ACombatEncounterVolume`. They do not share activation, completion, failure, HUD, save, spawn, or teardown contracts. The native HUD and main save primarily support only the first authority.

Important Pass 5 findings:

- `AAutoSpawnZone` configures runtime-spawned zone/spawner children after their `BeginPlay`, so tags and custom shape are not registered/applied and the spawner is not auto-started. Reach can stall, Clear can succeed after five seconds regardless of enemies, and Defend can treat the player as permanently outside.
- `AWaveSpawner::StopWaves()` clears timers only. Restart/load zeroes counters while old living enemies and death delegates remain, allowing old deaths to corrupt the new run. Empty/malformed waves can stall permanently.
- Legacy `AEnemyWaveSpawner` announces wave/all-wave completion when spawning ends rather than combat ends. Its pack-health polling stops after final spawning, so late pack deaths can leave Clear missions stuck.
- Pool prewarm callers now exist, but wake/release remains incomplete: native death lifespan is not canceled, pack state is not reset, and AI commands/memory/cover/timers/callbacks survive reuse.
- Save data has no stable chain/mission identity and omits mission/spawner/objective/encounter/procedural state. Restore picks an arbitrary first auto-start chain after BeginPlay, when auto-start combat may already exist, then stops spawners without cleaning living enemies.
- `AQuestNativeHUD` suppresses the tag-objective UMG stack and caches one quest chain indefinitely; later mission authorities can be invisible or stale.
- `STTask_EnemyMission` still hunts the player without perception inside 12,000 cm before mission movement. Direct pathing has a function-static fallback `AQuestZone` shared across controllers/world contexts.
- `ASceneDecorator` fails to damage a native player because native `UHealthComponent` is misclassified as a pack component. Both fire implementations use non-reference-counted burn booleans, so overlapping fires fight over status/overlay state.
- Barrage can damage a native player twice (direct player pass plus registry pass) and combines generic pack damage with direct reflected health subtraction.
- Sandstorm sight scaling now has a real controller consumer, fixing the archived zero-reader defect, but only sight radii change; direct pursuit/memory/visual weather remain. Manual Trigger/Stop phases stall when auto-cycle is disabled.
- Procedural villages, buildings, trenches, encounters, and supplies spawn child actors without explicit ownership/level placement and lack comprehensive EndPlay cleanup, which is unsafe for World Partition streaming. Several documented behaviors are absent: building/trench cover creation, barrel physics impulse/AI suppression, and use of multiple dust-zone fields.
- All ten principal archived Step 5 findings were compared against current source: several are fixed, while spawner unification, pooling, mission modes, FX cleanup, weather, and quest-log changes remain only partial at the system-contract level.

No `Source/SquadAI` code has been modified.

## Pass 6 summary

The detailed UI, Canvas/UMG stacks, Farsi/RTL shaping, localization subsystem, asset-import pipeline, loading experience, and settings integration report is in `PASS6_UI_ASSETS_LOCALIZATION.md`.

The central UI finding is that both live interfaces are immediate-mode Canvas HUDs (`AQuestNativeHUD`, `ASquadAIMainMenuHUD`, ~8,900 lines combined) while the module also compiles seven UMG widget classes that it actively suppresses at runtime by class-name substring sweeps. Canvas is authoritative; the suppressed UMG is dead weight that must either be deleted or formally opt-in. Localization is a custom INI subsystem (default Persian + English fallback table), and its generated template does not match the keys the code queries.

Important Pass 6 findings:

- **P6-1:** `ASquadAIMainMenuHUD::CachedMenuSettings` is loaded only when Settings is opened or changed — on menu boot with an English saved setting the menu renders mixed Persian/English and reports default quality until the user visits Settings.
- **P6-2:** The pause menu labels "Resume [Esc]" in both languages, but Esc/[P] is polled by a pawn component that stops ticking under `SetGamePaused(true)`; `DrawPauseMenu` reads only mouse input, so resume works only by click. Inventory's own I/Esc handler works (HUD-driven), highlighting the asymmetry.
- **P6-3:** 62 static localization keys are queried, only 13 exist in the generated `SquadAILocalization.ini` template. The `[Inventory]`, `[FallenTroopNotes]`, `[RadioStations]`, and `[QuranVerses]` sections are missing entirely, and the `[MainMenu]` template provides unused alias names (`SubTitle`, `Btn*`) while the code queries `GameSubtitle`/`Button*` — user edits to shipped keys silently do nothing.
- **P6-4:** the localization file auto-creation and loose-PNG asset lookups target `ProjectDir()`/content roots — editor-development paths that are read-only or non-staged in packaged builds. INI should live under `ProjectSavedDir()`; textures need an explicit packaging story.
- **P6-5:** pause-menu and deployment-veil texture fallbacks re-stat/import from disk every frame while art is missing.
- **P6-6:** widget suppression is class-name substring matching (`WBP_`, `Weapon`, `Ammo`, `TPWCS`, …), which can hide unrelated project widgets and is the only documented UMG contract.
- All 22 archived B6 Step-6 issues were re-validated: the large save/menu block (B6-1/3/4/6/7/8/9/14/15/17/18/20/21/22) is genuinely fixed in source; the remaining structural items are re-scoped into P6-1…P6-6.
- Farsi shaping (`ShapeAndOrder`) uses a per-frame cache and is adequate; the not-fallbackable asset is a Persian-capable font, which the module does not ship — engine `GetMediumFont` is the last-resort default.

No `Source/SquadAI` code has been modified.

## Localization decision & first code patch (L1) — 2026-09-21

**User decision (localization model, open question a):** keep the custom external `SquadAILocalization.ini`
system — its purpose is a Notepad-editable text layer for personal text changes, with backups kept for safety.
Not migrating to UE-native LOCTEXT.

**Audit of the user's INI (details in `PASS6_LOCALIZATION_INI_AUDIT.md`):**
- 61/~139 entries live; 78 decoys (MainMenu `SubTitle`/`Btn*` aliases, `[MapSelection]`, `[Traits]`,
  `[Profile]`, loading tips, inventory tabs/stat/wallet labels, most `[HUD]` names); 42 live keys missing.
- New defect **P6-8**: `SquadAI.ReloadText` console command advertised in the INI header never existed.
- `[FallenTroopNotes]` (incl. `Note<N>_Image` scan override), `[RadioStations]`, `[QuranVerses]`, `[PauseMenu]`,
  `[Armory] Weapon*` verified fully live.

**L1 patch delivered** (`patched/localization_L1.patch`, applied copy
`patched/SquadAI/Private/Localization/SquadAILocalizationSubsystem.cpp`; header unchanged;
round-trip-verified against extracted source):
1. P6-8 fix: `SquadAI.ReloadText` registered (register/unregister in Initialize/Deinitialize).
2. P6-4 fix: search order now `ProjectSavedDir()` first; legacy ProjectDir/Config/Content + `.txt` kept as
   fallbacks; auto-created master written to `Saved/`.
3. P6-3 soft fix: alias bridge (`SubTitle`↔`GameSubtitle`, `BtnStartGame`↔`ButtonNewGame`,
   `BtnMapSelect`↔`ButtonMapSelect`, `BtnArmory`↔`ButtonArmory`, `BtnProfile`↔`ButtonPlayerProfile`,
   `BtnSettings`↔`ButtonSettings`, `BtnExit`↔`ButtonQuit`, `BtnEquipWeapon`↔`EquipWeaponButton`,
   `BtnNextNote`↔`NextNoteButton`, `RevivePrompt`↔`ReviveHoldPrompt`, `FirstAidPrompt`↔`PickupFirstAid`) —
   old personalized files keep working.
4. `GetDefaultIniTemplate()` regenerated = full verified live-key master, byte-identical to
   `SquadAILocalization_v2_MASTER.ini` (user values migrated; dead sections kept under `⏸ RESERVED` backup banner).

**Companion file:** `SquadAILocalization_v2_MASTER.ini` (user deploys to `<Project>/Saved/SquadAILocalization.ini`).

**Still open:** L2 full-wiring opt-in (hardcoded bilingual surfaces → INI: map cards, traits, profile, tips,
tabs, stat labels, wallet, counters, leader/wounded labels, watermark), UMG policy (delete vs opt-in),
P6-1 (menu settings boot leak), P6-2 (pause Esc under SetGamePaused), P6-5 (per-frame texture re-stat failure latch),
and all Pass 5 structural decisions.

## B1 patch delivered (UI boot behavior) — 2026-09-21

User directive: fix the currently known problems; user will then report their own observed runtime bugs.

**`patched/ui_boot_B1.patch`** (3 files, 6 hunks, round-trip verified):
- **P6-1** — `SquadAIMainMenuHUD::BeginPlay` now caches the full `CachedMenuSettings = SaveSys->LoadSettings()`
  (was language-only read; every panel defaulted to fa/preset-3 until Settings was first opened).
- **P6-2** — `DrawPauseMenu` now handles Esc/P resume itself (top of function), mirroring the inventory's
  working Draw-side handler; bridge Esc/P poll can't tick under `SetGamePaused`.
- **P6-5** — both per-frame loose-PNG resolve blocks (pause card/button @2833, deployment veil art @1476)
  throttled to 2 s wall-clock retries (`FPlatformTime::Seconds()`; world time freezes under pause);
  two `double` retry-stamp members added to `QuestNativeHUD.h`; explicit `HAL/PlatformTime.h` include.

Deploy guide + test checklist: `PATCH_PACKAGES.md`. Patched copies: `patched/SquadAI/` (4 files).
Originals everywhere remain untouched as backup. Awaiting user's local build + their bug list.

## Round 2 — user bug batch fixed (B2/B3, cumulative with L1/B1) — 2026-09-21

Deliverables: `ROUND2_FIXES.md` (full report); 9 cumulative files in `patched/SquadAI/`;
`fixes_ALL_cumulative.patch` (originals→L1+B1+B2+B3, 1813 lines, round-trip verified);
`SquadAILocalization_AR_ADDON.ini`; master INI v2 extended with `[*.ar]` sections (template
regenerated byte-identical).

Root causes found & fixed:
1. **UI suppression regression (P6-6)**: F-G12 narrowed blanket `WBP_*` → explicit name list leaked
   any unmatched pack widget (TPW health bar) which renders ON TOP of Canvas HUD, covering the
   top-right weapon plate (plate was drawn fine) and loading screen. Fix: deny-by-default ownership
   allow-list (`RegisterAllowedViewportWidget`, SquadAI* prefix auto-allow), collapse-based sweep,
   idle backoff preserved. Loading widget registers + retries spawn (P6-7), ZOrder 1000 kept.
2. **Difficulty→loading "thinking"**: `OpenLevel` fired same frame as widget spawn (0 frames shown).
   Fix: FTSTicker-deferred travel (0.25 s) so screen paints first.
3. **Entry FPS drop**: handshake released at begun+PC+1 s. Fix: + streaming settled + pawn + 2 s
   settle buffer (+30 s failsafe, pawn optional@6 s for menu destinations).
4. **Enemies frozen**: `RunDirectEnemyMovement` gated `CurrentLODBucket < 5` — distant spawns are
   Dormant(5) → zero movement. Fix: run in all buckets (self-throttled); assault-goal fallbacks
   (inactive chain / non-Clear-Defend → any chain → Clear/Defend scan → any zone).
5. **Watermark shadowy**: flicker alpha 0.145–0.195 (site 1) + Brass/0.72–0.95 tint multiplies
   (3 crests) → stable 0.55 / full white ×4 sites.
6. **Stat ribbon**: number at Y+35 vs icon base ~Y+42 (fused) → Y+43/value, Y+68/label, scale
   1.02→1.12 + drop shadow ON (TitleFont route).
7. **Description fonts**: +0.14 scale (≈+5px@36pt) on 26 BodyFont call sites in MapSelect/Armory/
   Progression/Profile pages.
8. **Quick Start**: flat plate + hand-drawn ">>" → DrawReferencePanel 3D CTA + depth-shadowed
   double chevron + TitleFont pipeline (matches left buttons).
9. **Merged Persian words**: shaper DROPPED ZWNJ and treated it as join-transparent (182 ZWNJ
   sites affected) → ZWNJ now emitted = hard join boundary (2 spots in FarsiTextHelper.cpp).
10. **Arabic**: fa→en→ar tri-cycle (saved, boots, live re-skin), `ApplyArabicPreset()` (INI
    `[MainMenu.ar]` consulted), non-fa languages fall back to built-in ENGLISH (never Persian),
    HUD/loading IsEnglish helpers now `!fa`, NormalizeLang ar, `[*.ar]` add-on sections delivered.
    Notes bodies/radio names Arabic = follow-up; hardcoded bilingual surfaces ar→English until L2.

Weapon-in-hands question (future phase): answer = skeleton socket name missing on custom mesh;
fix = socket-mapping/override in pack attach bridge or socket added to user's skeleton in editor;
animations untouched. Not started (by design).

Awaiting: deployed-bug report from user; screenshot + other-AI notes were NOT attached (asked to
re-send; pixel-color pass pending).

### Round 2.5 — Pixel polish pass (screenshot-verified, 2026-09-21)
- Screenshot (1919x1079) arrived; pixel-sampled. Confirmed: ZWNJ merge (`جبههها`), QS title dark-gold 0.7x vs left buttons, emblem tint.
- FIXED (SquadAIMainMenuHUD.cpp only): mission crest `Brass*0.74f`→White (measured 0.72x header crest); portrait-fallback `Brass*0.82f`→White; stat value Y+43→+46 & scale 1.12→1.15 (icon 886-920 / labels 962-969 → mid 945); QS title → MenuFont 1.15 TextBright/RefLabelBright + subtitle TextMuted (exact left-button recipe).
- Misreads resolved: "کارنامه نبرد" correct; no "Version 1.0.0 AR" text (was XP counter); green news dot is intended (0x14C819 from owner reference).
- TitleFont carries Persian digits (difficulty cards ۰۱-۰۴) — safe for stat values.
- fixes_ALL_cumulative.patch regenerated (1843 lines) + round-trip byte-verified.

### Round 3 — UMG policy + mortar pressure + changelog (2026-09-21)
- UMG verdict (owner): keep classes/assets in project as backup, never show in game — round-2 deny-by-default suppression IS the enforcement; documented as locked policy. No deletions.
- NEW subsystem: SquadAIMortarPressureSubsystem (Tactical, UWorldSubsystem, FTimerManager 0.5s machine). 10 shells @0.1s on player pos, 2.5s HUD-warning window (reuses TacticalMortarBarrageActor + RegisterIncomingMortarWarning + MortarInbound radio callout "دیده‌بان"), rest 15/11/8/5.5s Easy→Lethal via UDifficultySubsystem, 15s entry grace, dormant w/o living pawn, all tunables UPROPERTY. Fire-support path untouched.
- Screenshot re-upload was byte-identical to the analyzed one (same pre-fix build).
- Other-AI notes: STILL not uploaded (3rd request pending).
- Deliverables: TECHNICAL_CHANGELOG.md (full L1→R2.5 technical edits), feature_mortar_pressure.patch (standalone), fixes_ALL_cumulative.patch now 11 files / 2116 lines, round-trip byte-verified.
