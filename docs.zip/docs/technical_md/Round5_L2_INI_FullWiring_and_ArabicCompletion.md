# Round 5 — L2 full wiring pass + Arabic completion for notes/radio

Resumes the deferred "L2 full-wiring" item from `PASS6_LOCALIZATION_INI_AUDIT.md` §4: every
hardcoded-bilingual surface named there is now INI-driven, and the Arabic layer gets its two
missing content sections. All edits live in `/home/user/source/SquadAI/` (drop-in tree);
no other modules touched, no UI layouts/images/meshes changed — only *text routing*.

## What becomes live with zero INI edits (user's existing keys, former decoys)

| Surface | Your key | Where wired |
|---|---|---|
| Squad status panel labels | `HUD.SquadLeaderName`, `HUD.AllyNamePrefix`, `HUD.AllyStatusWounded` | `QuestNativeHUD.cpp` squad panel (leader line, ally lines, wounded state) |
| Grenade counter printf | `HUD.GrenadesLabel` ("…%d | …%d") | squad-panel ordnance line |
| Route guidance banner label | `HUD.GuidancePrompt` | guidance banner (label — goal & distance stay dynamic) |
| Inventory tabs (6) | `Inventory.TabWeapons / TabSupplies / TabNotes / TabRadio / TabQuran / TabWallet` | backpack tab bar |
| Armory stat labels (4) | `Armory.Stat_Damage / Stat_Accuracy / Stat_FireRate / Stat_Range` | armory rating bars |
| Weapon ammo line printf | `Inventory.AmmoLabel` | armory ammo box |
| Radio tuner printf | `Inventory.RadioTunerLabel` | radio frequency line (station name appended after) |
| Wallet fields (3) | `Inventory.WalletOwner / WalletBloodGroup / WalletDogTag` | ID/medical cards; profile fields still win when set. Both full-line and `%s`-format values supported |
| Loading tips | `Loading.Tip1..Tip7` | `USquadAILoadingScreenSubsystem::GetRandomTacticalTip` — INI tips take precedence; compiled tips remain the fallback pool; refresh cadence hardened with a wall-clock guard for streaming stalls |
| Map cards | `MapSelection.HeaderTitle / Map1..3_Title / Map1..3_Status / Map1..3_Briefing` | title+status at the card draw site; title+briefing also at construction in the progression subsystem (`GetStringForLanguage`, per-language slots) |
| Traits | `Traits.Trait1..5_Name/_Desc` | assign by combat role to the signature trait of each weapon: 1=MG3 suppression, 2=AK47 desert reliability, 3=G3A3 heavy caliber, 4=RPG7 tank hunter, 5=SVD marksman |
| Profile page | `Profile.HeaderTitle / CallsignLabel / KillsLabel / TanksLabel / RevivesLabel / TimeLabel / ScoreLabel` + new `HeadshotsLabel` | dossier header, callsign label, lifetime-records grid |
| Wallet/Radio/Supplies extras | new keys (`Wallet*`, `RadioStatus*`, `Supply*_*`, `SupplyStockFmt`, `SupplyWaterFmt`) | wired + added to the auto-generated template with Persian defaults |

Loading tip cadence fix: `LastTipWallTime` member (catalog widget header) + `FPlatformTime::Seconds()`
guard — tip rotation now follows wall time even if heavyweight streaming throttles tick.

## Localization subsystem changes

- New public API `GetStringForLanguage(Section, Key, LangCode, Default)` — explicit-language
  lookup for multi-slot data; never leaks Persian into English slots nor vice versa.
- Auto-generated template: decoy-alien reserved sections `[ArmoryLabels]/[LoadingTips]/[HUDLabels]/[InventoryLabels]/[MainMenuLabels]`
  renamed to the canonical `[Armory]/[Loading]/[HUD]/[Inventory]/[MainMenu]` — fresh files now
  write *live* keys only.
- **Arabic completion**: full seeded `[FallenTroopNotes.ar]` (6 titles + 6 bodies, MSA,
  theme-faithful to the code's Persian defaults) and `[RadioStations.ar]` (5 station names);
  plus new `[MapSelection.ar]`, `[Traits.ar]`, `[Profile.ar]`, and Arabic rows for the L2 HUD/Inventory keys.
  The fallback ladder stays `[S.ar] -> Key_ar -> built-in English -> Persian base`, so an Arabic
  player never sees Persian where an English default exists (pattern-matched English rows for
  Note/Station/Verse/Weapon keys already existed).
- Not wired on purpose: `MainMenu.Watermark`/`CopyrightNotice` (there is no text draw site — advancing
  them would mean drawing new UI, which is forbidden); `[Profile].RankLabel/RankValue/BtnCycleCallsign`
  (the redesigned dossier has no equivalent element).

## Risk notes
- All new printf-from-INI use UE tolerance for missing specifiers; a user line without `%` prints
  verbatim, which is exactly how their existing keys were authored.
- 419-brace/3045-paren balance verified on QuestNativeHUD plus 7 other touched files; every API used
  (`FPlatformTime`, `GetStringForLanguage` internals, existing `SquadAIHUDLocal`) is UE 5.7-standard.
