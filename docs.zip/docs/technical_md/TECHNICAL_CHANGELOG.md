# SquadAI — Technical Changelog (Fix Rounds L1 → Round 2.5 + Features)

Scope: everything below lives only inside `Source/SquadAI/`. Deploy by replacing that
folder with `patched/SquadAI/` (11 files, cumulative) or by applying
`patched/fixes_ALL_cumulative.patch` (round-trip byte-verified against the originals).
Originals are never overwritten.

---

## 1. Localization & boot fixes (Round L1 + B1)

| # | File | Root cause | Change |
|---|------|-----------|--------|
| L1 | `Private/Localization/SquadAILocalizationSubsystem.cpp` | External `SquadAILocalization.ini` ignored after edits; template drifted from the master INI | Added `SquadAI.Localization ReloadText` console command; search order prefers `Saved/` over `Content/`; alias bridge for legacy section names; embedded template regenerated ≡ `SquadAILocalization_v2_MASTER.ini` |
| P6-1 | `Private/HUD/SquadAIMainMenuHUD.cpp` (`BeginPlay`) | `CachedMenuSettings` filled only when Settings opened → English saves booted mixed-language with wrong quality readout | Full settings struct cached at boot via `LoadSettings()` |
| P6-2 | `Private/HUD/QuestNativeHUD.cpp` (Draw) | Esc had no effect while paused (widgets flushed input before HUD saw it) | Draw-side Esc/P pause-resume fallback |
| P6-5 | both HUD files | Missing-art retries ran per-frame (log/freeze spam) | Wall-clock throttled retry |

## 2. Round 2 — user-reported bug batch

| # | Symptom (user report) | Root cause | Fix (file) |
|---|----------------------|-----------|-----------|
| B2-1 | TPW/pack health bar on top right; TPW UI on loading screen; Canvas weapon plate "missing" | F-G12 narrowed blanket `WBP_*` suppression to a name list; unmatched pack widgets render **on top** of the Canvas HUD (plate was covered, not missing) | Deny-by-default ownership allow-list in `Private/HUD/QuestNativeHUD.cpp/.h`: `RegisterAllowedViewportWidget` / `IsAllowedViewportWidget` (SquadAI* prefix auto-allowed, loading-screen widget registers), collapse sweep with 1 s cadence + 10 s idle backoff |
| B2-2 | Difficulty → loading "thinking" pause | `LoadLevelWithScreen` called `OpenLevel` the same frame (0 painted frames) | `Private/Performance/SquadAILoadingScreenSubsystem.cpp`: FTSTicker-deferred travel (~0.25 s) so the screen paints first |
| B2-3 | FPS drop on level entry | Handshake released as soon as map begun + PC + 1 s | Readiness now requires streaming settled (`ULevelStreaming` all loaded+visible) + pawn (optional after 6 s) + 2 s settle buffer, 3 s minimum, 30 s failsafe; PIE widget respawn retry preserved |
| B2-4 | Distant enemies frozen, never advance to quest zone | Movement gated `CurrentLODBucket < 5`; far spawns are bucket 5 (Dormant) by design | `Private/AI/SoldierAIController.cpp`: gate removed (self-throttled 2.5–3 s reissue), assault-goal fallback chain (active chain any-type → any chain → Clear/Defend scan → any zone) in the zone-defense block. **User constraint honored: distant spawning stays intact.** |
| B3-1 | Emblem shadowy/low quality | Tint multiplies + flicker | See §3 (completed in pixel pass) |
| B3-2 | Stat numbers too close to icons, ugly font | Value at Y+35 hugging icon; scale 1.02, no shadow | See §3.2 |
| B3-3 | Description texts extremely small (26 sites) | BodyFont 0.66–0.75 scale | +0.14 scale bump on all 26 description sites (MapSelect/Armory/Progression/Profile) |
| B3-4 | Quick Start button: ugly `>>`, low text quality, disliked style | Flat PNG plate + thin hand-drawn `>>`; dark-gold text | Procedural `DrawReferencePanel` 3D (same helper as left buttons) + depth-shadowed double chevron + exact left-button text recipe (see §3.3) |
| B3-5 | Persian words merged (182 sites, e.g. `جبهه‌ها` → `جبههها`) | `FarsiTextHelper::ShapeFarsi` dropped ZWNJ (U+200C) and skipped it in neighbor lookup | `Private/HUD/FarsiTextHelper.cpp`: ZWNJ is now emitted and breaks the join; only tashkeel stays join-transparent. Global fix — no per-string edits |
| B3-6 | Add Arabic | — | Language tri-cycle fa→en→ar (settings row shows العربية, persisted, boot branch, `OnLanguageChanged`); `ApplyArabicPreset()`; fallback chain `[S.ar]K → [S]K_ar → built-in English → [S]K → default` (Persian base unreachable for ar); IsEnglish-style checks are `!fa`; `SquadAILocalization_v2_MASTER.ini` gained `[*.ar]` sections; `SquadAILocalization_AR_ADDON.ini` for live files. Glyph table already covers Arabic; Quran tab needs nothing |

## 3. Pixel-verification polish pass (screenshot-measured)

| # | Item | Pixel evidence (exact samples) | Fix (all in `Private/HUD/SquadAIMainMenuHUD.cpp`) |
|---|------|-------------------------------|-----------|
| 3.1 | Emblem — mission card crest still dark | Crest highlight avg `(103,65,25)` vs header `(143,87,29)` → **0.72×** = the `Brass*0.74f` multiply | Mission crest + portrait-fallback (`Brass*0.82f`) → `FLinearColor::White`. **All 5 emblem sites now texture-native colors, stable alpha (0.55 backdrop / 1.0 placements)** |
| 3.2 | Stat ribbon numbers | Icon band `y 886–920`, labels `y 962–969` → midpoint `y≈945` | Value `StatsY+46` (was +35), scale 1.15, drop shadow ON, `TitleFont` (Persian digits proven via difficulty cards ۰۱–۰۴); label at +68 |
| 3.3 | Quick Start title vs left labels | QS glyph median `(149,119,59)` ≈ 0.7× left labels' `(167,145,98)` | Left-button recipe exactly: `MenuFont` 1.15, `TextBright`→`RefLabelBright` hover, single tight shadow; subtitle `TextMuted` |
| 3.4 | False alarms cleared | 3× zoom checks | `کارنامه نبرد` renders correctly; "Version 1.0.0 AR" was the XP counter `۱۷۰۰ / ۱۲۰۰۰`; green news dot `0x14C819` is intentional per owner reference |

## 4. UMG policy (owner directive, locked)

**"Keep the UMG, but it should not be loaded in the game — it stays as a backup."**

- No UMG/TPW asset, class, or Blueprint is deleted or renamed — everything remains in the project as backup.
- At runtime the old UI never appears: the deny-by-default viewport suppression (B2-1) collapses any non-SquadAI widget within one sweep cycle, in game **and** during the loading screen (loading widget is explicit-allowed).
- The Canvas UI is the only visible stack. If the pack UI is ever wanted back, reverting is a config flip, not a restore-from-backup job.

## 5. Feature — automatic enemy mortar pressure (FR-mortar-pressure)

**New files:** `Public/Tactical/SquadAIMortarPressureSubsystem.h`, `Private/Tactical/SquadAIMortarPressureSubsystem.cpp`
(standalone patch: `patched/feature_mortar_pressure.patch`; already included in the cumulative set)

- **Cycle (owner spec)**: volley of **10 shells at 0.1 s intervals** on the player's position → rest → repeat. Rest = **15 s on Easy** (the stated cadence), **11 s Normal / 8 s Hard / 5.5 s Lethal**. Entry grace 15 s.
- **Reuses** `ATacticalMortarBarrageActor` (dispersion, ground snap, FX manager explosion, radial damage with falloff, suppression, AI-hearing stimulus) and the **HUD red-zone warning** (`RegisterIncomingMortarWarning`) — a 2.5 s warning window before impacts, so "run and avoid" is genuinely playable. The barrage anchors to the player's position at fire time and does not track afterward.
- Optional radio immersion: broadcasts the existing `MortarInbound` chatter line (callsign دیده‌بان) when the chatter subsystem is present.
- Pause-safe (FTimerManager game-time), menu-safe (dormant without a living player pawn), dead-safe (skips while the soldier is down), master `bEnabled` switch, every number exposed as a UPROPERTY for editor tuning.
- The player's own fire-support path (`SquadAIFireSupportSubsystem`) is untouched.

## 6. Validation

- `fixes_ALL_cumulative.patch` regenerates from `extracted/source-full` and re-applies byte-identically to all 11 patched files (`patch -p3`).
- Brace/paren balance per file unchanged vs. originals; new files balance-checked.
- ZWNJ fix is invisible by design at rest — verify in-game: `ماموریت‌ها و جبهه‌ها`, `سلاح‌ها و مهمات`, `گزارش‌های میدانی` must show half-space gaps.
- Arabic: Settings row cycles فارسی → English → العربية; HUD/menus never show Persian base strings under `ar`.
- Mortar pressure: 15 s after entry a red HUD zone + radio callout precede a 10-shell/1 s volley; interval shortens with difficulty.

## 7. Deferred backlog (status)

| Item | Status |
|------|--------|
| L2 full INI wiring of reserved localization surfaces | open |
| Pass 5 structural work (per earlier study) | open |
| Arabic translations for fallen-note bodies / radio names | open (English fallback meanwhile) |
| Leader character-swap (socket-name mapping plan, animations untouched) | postponed at owner request |
| Other AI's study notes | **never uploaded** — asked for twice; paste the text directly if the upload keeps failing |
