# Round 4 — UE 5.7 Compatibility Audit + Village Enrichment

## 1. Compile-safe audit of every Round-1..3 code change (target: UE 5.7)

Every previously patched file was re-read line-by-line and checked so that **no attribute,
variable, struct, or function used is outside Unreal Engine 5.7**.

| File | Result |
|---|---|
| `Public/Tactical/SquadAIMortarPressureSubsystem.h` | **FIXED** — declared member functions taking `APawn*` with no `class APawn;` forward declaration (certain compile error). Added `class APawn;`. |
| `QuestNativeHUD.cpp` (3,616 lines, suppression, K2 draw, reflection helpers) | Clean. `Containers/Ticker.h`, `UObject/UObjectIterator.h` + `TObjectIterator<UUserWidget>`, `IsInViewport`, `ESlateVisibility`, `GetAssetsByClass(path,…)`, `UKismetRenderingLibrary::DrawMaterialToRenderTarget` — all valid 5.7. |
| `SquadAILoadingScreenSubsystem.cpp/.h` | Clean. `FTSTicker` deferred travel, `ShouldBeLoaded/IsLevelLoaded/IsLevelVisible` on `ULevelStreaming`, `FDelegateHandle` pattern identical to pre-existing `PostLoadMapHandle`, widget re-spawn + `RegisterAllowedViewportWidget` after travel. |
| `SquadAILocalizationSubsystem.cpp` | Clean. `IConsoleManager::RegisterConsoleCommand` + `FConsoleCommandDelegate::CreateWeakLambda` + `ECVF_Default`, `UnregisterConsoleObject`, `SquadAINormalizeLang` (fa/en/ar). |
| `SoldierAIController.cpp` | Clean. `EngineUtils.h` present for the added `TActorIterator<AMissionZone>`; all-LOD `RunDirectEnemyMovement` call and the quest-zone fallback chain use only pre-existing statics (`AQuestChain::FindPreferred`). |
| `FarsiTextHelper.cpp` | Clean (pure TCHAR; ZWNJ U+200C emitted, not dropped). |
| `SquadAIMainMenuHUD.cpp/.h` | Clean (preset/alignment/text-block APIs unchanged since 4.x). |
| `SquadAIMortarPressureSubsystem.cpp` | Clean (UWorldSubsystem, timer member-function template, APawn-based dormant logic). |

Only one defect existed (the missing forward declaration above); it is fixed in place.

## 2. Village creation system — missing pieces filled + new detail

### 2a. Plumbing bugs fixed (feature existed but was dead-wired)

| Gap | Fix |
|---|---|
| `ADestroyedVillageCompoundActor::CustomVillageRubbleMesh` property exposed but **never forwarded** to buildings (`ADestroyedBuildingActor::CustomRubbleMesh` exists and works) | Forward it in `BuildVillage()` next to wall/sandbag/wood mesh forwarding. |
| `ASquadAIAutoSetupManager::GlobalRubbleMesh` was injected into standalone ruined buildings but **never into villages** | Forward `GlobalRubbleMesh → V->CustomVillageRubbleMesh` in `ApplyGlobalPalette` village loop. |

### 2b. New detail passes in `BuildVillage()` (no new assets — reuses the existing
mesh/material override system; everything falls back to `/Engine/BasicShapes/Cube`)

All new actors attach to the village root and are registered in `SpawnedBuildings`, so
`ClearVillage` / `BuildVillage` / `SnapVillageToGround` (CallInEditor) stay consistent; the
deterministic `Stream` random source keeps rebuilds reproducible.

4. **bSpawnPlazaMonument** — plaza landmark: 4-block stone well ring (~2.9 m Ø, 80 cm high,
   wall material) + broken monument column (55×55×160 cm, tilted) + its toppled cap piece
   (rubble material, walkover). Uses wall/rubble mesh overrides.
5. **bSpawnRubbleMounds / RubbleMoundCount (0–24, default 6)** — irregular war-damage mounds
   scattered 5 m–0.85 R from center, ground-snapped, rubble material; mounds ≥45 cm tall block
   movement, low ones are `NoCollision` walkovers. First real consumer of the rubble-mesh override.
6. **bSpawnStreetClutter / StreetClutterCount (0–40, default 8)** — alley dressing outside
   building doorways (650–1050 cm toward plaza): bulky crates (blocking), thin cart planks
   (walkover), roof-beam bundles (blocking); wood mesh/material.
7. **bSpawnPerimeterSandbags / PerimeterSandbagArcs (0–8, default 3)** — outer defensive arcs at
   0.78 R, three 2.3 m tangential segments each, rotated to face outward, sandbag mesh/material,
   ground-snapped per segment.

Old sections renumbered: square/encounter 4→8, cover generator 5→9.

**Extra actor budget:** ≈ 6 + 6 + 8 + 9 = ~29 static-mesh actors per 5-building village.

**5.7 guarantee for the new code:** every call used (`SpawnActor<AStaticMeshActor>`,
`GetStaticMeshComponent`, `SetStaticMesh`, `SetRelativeScale3D`, `SetCollisionProfileName`,
`SetMaterial`, `AttachToComponent`, `LineTraceSingleByChannel`, `FCollisionQueryParams`,
`FRandomStream`, `FMath::RadiansToDegrees/Clamp/Max`) already appears in the same compilation
unit — nothing outside UE 5.7.
