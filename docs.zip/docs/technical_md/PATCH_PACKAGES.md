# First code patches — L1 (localization) + B1 (UI boot behavior) — 2026-09-21

Everything below touches **only** files inside `Source/SquadAI/`. Your originals stay
untouched (keep them as backup; also the study copies in `extracted/` are pristine).
Every patch was **round-trip verified**: applied to a pristine copy of your source it
reproduces the delivered files byte-for-byte.

| Package | Defects fixed | Files changed | Patch file |
|---|---|---|---|
| **L1 — Localization harness** | P6-3 (decoy keys), P6-4 (non-writable path), P6-8 (`SquadAI.ReloadText` missing) | `Private/Localization/SquadAILocalizationSubsystem.cpp` (1 file) | `patched/localization_L1.patch` |
| **B1 — UI boot behavior** | P6-1 (menu boots wrong language/quality), P6-2 (pause menu Esc dead), P6-5 (per-frame disk re-stat) | `Private/HUD/QuestNativeHUD.cpp`, `Private/HUD/SquadAIMainMenuHUD.cpp`, `Public/HUD/QuestNativeHUD.h` (3 files) | `patched/ui_boot_B1.patch` |

---

## L1 — Localization subsystem (details in `PASS6_LOCALIZATION_INI_AUDIT.md`)

1. **`SquadAI.ReloadText` console command now actually exists** (P6-8). The header of your
   INI has always told you to type it; nothing was ever registered. Prints which file it loaded.
2. **Writable-first file lookup** (P6-4): `<Project>/Saved/SquadAILocalization.ini` is now
   searched **first** and is where the auto-generated master is written (packaged-install safe;
   `ProjectDir` was read-only territory). Your existing project-root INI keeps working as fallback.
3. **Alias bridge** (P6-3): your current INI works immediately — the old decoy names
   (`SubTitle`, `BtnStartGame`, `BtnMapSelect`, `BtnArmory`, `BtnProfile`, `BtnSettings`,
   `BtnExit`, `BtnEquipWeapon`, `BtnNextNote`, `RevivePrompt`, `FirstAidPrompt`) automatically
   map to the keys the code queries. No forced rename.
4. **Auto-generated template replaced** with the full verified live-key master
   (byte-identical to `SquadAILocalization_v2_MASTER.ini`) — never again a decoy template.

## B1 — UI boot behavior

1. **P6-1 — menu boots in the wrong language/misreports quality.** `CachedMenuSettings` was only
   filled when the Settings screen opened; until then every panel sampled the default struct
   (Persian, "Epic" preset). `BeginPlay` now caches the full saved settings struct, so an
   English save boots a fully English menu and the quality readout is correct from frame one.
2. **P6-2 — "Resume [Esc]" in the pause menu was mouse-only.** The Esc/P poll lives in the
   combat bridge, which *stops ticking while the game is paused*. `DrawPauseMenu` now handles
   Esc/P itself, exactly like the inventory's proven I/Esc handler. Safe against same-frame
   re-trigger (pause flushes key state — the same reason inventory works).
3. **P6-5 — pause menu & deployment veil hammered the disk every frame when art is missing.**
   The loose-PNG fallback stat/import now retries **once every 2 s of wall time** (world time
   freezes under pause — that's why wall clock). Mid-session art drop-ins still get picked up.

---

## How to deploy both packages

**Option A — copy the files (recommended):** from `patched/SquadAI/`, copy these 4 files over
the same paths in `<YourProject>/Source/SquadAI/` (keep your current ones somewhere as backup):
- `Private/Localization/SquadAILocalizationSubsystem.cpp`
- `Private/HUD/QuestNativeHUD.cpp`
- `Public/HUD/QuestNativeHUD.h`
- `Private/HUD/SquadAIMainMenuHUD.cpp`

**Option B — apply the patches:** from your project root:
`patch -p3 < patched/localization_L1.patch` then `patch -p3 < patched/ui_boot_B1.patch`.

Then: rebuild the module (normal workflow — **only** the SquadAI folder is touched; target files
stay as they are) and launch.

**Also drop** `SquadAILocalization_v2_MASTER.ini` into `<Project>/Saved/SquadAILocalization.ini`
(or just launch once — the game will now auto-create the full correct template there, then you
paste in your personal wording; your old project-root INI still works meanwhile).

## Quick in-engine test checklist

1. Console `~` → `SquadAI.ReloadText` → log shows OK + the file path it read.
2. Edit `GameTitle` in the INI → `SquadAI.ReloadText` → main-menu title updates live.
3. With an English save: menu boots fully English immediately (before opening Settings).
4. In game: Esc opens pause → Esc again (or P) resumes — no mouse needed.
5. Remove `UI_Frame_Tactical_PauseCard.png` temporarily, open pause → no hitching; drop the
   file back while paused → it appears within ~2 s.

*Not compiled here (no UE 5.7 toolchain in this environment) — changes are conservative and
follow patterns already present in the same files; please report any build error verbatim
and I'll correct immediately.*
