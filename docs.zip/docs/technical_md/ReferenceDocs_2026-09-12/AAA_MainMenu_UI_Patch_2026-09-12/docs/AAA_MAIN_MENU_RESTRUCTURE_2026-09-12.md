# AAA Main Menu Restructure — 2026-09-12

Owner prompt: `#1 ignore_UMG` + `#2 restructure and recreate ui in better looking style for an aaa game` based on the current main-menu screenshot.

## What changed

### 1. UMG ignored for main menu

File: `project/lidar_rostami_a_FIXED/SquadAI/Private/HUD/SquadAIMainMenuHUD.cpp`

- `ASquadAIMainMenuHUD::DrawHUD()` no longer lets `ActiveMenuWidget` suppress the Canvas HUD.
- If a legacy UMG menu instance exists, the Canvas HUD removes it and continues drawing.
- `bUseProceduralCanvasMenu` is forced true at draw time for this HUD.

Fix marker: `AAA-MM-1`.

### 2. Header and telemetry rebuilt

- Old loose title + thin line is replaced with a cinematic command-header strip.
- Top-right telemetry is now a sealed command pill instead of loose debug-style text.
- Fixed a mojibake/corrupt Persian line in the old telemetry copy.

Fix markers: `AAA-MM-2`, `AAA-MM-3`.

### 3. Main screen visually restructured

File: `ASquadAIMainMenuHUD::DrawMainMenuScreen()`

Old layout:
- left stack of same-looking long buttons,
- right loose paragraph/info area,
- weak hierarchy,
- too much empty background conflict,
- buttons looked like default black/grey bars.

New layout:
- left **Operations Command Deck** with dark scrim, title, hero CTA, numbered command rows, and readable hints;
- right **Commander Dossier / Tactical Intel Card** with avatar slot, three status chips, concise briefing, XP progress bar;
- lower-right small mission note panel;
- bottom utility rail for briefing/settings/quit with the radio waveform retained;
- cinematic left/right scrims to keep background visible but readable;
- smaller, more restrained frame accents and less full-width clutter.

Fix marker: `AAA-MM-5`.

### 4. Separate modular border PNGs now actually draw

The docs already expected `UI_Frame_TacticalBorder_Gold.png` / `Crimson.png`, but the main menu panel helper was mostly procedural-only. Added true transparent-center 9-slice support:

- New helper: `DrawNineSliceFrame(...)`
- `DrawChiseledTacticalPanel(...)` still draws the safe procedural fallback.
- If frame PNGs are installed, a final 9-slice micro-detail overlay is drawn.

Fix marker: `AAA-MM-4`.

### 5. New drop-in UI texture foundation

Generated and included under `Content/Textures/`, `project/lidar_rostami_a_FIXED/Content/Textures/`, and `art/`:

- `UI_Frame_TacticalBorder_Gold.png`
- `UI_Frame_TacticalBorder_Crimson.png`
- `UI_Frame_MedalSocket.png`
- `UI_Button_Tactical_Normal.png`
- `UI_Button_Tactical_Hover.png`
- `UI_LoadingBar_Frame.png`
- `UI_LoadingBar_Fill.png`
- `HUD_Health_Card.png`
- `HUD_Weapon_Fist.png`

The frames use transparent centers and are safe for Canvas 9-slice overlay.

## Validation

Included static validator result after edits:

```text
Scanning 230 files (111 cpp, 119 h)...
Zero brace issues found across all files!
Zero paren issues found across all files!
```

No UE engine exists in this workspace, so local UE 5.7 compile/PIE verification is still required.

## Install

1. Copy `project/lidar_rostami_a_FIXED/SquadAI/` to your local `<Project>/Source/SquadAI/`.
2. Copy `Content/Textures/*.png` to your local `<Project>/Content/Textures/`.
3. Regenerate project files if needed.
4. Build Development Editor.
5. Open the main menu map and verify:
   - no UMG menu is visible,
   - new command-deck layout appears,
   - frame PNG overlay appears on panels,
   - all buttons still click the same actions.

## Known scope

This patch restructures the **main menu screen** and upgrades the shared menu panel frame helper. Subscreens such as Map Select, Armory, Progression, Achievements, Profile, Settings, and Relics inherit the improved frames but are not fully re-laid-out yet. Recommended next pass: rebuild those subscreens into the same command-deck visual language.
