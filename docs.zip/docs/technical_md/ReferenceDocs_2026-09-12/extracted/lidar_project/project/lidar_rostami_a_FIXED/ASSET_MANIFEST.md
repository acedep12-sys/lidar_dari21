# SquadAI Project Asset Manifest & Texture Registry

This document serves as the official registry for all UI textures, tactical frames, vector SVGs, weapon previews, map theater cards, soldier profile avatars, and localization in Unreal Engine 5.7.
All assets are located in `SquadAI/Content/Textures/`. When updating an asset, overwrite the file with the matching standard name.

---

## 1. AAA Modular Tactical Frames & Borders (`SquadAI/Content/Textures/`)
| Filename | Vector Source | Target Resolution | Aspect Ratio | Status | Description |
|:---|:---|:---:|:---:|:---:|:---|
| `UI_Frame_TacticalBorder_Gold.png` | `UI_Frame_TacticalBorder_Gold.svg` | 1536×1024 | 3:2 | ✨ AAA Rebuilt | Minimalist matte obsidian & khaki gold 1px laser border with chiseled 45° tactical corner brackets (Call of Duty / Battlefield style). |
| `UI_Frame_TacticalBorder_Crimson.png` | `UI_Frame_TacticalBorder_Crimson.svg` | 1536×1024 | 3:2 | ✨ AAA Rebuilt | Minimalist matte graphite & crimson alert 1px laser border with corner telemetry crosshair brackets for active combat status cards. |
| `UI_Frame_Badge_Hexagon.png` | `UI_Frame_Badge_Hexagon.svg` | 1024×1024 | 1:1 | ✨ AAA Rebuilt | Sleek angular titanium hexagonal socket frame for weapon specialization trait icons and medals. |
| `UI_Frame_Avatar_Portrait.png` | `UI_Frame_Avatar_Portrait.svg` | 1024×1536 | 2:3 | ✨ AAA Rebuilt | Sleek military dossier ID card frame with subtle titanium corner tabs and 1px khaki gold accents for player avatars. |
| `UI_Frame_Tactical_PauseCard.png` | `UI_Frame_Tactical_PauseCard.png` | 1024×1024 | 1:1 | ✨ AAA Rebuilt | High-tech tactical military modal pause frame with titanium finish, subtle corner chevrons, and gold laser border. |
| `UI_Button_Tactical_Normal.png` | `UI_Button_Tactical_Normal.png` | 512×128 | 4:1 | ✨ AAA Rebuilt | Obsidian matte tactical button plate with gold laser chamfer accents and corner rivet tabs. |
| `UI_Button_Tactical_Hover.png` | `UI_Button_Tactical_Hover.png` | 512×128 | 4:1 | ✨ AAA Rebuilt | Highlighted tactical button with luminous amber border and active status telemetry streak. |
| `UI_LoadingBar_Frame.png` | `UI_LoadingBar_Frame.png` | 512×64 | 8:1 | ✨ AAA Rebuilt | Military carbon/titanium progress bar housing with chamfered edges, scale ticks, and laser border. |
| `UI_LoadingBar_Fill.png` | `UI_LoadingBar_Fill.png` | 512×64 | 8:1 | ✨ AAA Rebuilt | Energetic amber/gold segmented energy pulse progress fill texture with core laser highlight. |

---

## 2. Key Art Backgrounds & Cinematic Screens (`SquadAI/Content/Textures/`)
| Filename | Target Resolution | Aspect Ratio | Status | Description |
|:---|:---:|:---:|:---:|:---|
| `Menu_Background_KhuzestanDesertWar.png` | 1920×1080 | 16:9 | ✨ AAA High-Intensity | Ultra-intense cinematic battlefield action in Khuzestan with Iranian squad advancing through dust, burning tanks, dynamic fire embers, and dramatic lighting (Call of Duty / Battlefield style, zero baked-in text). |
| `Loading_Background_TrenchAssault.png` | 1920×1080 | 16:9 | ✨ AAA High-Intensity | Frontline trench assault concept art with illumination flare in night sky, sandbags, flying dirt, and squad advance in Khuzestan (zero baked-in text). |
| `UI_Background_Medals.png` | 1920×1080 | 16:9 | ✨ AAA Photorealistic | Holy Defense medals & honors command display case with velvet lining, brass trim, and tactical telemetry. |
| `UI_Background_Progression.png` | 1920×1080 | 16:9 | ✨ AAA Photorealistic | Frontline field command briefing desk with map grid, radio transceiver, field binoculars, and tactical doctrine charts. |
| `UI_Background_Armory.png` | 1920×1080 | 16:9 | ✨ AAA Photorealistic | Khuzestan field armory workshop with vintage wooden ammo crates, gunsmith tools, and G3/AK rifle maintenance benches. |
| `UI_Player_Progression_Art.png` | 1920×1080 | 16:9 | Verified | Progression relics featuring authentic chafiyeh, Holy Defense metal identity dog tag, red headband, brass compass, and casings. |
| `UI_Progression_Leadership.png` | 1024×1024 | 1:1 | Verified (1:1 Preserved) | Leadership & Command doctrine artwork with commander binoculars, Holy Defense flag, and map grid. |
| `UI_Progression_Marksmanship.png` | 1024×1024 | 1:1 | Verified (1:1 Preserved) | Precision Marksmanship doctrine artwork with scoped rifle, brass casings, and ballistic range table. |
| `UI_Progression_Endurance.png` | 1024×1024 | 1:1 | Verified (1:1 Preserved) | Frontline Endurance & First Aid doctrine artwork with field medical pouch, canteen, and combat harness. |
| `UI_Progression_Tactics.png` | 1024×1024 | 1:1 | Verified (1:1 Preserved) | Irregular Combat Tactics doctrine artwork with radio transceiver, RPG rocket harness, and smoke canisters. |
| `UI_Progression_Engineering.png` | 1024×1024 | 1:1 | Verified (1:1 Preserved) | Battlefield Engineering doctrine artwork with explosive charges, wire cutters, and sandbag fortification blueprints. |
| `UI_Military_Watermark_Emblem.png` | 1024×1024 | 1:1 | ✨ AAA Rebuilt | Dignified Iranian Holy Defense military heraldic watermark crest with olive branches, crossed G3 rifles, and brass shield. |

---

## 3. Difficulty Screen Vertical Background Cards (`SquadAI/Content/Textures/`)
| Filename | Target Resolution | Aspect Ratio | Status | Description |
|:---|:---:|:---:|:---:|:---|
| `UI_Diff_Recruit.png` | 768×1344 | 9:16 | ✨ AAA Photorealistic | Level 1: Recruit soldier in desert outpost checking compass and binoculars in warm sunrise light. |
| `UI_Diff_Regular.png` | 768×1344 | 9:16 | ✨ AAA Photorealistic | Level 2: Frontline squad advancing cautiously behind sandbags under smoke and flare illumination. |
| `UI_Diff_Hardened.png` | 768×1344 | 9:16 | ✨ AAA Photorealistic | Level 3: Intense trench artillery barrage with shockwaves, flying dust, and soldier firing RPG-7. |
| `UI_Diff_Lethal.png` | 768×1344 | 9:16 | ✨ AAA Photorealistic | Level 4: Epic commander standing atop contested earthen berm amid burning tanks and tracer crossfire. |

---

## 4. Theater & Map Previews (`SquadAI/Content/Textures/`)
| Filename | Target Resolution | Aspect Ratio | Status | Description |
|:---|:---:|:---:|:---:|:---|
| `Map_Preview_Dehlavieh_Karkheh.png` | 1920×1080 | 16:9 | Active Map (16:9 Preserved) | Dehlavieh & Karkheh River frontline theater card with trenches, earthen berms, and armored advance. |
| `Map_Preview_Bostan_Chazzabeh.png` | 1920×1080 | 16:9 | Undergoing (16:9 Preserved) | Bostan & Chazzabeh marshes theater preview with sand dunes and marsh waterways. |
| `Map_Preview_Khorramshahr_Arvand.png` | 1920×1080 | 16:9 | Undergoing (16:9 Preserved) | Khorramshahr & Arvand River urban defense theater preview in palm groves and residential streets. |
| `UI_Frame_MapTheater.png` | 1536×1024 | 3:2 | ✨ AAA Rebuilt | Minimalist matte obsidian & gold titanium map border with precision corner brackets. |
| `UI_Progression_UpgradeBar.png` | 512×128 | 4:1 | ✨ AAA Rebuilt | 3D tactical segmented upgrade meter gauge with glowing amber power cells. |

---

## 5. Period Weapon Previews (`SquadAI/Content/Textures/`)
| Filename | Target Resolution | Aspect Ratio | Status | Description |
|:---|:---:|:---:|:---:|:---|
| `Weapon_Preview_G3A3.png` | 1536×1024 | 3:2 | Verified (3:2 Preserved) | H&K G3A3 7.62mm battle rifle resting on Khuzestan trench sandbags. |
| `Weapon_Preview_AK47.png` | 1536×1024 | 3:2 | Verified (3:2 Preserved) | Kalashnikov AK-47 / AKM with wood furniture and chafiyeh on a vintage ammo crate. |
| `Weapon_Preview_RPG7.png` | 1536×1024 | 3:2 | Verified (3:2 Preserved) | RPG-7 anti-tank rocket launcher with PG-7V warhead in frontline trench position. |
| `Weapon_Preview_MG3.png` | 1536×1024 | 3:2 | Verified (3:2 Preserved) | MG3 7.62mm general-purpose machine gun mounted on bipod in sandbag bunker with ammo belt. |
| `Weapon_Preview_SVD.png` | 1536×1024 | 3:2 | Verified (3:2 Preserved) | SVD Dragunov sniper rifle with authentic wood stock and PSO-1 scope on chafiyeh in camouflage hide. |

---

## 5. Soldier Profile Avatars (`SquadAI/Content/Textures/`)
| Filename | Target Resolution | Aspect Ratio | Status | Description |
|:---|:---:|:---:|:---:|:---|
| `UI_Avatar_ShahidRostami.png` | 1024×1024 | 1:1 | ✨ Authentic Sacred Defense | Heroic Iranian squad commander (Major Shahid Iraj Rostami) with short trimmed beard, authentic olive jacket, black-and-white keffiyeh scarf, metal dog tag, and resolute warrior gaze. |
| `UI_Avatar_YoungBasiji.png` | 1024×1024 | 1:1 | ✨ Authentic Sacred Defense | Young Iranian volunteer frontline fighter with red cloth headband, keffiyeh scarf, and authentic olive combat jacket. |
| `UI_Avatar_ArteshParatrooper.png` | 1024×1024 | 1:1 | ✨ Authentic Sacred Defense | Elite Iranian commando paratrooper with camouflage scrim helmet, short rugged beard, olive jacket, and keffiyeh scarf. |
| `UI_Avatar_GuerrillaHunter.png` | 1024×1024 | 1:1 | ✨ Authentic Sacred Defense | Irregular warfare tank hunter with full rugged beard, tactical wool watch cap, combat goggles, and RPG rocket harness. |

---

## 6. Weapon Speciality Trait Badges (`SquadAI/Content/Textures/`)
| Filename | Vector Source | Target Resolution | Aspect Ratio | Status | Description |
|:---|:---|:---:|:---:|:---|:---|
| `UI_Trait_TankDestroyer.png` | `UI_Trait_TankDestroyer.svg` | 512×512 | 1:1 | ✨ AAA Rebuilt | RPG-7 shaped-charge rocket piercing armored vehicle plate with supersonic shockwaves. |
| `UI_Trait_HeavyCaliber.png` | `UI_Trait_HeavyCaliber.svg` | 512×512 | 1:1 | ✨ AAA Rebuilt | 7.62mm heavy brass cartridge with penetrating supersonic shockwave rings. |
| `UI_Trait_DesertReliability.png` | `UI_Trait_DesertReliability.svg` | 512×512 | 1:1 | ✨ AAA Rebuilt | Desert whirlwind sandstorm vortex protecting rifle bolt carrier. |
| `UI_Trait_AreaSuppression.png` | `UI_Trait_AreaSuppression.svg` | 512×512 | 1:1 | ✨ AAA Rebuilt | Machine gun muzzle in left quadrant firing forward tracer barrage downrange. |
| `UI_Trait_SilentMarksman.png` | `UI_Trait_SilentMarksman.svg` | 512×512 | 1:1 | ✨ AAA Rebuilt | Precision PSO-1 graduated reticle with stadia lines and knurled brass turret ring (no birds/animals). |

---

## 7. In-Game HUD Weapon Silhouette Icons (`SquadAI/Content/Textures/`)
| Filename | Target Resolution | Aspect Ratio | Status | Description |
|:---|:---:|:---:|:---:|:---|
| `HUD_Weapon_G3A3.png` | 512×256 | 2:1 | ✨ High-Res Silhouette | Clean white silhouette vector of G3A3 battle rifle for top-right tactical status plate. |
| `HUD_Weapon_AK47.png` | 512×256 | 2:1 | ✨ High-Res Silhouette | Clean white silhouette vector of AK-47 assault rifle for top-right tactical status plate. |
| `HUD_Weapon_RPG7.png` | 512×256 | 2:1 | ✨ High-Res Silhouette | Clean white silhouette vector of RPG-7 launcher with PG-7V warhead. |
| `HUD_Weapon_MG3.png` | 512×256 | 2:1 | ✨ High-Res Silhouette | Clean white silhouette vector of MG3 machine gun with bipod and ammo drum. |
| `HUD_Weapon_SVD.png` | 512×256 | 2:1 | ✨ High-Res Silhouette | Clean white silhouette vector of SVD Dragunov sniper rifle with PSO-1 scope. |
| `HUD_Weapon_Unarmed.png` | 512×256 | 2:1 | ✨ High-Res Silhouette | Clean white graphic silhouette of tactical hand-to-hand combat knife. |

---

## 8. Tactical Military Backpack & Inventory Items (`SquadAI/Content/Textures/`)
| Filename | Target Resolution | Aspect Ratio | Status | Description |
|:---|:---:|:---:|:---:|:---|
| `UI_Item_PocketQuran.png` | 1024×1024 | 1:1 | ✨ Photorealistic AI Generated | Small pocket-sized Holy Quran with gilded embossed green leather cover carried by frontline defenders into battle. |
| `UI_Item_PocketRadio.png` | 1024×1024 | 1:1 | ✨ Photorealistic AI Generated | Vintage 1980s military pocket transistor radio with rotary tuning dial, metal speaker mesh, and antenna. |
| `UI_Item_CombatWallet.png` | 1024×1024 | 1:1 | ✨ Photorealistic AI Generated | Rugged leather military ID wallet with wartime soldier identification card, blood type tag, and personal memorabilia. |
| `UI_Item_FirstAidPouch.png` | 1024×1024 | 1:1 | ✨ Photorealistic AI Generated | Olive canvas individual first aid trauma pouch with medical cross insignia and tactical webbing straps. |
| `UI_Item_Canteen.png` | 1024×1024 | 1:1 | ✨ Photorealistic AI Generated | Vintage military aluminum canteen water flask with olive drab canvas insulated cover and screw-top cap. |
| `UI_Item_DogTag.png` | 1024×1024 | 1:1 | ✨ Photorealistic AI Generated | Historical 1980s Iranian military aluminum identification dog tag on ball chain with etched Persian numbers and text. |
| `UI_FallenNotes_Background.png` | 1024×1024 | 1:1 | ✨ Photorealistic AI Generated | Aged wartime field notebook parchment with sacred defense handwritten poetry and field notes texture. |

---

## 9. External Notepad-Editable Localization Config (`SquadAILocalization.ini`)
- **Location**: `SquadAILocalization.ini` in the project root (also searched under `Config/` or `Content/Localization/`).
- **Format**: Standard UTF-8 INI file. Any text in the game can be opened and edited directly in Windows Notepad:
  - `[MainMenu]`: Game title, subtitles, button labels, copyright notices.
  - `[MapSelection]`: Map titles, status badges, mission situation briefings.
  - `[Armory]`: Weapon names, descriptions, and ballistic rating labels.
  - `[Traits]`: Speciality trait names and descriptions.
  - `[Profile]`: Callsigns, ranks, and combat statistics labels.
  - `[Loading]`: Sector loading titles, loading descriptions, combat tips, Enter prompt.
  - `[HUD]`: Squad leader name, ally prefixes, interaction prompts, key hints.
  - `[PauseMenu]`: Pause titles, Resume, Save Game, Restart, Quit button labels, success/failure notifications.
- **Console Command**: `SquadAI.ReloadText` or `ReloadLocalization` reloads all texts in real time without restarting the game.

---

## 9. Unreal Engine Auto-Import Configuration (`DefaultEditorPerProjectUserSettings.ini`)
Unreal Engine does not import `.svg` vector files natively (it expects `.png`, `.tga`, or `.jpg`). All SVGs have been pre-rasterized to PNGs in `SquadAI/Content/Textures/`.
To have Unreal Engine automatically import all `.png` files without dragging and dropping:
1. `DefaultEditorPerProjectUserSettings.ini` is placed in `Config/DefaultEditorPerProjectUserSettings.ini`.
2. Directory monitoring is configured to watch `SquadAI/Content/Textures/` and mount directly to `/Game/Textures/`.
3. When you open the project in Unreal Engine Editor, UE automatically imports all textures!

---

## 10. Asset Diagnostic & Audit Command
- **Console Commands**: `SquadAI.CheckAssets`, `CheckAssets`, `AuditTextures`, `AuditGameAssets`.
- **Log Tag**: `[SQUADAI_ASSET_AUDIT]` — Type this keyword in the Unreal Engine Output Log search bar to immediately see which textures and icons were found and which are missing!

---

## Batch 3 field-slate override (2026-09-12)

The current active workspace has been patched directly, not just as a zip patch. For Progression/Profile/Achievements, these generated PNGs supersede older gold/brass descriptions elsewhere in this manifest:

- `UI_Background_Progression.png` — 1920×1080 opaque field-slate doctrine board.
- `UI_Background_Medals.png` — 1920×1080 opaque dark honors case, no baked frames.
- `UI_Player_Progression_Art.png` — 1024×576 compatibility doctrine artwork.
- `UI_Frame_Badge_Hexagon.png` — 256×256 transparent-center socket.
- `UI_Frame_Avatar_Portrait.png` — 512×512 transparent-center dossier portrait frame.
- `UI_Military_Watermark_Emblem.png` — 512×512 abstract date-palm/dome field emblem.
- `UI_Trait_*` and `UI_Progression_*` icons — 256×256 field-slate procedural fallbacks.
- `UI_Avatar_*` portraits — 512×512 stylized placeholder fallbacks; final owner-approved portraits may replace them later.

The Batch 3 UI code markers are `AAA-B3-0` through `AAA-B3-3` in `SquadAI/Private/HUD/SquadAIMainMenuHUD.cpp` and `ActiveProgressionInspectIdx` in the HUD header.
