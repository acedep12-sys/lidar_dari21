# SquadAI / lidar_rostami1222 — consolidated static review

**Review target:** Unreal Engine 5.7
**Review date:** 2026-09-09
**Reviewed archive:** `repo_inspect/lidar_rostami_a_FIXED/`

## Executive decision

The archive contains a substantial Unreal C++ gameplay module, but it is not a buildable or runnable UE project as delivered. The repository's `main` branch exposes `mywww.zip`; the extracted archive contains source/configuration/generator files but no `.uproject`, target files, Content directory, maps, generated headers, or the external TPWCS pack. Therefore this review is source-complete for the supplied archive, but it is **static only**: no UE 5.7 compile, UHT pass, PIE test, packaged build, asset audit against real assets, or network/multiplayer test was possible.

Before adding more gameplay features, establish one authoritative runtime project and repair the compile blockers and cross-system authorities below. The biggest product risk is not missing polish; it is that health, death, combat, quest completion, difficulty, audio, and diagnostics currently have overlapping ownership.

## Coverage

The source review covered the module/build bootstrap, characters and health, weapons and TPWCS bridges, AI controllers/StateTree tasks, team/cover/significance/registries, quest chains and mission zones, wave spawners, save/load, progression/inventory, menu/loading/HUD/localization, audio manager/subsystem, cinematic combat, fire/FX/weather/building systems, difficulty, developer diagnostics/cheats, and the generated tactical asset pipeline/configuration files.

## Release blockers (P0)

### P0-1 — The delivered archive cannot be built or run as a UE project

**Evidence:** archive root has no `.uproject`, `Source`/target definition, `Content`, maps, generated headers, or external pack source. `SquadAI.Build.cs` and `IMPLEMENT_PRIMARY_GAME_MODULE` are present, but they are not sufficient to create a runnable project.

**Impact:** every runtime claim remains unverified; Blueprint references and hard-coded `/Game/...` paths cannot be resolved; the intended player/enemy pack integration cannot be tested.

**Correction:** recover or create the UE 5.7 host project first, import the actual Content/maps and external pack, then run UHT + Development Editor build before changing gameplay behavior.

### P0-2 — Confirmed C++ compile error: duplicate switch case

`SquadAI/Private/Performance/SquadAIAudioSubsystem.cpp:549-559` contains `case ETacticalVoicelineType::Command_Hold` twice in the same switch. This is a hard compiler error, not a runtime warning.

**Correction:** keep one case and add a dedicated hold-voiceline array or an intentional fallback.

### P0-3 — Confirmed C++ access error in save restoration

`SquadAI/Private/SaveSystem/SquadAISaveLoadSubsystem.cpp:417` calls `Chain->StartMissionAtIndex(SavedActive)`, while `StartMissionAtIndex` is declared under `private:` in `SquadAI/Public/Quest/QuestChain.h:99-105`. There is no friend declaration.

**Impact:** save/load cannot compile until the API is redesigned.

**Correction:** expose a narrow public `RestoreMissionState(...)` operation on `AQuestChain`; do not make internal indexing generally public.

## Critical cross-system correctness findings (P1)

### P1-1 — Three competing damage/death authorities

The module has at least three damage paths:

1. `UHealthComponent` + `ASoldierCharacter::HandleDeath()`;
2. TPWCS reflected health synchronization;
3. the auto-attached `USquadAIPlayerCombatBridge`.

The bridge correctly routes SquadAI soldiers through `HealthComp->ApplyDamage()` (`SquadAIPlayerCombatBridge.cpp:484-516`), but `DamagePackEnemy()` directly writes `currentHealth`/`Health` (`:519-613`) and manually simulates ragdoll. That bypasses pack damage events, AI stimuli, quest/wave death registration, death delegates, kill attribution, health UI contracts, and any external pack death lifecycle. The reflection fallback repeats the same problem.

**Symptoms/reproduction:** shoot a TPWCS enemy through the bridge; compare reflected HP, pack health UI/events, quest alive-enemy count, wave completion, registration, and death/ragdoll state. A hit can visually kill an enemy without the mission knowing it died, or leave pack and SquadAI representations out of sync.

**Correction order:** define `ISquadAIDamageReceiver`/adapter semantics first; route every hit through one `ApplyDamage -> OnDamaged -> OnDowned/OnDied` contract; use a pack-specific adapter that invokes the pack's public damage/death API rather than mutating reflected properties.

### P1-2 — The player combat bridge is active by default in ordinary runtime

`USquadAIPlayerDiagnosticSubsystem` defaults `bAutoAttachDiagnostic = true` and, in `Tick()` (`SquadAIPlayerDiagnosticSubsystem.cpp:120-173`), attaches both `USquadAIPlayerWeaponDiagnostic` and `USquadAIPlayerCombatBridge`. This is not gated by editor/development build in the supplied source.

**Impact:** a developer wall-check workaround and a second custom trace/input/damage system alter shipped gameplay automatically. It can fight the external weapon component, consume input keys, generate duplicate effects, and change weapon balance.

**Correction:** make production combat explicitly selected by the player pawn/game mode; gate diagnostics and cheats with `UE_BUILD_DEVELOPMENT`, editor-only config, or a dedicated developer subsystem. Do not let a diagnostic subsystem own production combat attachment.

### P1-3 — Difficulty does not propagate to future spawns or travel worlds

`UDifficultySubsystem` is a GameInstance subsystem and persists `CurrentDifficulty`, but `SetDifficulty()` only iterates soldiers in the current world (`DifficultySubsystem.cpp:28-80`). `AEnemySoldier::BeginPlay()` and `AAllySoldier::BeginPlay()` then restore tuning defaults on every new spawn/travel.

**Symptoms/reproduction:** choose Easy/Hard in the menu, travel to a map, spawn a wave or use the dev spawn; inspect `WeaponComp` accuracy/damage and ally `PowerLevel`. Newly created soldiers use defaults instead of the selected difficulty.

**Correction:** store a difficulty profile independent of the world and apply it in a common soldier registration/spawn hook. `SetDifficulty()` should update the profile and existing actors; `RegisterWithSystems()`/registry registration should apply it to every new soldier. Save/load should use the same path.

### P1-4 — Last-enemy cinematic is wired with impossible input

`SoldierCharacter.cpp:823-830` always calls `NotifyEnemyEliminated(this, false, false)`. The cinematic subsystem only triggers when `bWasLastEnemyInArea` is true (`SquadAICinematicCombatSubsystem.cpp:63-70`), so the last-kill moment can never fire from this hook.

**Correction:** the encounter/mission/wave owner must determine the final hostile after authoritative death registration, then call a single `OnEncounterCleared`/cinematic event. Do not infer encounter completion inside an individual soldier.

### P1-5 — Slow-motion duration is scaled in the wrong direction

`TriggerCinematicHeroMoment()` sets global dilation and schedules a world timer for `Duration * Dilation` (`SquadAICinematicCombatSubsystem.cpp:40-43`). With a dilated timer, this shortens the real-time slow-motion interval rather than preserving the requested real-time duration.

**Correction:** explicitly decide whether duration is world time or real time. For real-time duration, use a real-time timer or convert according to the engine timer/dilation semantics and test at 0.1, 0.25, and 0.5 dilation.

### P1-6 — Loading screen is a flash, not a persistent transition

`StartDeploymentTransition()` creates a widget, broadcasts shown, and immediately calls `UGameplayStatics::OpenLevel()` (`SquadAILoadingScreenSubsystem.cpp:101-122`). `MarkLoadingComplete()` has no caller anywhere in the module. The GameInstance subsystem can retain `bIsLoading`/a stale widget reference across travel, while the viewport widget belongs to the old world.

**Correction:** use a GameInstance-owned transition layer or movie/loading screen that survives travel; add a destination-world `BeginPlay`/GameMode handshake to call completion; handle cancellation, failed map load, and player-confirmation mode explicitly.

### P1-7 — Main-menu button ID 10 makes Tactical Briefing unreachable from the main screen

The main screen registers ID 10 for the profile header (`SquadAIMainMenuHUD.cpp:1069`) and also ID 10 for the bottom Briefing button. `ProcessClickAtMousePosition()` dispatches every ID 10 click as profile when `MenuState == Main` (`:2769-2778`). The bottom Briefing button therefore navigates to the profile, not briefing.

**Correction:** use unique IDs or, preferably, an enum/action payload instead of a large integer namespace. Add click tests for every menu state and button.

### P1-8 — UMG quest HUD does not drive its minimap or compass

`UQuestHUDWidget::OnHudUpdated()` updates the briefing widget but contains only comments for minimap and compass updates (`QuestHUDWidget.cpp:58-72`). `UMissionMinimapWidget::DrawCompassMarkers()` is also an empty placeholder (`MissionMinimapWidget.cpp:190-197`). This leaves a parallel native `QuestNativeHUD` and incomplete UMG HUD with no single presentation owner.

**Correction:** put objective center/radius/heading in the HUD snapshot, bind the snapshot to minimap/compass, and choose one operational HUD architecture. Add a visible in-map test that verifies objective changes, player movement, rotation, and mission completion.

### P1-9 — SceneDecorator defaults every decoration entry into a fire hazard

`ASceneDecorator::bEnableFireDamage` defaults true. `BuildDecoration()` uses `bEnableFireDamage || Entry.bFireDamage` (`SceneDecorator.cpp:505-515`), so visual-only entries receive hurt boxes. It also uses the actor-level `FireDamagePerSecond` instead of `Entry.FireDamagePerSecond` (`:514`), making per-entry tuning ineffective.

**Impact:** unexpected damage volumes, excessive hurt-box count, incorrect DPS, and expensive polling in decorated areas.

**Correction:** default global fire damage off; only spawn a hurt box when the entry is explicitly hazardous; use the entry's radius/DPS and aggregate overlapping zones before applying damage.

## Important audio issues (P1/P2)

- Mission success/failure can play a stinger in `PlayTacticalVoiceline()` and then play the same manager stinger again through `SetAudioGameState(Victory/Defeat)`. Pick one ownership path.
- `PlayTacticalVoiceline()` returns immediately when no audio manager is registered, so the tuning/default fallback is not used for voicelines even though music has fallback logic.
- `UpdateCrossfade()` fades the old track using the new `TargetMusicVolume`; a state/volume change during a crossfade can make the old track fade from the wrong level.
- `SquadAITPWCSVisualsComponent::PlayShotVisuals()` can spawn both Cascade and Niagara versions of muzzle flash/trail/impact when both are assigned (`:200-249`) and does not route those spawns through the FX budget manager. This can double every shot's visual cost.

## Quest, lifecycle, and persistence risks

- Enemy death currently unregisters the soldier before the cinematic/quest ownership can determine encounter completion. The wave/mission owner must receive exactly one authoritative death notification and compact weak references.
- `AEnemySoldier::BeginPlay()` resets health/tuning defaults; any spawn pool or wave reuse path must apply difficulty and per-encounter tuning after registration, not only in the constructor/BeginPlay default path.
- Save restoration is structurally on the correct post-travel path (`SchedulePostTravelApply()`), but it currently depends on the private quest API noted above. It also directly writes mission state, so the eventual public restore API must suppress duplicate completion rewards/events.
- Multiple systems write health and revive/downed state directly. Save/load, fire damage, player combat, `HealthComponent`, and pack bridges must share a documented invariant for current health, max health, dead, downed, ragdoll, and registration.

## Performance and production-safety findings

- `USquadAIDevDebugSubsystem::Initialize()` calls the full texture audit unconditionally (`SquadAIDevDebugSubsystem.cpp:26-30`), performing repeated safe-load attempts for a large asset list on every applicable world. Gate it and run on demand or only in development/editor.
- The player diagnostic wall fix rechecks reflected properties on a repeating timer and attaches diagnostic code at runtime. This belongs in a development-only adapter or explicit compatibility profile.
- Battlefield/decorative systems can create large numbers of Niagara, Cascade, mesh, fire-volume, ambient-volume, and decal components. Enforce per-class budgets, finite lifetimes, pooling/reuse, and destruction on mission/world teardown. The FX subsystem's budget is not a license for direct spawners to bypass it.
- Avoid per-world asset probing in constructors/initialization for production. Resolve required assets through cooked references/soft paths during an explicit prewarm phase and report missing assets once.

## Localization/UI findings

- The hand-written Farsi renderer shapes glyphs, skips ZWNJ, and then performs a simplistic token reversal. It is fragile for mixed Persian/English, punctuation, numbers, diacritics, and longer text. It also does not consistently convert formatted ASCII digits to Persian digits in the canvas path.
- Language switching changes menu presets, but the localization subsystem is a small custom INI parser and its language change does not automatically refresh already-created world widgets. Use UE localization/FText or a central language-changed event and rebuild/rebind UI.
- The menu draws English labels through the same `DrawFarsiText` functions; mixed RTL/LTR layout should be tested at the actual font/viewport sizes.

## Recommended correction order

1. Recover/create the UE 5.7 host project, target files, Content/maps, and external pack; verify all `/Game/...` paths.
2. Fix the two confirmed compile errors, regenerate headers, and run UHT + Development Editor build.
3. Define the authoritative contracts: damage/death, soldier registration, quest completion, difficulty profile, and player combat ownership.
4. Disable automatic diagnostics/combat injection in production; make the intended weapon path explicit.
5. Repair save/load through a public quest restore API and post-travel handshake.
6. Apply difficulty at registration/spawn and add automated tests for menu -> travel -> wave spawn.
7. Fix encounter-owned last-kill detection and time-dilation timing.
8. Fix loading transition, menu actions, and HUD objective binding.
9. Gate asset audits/cheats, centralize FX/audio budgets, and fix fire hazard defaults.
10. Replace or isolate the custom Farsi renderer, then balance weapons, AI, waves, and cinematic/audio polish.

## Minimum acceptance tests after the host project is restored

- Editor opens with no UHT/compiler errors and no missing generated headers.
- Main menu: every button reaches its intended state; Briefing and Profile are distinct; difficulty survives travel.
- Load a save on another map: player, mission, allies, supplies, ammo, equipped weapon, and difficulty restore once without duplicate rewards.
- Spawn an enemy wave after selecting each difficulty; verify damage, accuracy, health, registration, and wave completion.
- Shoot one SquadAI enemy and one pack enemy; verify the same damage/death/quest/AI/UI contract and exactly one death event.
- Clear an encounter: exactly one last-kill event, correct slow-motion real-time duration, one victory stinger, and restored dilation on interruption/travel.
- Enter/leave a single fire volume: expected DPS, no double damage, no unexpected fire boxes on non-fire decorations.
- Open UMG HUD: current mission, objective marker, compass, minimap, briefing, timer, and completion state all update from one snapshot.
- Run a 30-minute combat stress test: FX/audio budgets reset, no stale decals/components, no unbounded diagnostics or asset loads.

## Validation limitation

The repository's `validate_codebase.py` was executed, but it scanned `0 files` because its hard-coded source path is stale. Its zero-error result is not source validation. No source files were changed during this review.
