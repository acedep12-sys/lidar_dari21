# STEP 5 — Missions: Quest Chain, Spawners/Waves, Scene Dressing, Weather, Barrage (DETAILED)

Read: all of `SquadAI/Public+Private/Quest/**` (42 files, ~9,727 lines). Biggest: SceneDecorator.cpp 1618,
MissionZone.cpp 1047, SplinePathActor.cpp 700, PathExplosionBarrage.cpp 612, EnemyWaveSpawner.cpp 521,
AtmosphericDustScatterer.cpp 485.

**Key architectural fact: TWO parallel mission systems + TWO parallel spawner systems exist.**
Which one is "live" depends on what the level designer placed. See §7.

---

## 1. System A — MissionZone + QuestChain (zone/trigger-driven, gameplay + XP)

### 1.1 AMissionZone (1047) — one mission point in the world
- Types: **Reach** (player enters trigger), **Clear** (kill all linked-spawner enemies), **Defend**
  (survive `DefendDuration`, default 60s, waves re-triggered every `DefendWaveInterval` 15s).
- States Locked → Active → Completed/Failed; delegates `OnMissionStateChanged`, `OnMissionProgressUpdated`
  (progress broadcast throttled to >0.5% change). Custom Farsi badge text override.
- Tick 0.5s, only while Active: Reach = event-only; Clear = event-driven via spawner delegates with Tick
  as safety net (`bEventDrivenClearCheck`); Defend = countdown in Tick → CompleteMission.
- **Clear completion**: syncs counts from linked spawners on every death event; completes when all spawners
  `bCompleted` + 0 alive + >0 spawned. No spawners → completes immediately.
- **Player death → infinite retry**: `OnPlayerDied` → `RestartCurrentAttempt` (wipe spawners, `RespawnSquad`,
  0.75s → `FinishRestartAttempt` replays waves with original counts). ⚠️ Nothing ever calls `FailMission`
  internally — missions **cannot fail on their own** (Bugs §8.1).
- Death detection: SquadAI `OnDeath` delegate, else finds pack `OnDeath` (reflection, informational only),
  else **0.15s poll timer** reading pack `currentHealth` via cached `BPC_Health` component.
- `RevivePawnAt`: clears lifespan, re-possess, capsule/movement/mesh/anim reset, teleport, HealthComp Revive,
  AI memory reset + StateTree restart, `RestorePackHealth` (reflection: max→current, bIsDead=false),
  player input re-enable + `ResetPlayerAmmo` (reflection on `BPC_WeaponCharacter`: per-weapon clip/reserve maps).
- `RespawnSquad`: player at trigger (or saved loc for Reach); leader −280 fwd; allies V-formation rows behind.
- Audio: per-mission music overrides (ambient/combat/climax/horde) + `NotifyMissionStateChanged/Progress` to audio sys.
- Completion awards **800 XP** via `AwardQuestCompletionXP(GetFName())`.
- ⚠️ `DefendTimerHandle` is cleared 4× but **never SetTimer** — countdown actually runs in Tick (Bugs §8.2).

### 1.2 AQuestChain (304) — ordered MissionZone sequencer
- `Missions` array (auto-discovers + sorts by `MissionIndex` if empty); `bAutoStart` + `StartDelay`.
- Global `GQuestChains` registry; `FindPreferred(world, activeOnly)` — O(chains), used by Spline/Barrage/HUD.
- Failure: `bRestartChainOnFailure` → whole chain else reset + 1s retry of current mission. ⚠️ Dead path —
  unreachable since FailMission is never called (Bugs §8.1).
- Chain completion: **1500 XP "Theater Operation Victory"** + `DehlaviehDefender` achievement progress.
- `SpawnLeaderSplinePath()` — CallInEditor helper that drops a spline actor wired to Missions[0].

## 2. System B — QuestMission + QuestDirector (tag/objective-driven, HUD-visible)

- **AQuestMission** (163): ordered `Objectives` (instanced UObjects) + title/order/timer/music/briefing/RTL flag.
  No tick — ticked at **4Hz by QuestTickerSubsystem**. Timer expiry → Fail. `GetHudSnapshot` pulls live
  `EnemiesRemaining` via `CountHostilesNear(loc, 999999, team0)`. Music: SpawnSound2D + 2s fade-in / 1.5s fade-out.
- **Objectives** (114): base `UQuestObjective` (OnStart/Tick/OnFinish). Only subclass: `AutoZone` —
  OnStart: resolves `ZoneTag` via QuestRegistry, sets **GPS beacon** `CurrentActiveGoal`, **force-pushes**
  `FSquadAIMoveCommand{QuestGoal, 500 accept}` to ALL team-0 AI (registry first, TActorIterator fallback).
  Tick: player-in-zone → Succeed; fallback: any living ally within 600cm of goal → Succeed.
  ⚠️ `ResolveMode` **hardcodes Reach** — Defend/Clear modes, `MaxSecondsOutsideZone`, `InitialHostileCount`
  are all non-functional (Bugs §8.3).
- **AQuestDirector** (103): auto-discovers missions (level-wide or outliner-attached), stable-sorts by `Order`,
  auto-starts after 1s, 3s gap between missions.
- **QuestTickerSubsystem** (122, tickable world subsystem): `IsTickable` true only until director search resolves
  once — then a 0.25s timer ticks the active mission + broadcasts `OnHudUpdated(FQuestHudSnapshot)`.
  Zero cost on non-quest maps. ⚠️ Only handles **Succeeded** — Failed missions stall the chain silently (Bugs §8.4).
- **QuestRegistry** (50): O(1) `FQuestTag → actor` map + `CurrentActiveGoal` GPS beacon.
- **QuestLog** (89, game-instance subsystem): mission history + `ToBytes/FromBytes` save serialization.
  ⚠️ `RecordMission` is **never called** — log always empty (Bugs §8.5).
- **QuestValidator** (151): non-shipping only; 0.5s after BeginPlay checks: directors>1, missions without
  objectives, duplicate Orders, AutoZone tags matching a registered zone, AutoSpawnZone enemy class/points.
  Errors = red on-screen 30s + log. Silent on non-quest maps.

## 3. Spawners & waves

### 3.1 AEnemyWaveSpawner (521) — the X/Y/Z spawner (used by MissionZone)
- Config: X=`EnemiesPerWave` 5, Y=`SpawnIntervalSeconds` 1s, Z=`MaxWaves` 3 (0=infinite), `DelayBetweenWaves` 5s,
  `bLoopWaves` (Defend), `SpawnRadius` 500, `MaxAliveEnemies` 15 (waits when capped), `bOneShot`, `bAutoActivate`,
  `LinkedTrigger`, `EnemyClass` (default AEnemySoldier), `bEnableFireteam` (0.25s-delayed `RegisterMember`,
  TeamKey = spawner UniqueID).
- Spawn flow: pool `Acquire` → fallback SpawnActor (Owner=this); bind death (SquadAI delegate, else polling);
  `SpawnDefaultController` if missing; per-spawn timer chain; fail-safe increment (no infinite loop).
- Wave completion = all *spawned* (not killed) → delay → next wave; all waves → `bCompleted` + event.
- `CleanupDeadEnemies`: SquadAI via `IsAlive`; **pack enemies via `BPC_Health` reflection poll** (double/float
  currentHealth≤0 → unregister + batched `OnSpawnerEnemyDied` broadcast after loop).
- `ResetSpawner`: destroys tracked + any Owner==this pawns (TActorIterator sweep), unregisters fireteam, resets all.
- Death → corpse linger (`CorpseLingerSeconds` tuning) → `Pool->Release` else Destroy.

### 3.2 AWaveSpawner (286) + UWaveTemplate + AAutoSpawnZone — the parallel template system
- DataAsset `UWaveTemplate`: `TArray<FWaveDefinition>` + default class; `GetTotalEnemyCount`.
- `AWaveSpawner`: per-wave delay → **batched spawning** (`BatchSize`, `SecondsBetweenBatches`), round-robin
  spawn points (MakeEditWidget **local coords → world transform** — documented fix), ±200 jitter, NavMesh project;
  pool-first spawn; per-enemy: coordinator `AddEnemy`, fireteam `RegisterMember(UniqueID)`, death delegate;
  death-driven `CachedLiving` (O(1)), auto-compact stale refs at 2× living + 10; wave-cleared → next; all → event.
- `AAutoSpawnZone` (134): one drop = QuestZone + WaveSpawner + AttackCoordinator + N ring spawn points
  (auto-tagged `<Tag>_Spawner`), editor arrow previews via `OnConstruction`.
- ⚠️ Reachable **only** via placed AutoSpawnZone; MissionZone/QuestChain path uses EnemyWaveSpawner exclusively.
  Two spawner stacks to maintain (Bugs §8.6).

### 3.3 UEnemyPoolSubsystem (209) — pre-warmed pooling
- `Prewarm(class, N)` spawns hidden at (0,0,−10000); `Acquire` O(1); `Release` sleep+available.
- Sleep: hide, no collision, no tick, abort pathing, disable movement, reset health (keeps controller possessed).
- Wake: teleport, unhide, collide, tick, StateTree start/restart, walking mode, ragdoll-off, capsule on, health reset.
- ⚠️ **`Prewarm` is never called anywhere** → pool always empty → every Acquire misses → all spawners always
  SpawnActor. The entire pooling/GC optimization is dormant; `Release` calls no-op (Bugs §8.7).

### 3.4 Triggers & zones
- **ASpawnerTrigger** (112): box trigger (player-controlled pawn + optional team filter) → activates N linked
  spawners; one-shot default, optional self-destroy; editor plane visual. Two-way link (spawner also AddUnques).
- **AQuestZone** (127): self-registering box/sphere overlap volume; tracks `ActorsInZone`; `IsPlayerInZone`,
  `CountHostilesInZone`/`GetHostilesInZone` (SquadAI-only cast!), center/radius for minimap.

## 4. Leader pathing — ASplinePathActor (700)
- Designer-sculpted trench corridor: `ToMission` (explicit) / `FromMission` gate / legacy `TriggerMission` /
  `bFreeWill` (opt-out) / corridor 400 / look-ahead 700 / wander 160 / accept 200 / nearby fallback 3500.
- `FindGuide` (static): 0.35s + 250cm-move cache; explicit match beats nearby (+50000 penalty); TActorIterator
  fallback if BeginPlay hasn't registered yet; PATHDBG logging throughout.
- `EvaluateMatch` rules: skip freewill/short-spline (<150cm)/from-not-done; nearby rule requires curve to lead
  toward mission (endpoint-distance test or tangent alignment >0.15).
- `GetSoftFollowLocation`: monotonic walk toward goal end (auto-sign), ≥650 look-ahead, returns FinalGoal near end.
- `GetFollowLocationSkipping`: walks up to 24×140cm further along spline to clear hazard circles (+Z 180 check).
- `GetCorridorSlotLocation`: allies staggered behind leader (row = slot/2+1, alternating sides, ≤160 lateral).
- Legacy `bMarchAlongSpline` conveyor (allies dragged to single progress point — header says leave OFF).
- Editor: `PostEditChangeProperty` one-shot enemy spawn/remove along spline; debug corridor draw; `DumpDebugNow`.

## 5. Battlefield dressing & damage

### 5.1 ASceneDecorator (1618) — scatter + fire-damage core
- **Build**: `FDecorationEntry` (Niagara/Cascade/Mesh/Both, count, spacing, radius, scale/rot, cull distances,
  per-entry fire damage). RebuildNow/ClearAllNow/DumpDebugNow (CallInEditor) + legacy bool triggers.
  Editor worlds spawn **immediately** (gameplay timers don't tick in editor); game worlds stagger by `SpawnDelay`.
  Placement: rejection sampling (count×20 attempts), min-spacing 2D check, ground snap with **triple fallback**
  (WorldStatic → Visibility → WorldDynamic — Landscape/WP note), fire-hurt-box per instance (radius clamp >220→180).
- Components spawned as **instance components** (survive PIE/WP), tracked in arrays; Clear destroys + sweeps
  leftover tagged spheres. `TotalSpawnedCount` runtime stat.
- **Fire damage**: 0.25s poll timer (+tick backup); player inside any tagged sphere (2D ≤ radius, ΔZ ≤ 180) →
  `ShowBurnEffect` (native HUD `SetPlayerBurning` + optional widget @viewport 100), `SetPackBurning`
  (reflection: pack `fireDamage` DPS + `fireDamageCauser` + `SetIsOnFire`/`SetOnFireClear` calls),
  DPS applied **immediately on enter + 1/sec accrual**.
  Damage path is pack-HUD-aware by design: `HI_SetHealth(add=true, −dps)` via generic `CallPackFunction`
  (builds UFunction params by **fuzzy param-name matching**: Max/Health/Damage/Duration, bool Fire/Dead rules);
  explicit comment: do NOT double-call `SetOnFireTakeDamage` (stacked deaths); plain `ApplyDamage` fallback
  only when no health comp found.
- **TPWCS bridge machinery**: `FindPackHealthComp` (name/class contains "Health", cached), `ResolveFireDamageType`
  (pack `fireDamageType` prop → TObjectIterator scan for Fire/Burn/Flame UDamageType → base class),
  `BroadcastZeroParam`, `ReadPackDouble`, `CallNamedDamageFunctions` (4 candidate function names).
- **AI integration**: static `CollectFireHazards` (O(decorators), no world scan) → confirmed caller:
  SoldierAIController fire avoidance (Step 4). Tagged-sphere radius floor 30→180.
- Debug: SDDBG snapshot (world/tick/timer/track-vs-live/player-distance/wouldHit) + full player probe
  (hierarchy, components, health props, health functions).

### 5.2 AFireDamageZone (215) — standalone variant
- Same concept, simpler: overlap-gated 1s DPS timer, SquadAI direct + pack reflection (double/float, 3 prop names),
  burn widget + crackle sound + native HUD flag. Player-only. Overlaps SceneDecorator's role (two fire systems).

### 5.3 ABattlefieldDecorator (144) — mission-linked FX spawner
- `FBattlefieldEffectEntry` (Niagara/Cascade, radius, count, scale); activates on linked MissionZone Active,
  deactivates on Completed/Failed; optional auto-activate + loop timer. ⚠️ Spawned FX components are
  **never tracked** (`SpawnedEffects` stays empty — the `if (NC) {}` blocks are empty) → DeactivateEffects
  destroys nothing; loop mode leaks emitters (Bugs §8.8).

## 6. Weather, dust, barrage

### 6.1 ASandstormWeatherDirector (146) — Clear → Approaching → Haboob → Dissipating
- Auto-cycle (clear 120–300s, approach 12s, storm 60s, dissipate 15s) or `TriggerSandstorm` (8s buildup)/`StopSandstorm`.
  Intensity lerped 0.25 rate; targets 0/0.35/1/0.25. Howl audio SpawnSound2D, volume = intensity×0.95, 2s fadeout.
- ⚠️ `GetCurrentAIVisibilityMultiplier()` (lerp 1→0.35) is **never called** — storm has zero AI perception effect
  despite the header's "real time" claim (Bugs §8.9).

### 6.2 AAtmosphericDustScatterer (485) — player-proximal dust streaming
- Build phase: 5 zones/tick random anchors (radius = AutoZoneRadius×√count), ground-traced; ditch detect =
  ≥3 of 4 ring samples (400cm) avg ≥100cm above point; manual zones/ditches appended.
- Stream phase (0.5s): squared-distance cull (×1.6/×1.8 hysteresis), budgets **10 Niagara / 1 ambient / 2 ditch**;
  proximity dedup before spawn; volumes = spawned actor class or resolved `HeterogeneousVolume` fallback
  (StaticLoadClass, else plain AActor!) with material applied to prims + Material/VolumeMaterial props.
- ⚠️ Fallback `AActor::StaticClass()` spawn is a wasted empty actor if the volume class path ever fails (Bugs §8.10).

### 6.3 APathExplosionBarrage (612) — mortar strikes near player during missions
- Runs while any LinkedMission Active (or current chain mission), polled 0.5s; strikes every 6–12s (first 4s),
  max 2 concurrent; placement 450–2200cm from player, 10 attempts, ground-traced, spacing vs pending.
- Sizes Small/Medium/Large (r 180/300/480, dmg 35/75/140, weights 1.2/1/0.55, FX scale).
- Warning: pulsing translucent disc (MID params Tint/Color/BaseColor + 0.45 opacity) + debug circles
  (yellow inner <0.45s); 2s fuse; voiceline `Ally_IncomingGrenade`; **+0.85 suppression to AI in 1.6× radius**.
- Detonation: Niagara explosion + dirt (AutoRelease), dual-layer spatial audio with
  close→manager→tuning fallback chain + optional speed-of-sound + camera concussion; damage with
  falloff clamp (0.35–1.0) to player (2D) + registry soldiers (3D), **750-strength ragdoll impulse on kill**.
- Damage: SquadAI direct; others `ApplyDamage` + pack reflection write (no HUD notify — unlike SceneDecorator).

## 7. Tunables quick index (Step 5 surface)
MissionZone: Defend 60s/15s, respawn clip 30/reserve 120, death-poll 0.15s, retry delay 0.75s, progress broadcast 0.5%.
QuestChain: start delay, XP 1500 + achievement. QuestMission: 4Hz tick, timer, XP 800. Spawners: 5/1s/3waves/5s-gap,
loop, radius 500, max-alive 15, fireteam join 0.25s, corpse linger (tuning). Splines: corridor/lookahead/wander/
accept/nearby 400/700/160/200/3500, guide cache 0.35s/250cm, hazard skip 24×140. Decorator: trace ±2000/5000,
delay 0.1s, fire 3dps/180r, cull 15k/20k, poll 0.25s, Z-tol 180. Barrage: 6–12s, warn 2s, sizes above.
Dust: 15 zones/2500r, stream 0.5s, budgets 10/1/2, ditch 400ring/100thresh. Storm: timings above, AI vis 0.35.

## 8. Bugs / dead code found in Step 5 (10)
1. `AMissionZone::FailMission` has **zero callers** — player death infinitely retries; QuestChain failure branch
   (`OnMissionFailed`, `OnChainFailed`, `bRestartChainOnFailure`) is unreachable from C++.
2. `DefendTimerHandle` cleared 4×, never armed — leftover; countdown actually in Tick.
3. `UQuestObjective_AutoZone::ResolveMode` hardcodes **Reach** — Defend/Clear/`MaxSecondsOutsideZone` inert.
4. `QuestTickerSubsystem` advances only on **Succeeded** — a Failed mission stalls its director forever.
5. `UQuestLogSubsystem::RecordMission` never called — history + save bytes always empty.
6. Two spawner stacks (`EnemyWaveSpawner` vs `WaveSpawner`+template+AutoSpawnZone) with no shared base;
   MissionZone path uses only the former; the latter needs manual AutoSpawnZone placement.
7. `UEnemyPoolSubsystem::Prewarm` never called → pool always empty → **all** wave spawns pay full SpawnActor
   cost; `Release` calls no-op. Either prewarm from GameMode or delete the pool.
8. `ABattlefieldDecorator::SpawnedEffects` never filled (empty `if` blocks) → deactivate/loop leak emitters.
9. Sandstorm `GetCurrentAIVisibilityMultiplier` never read → weather is purely cosmetic for AI.
10. Dust scatterer volume fallback spawns a bare `AActor` if `HeterogeneousVolume` load fails — dead weight;
    (minor) `AQuestZone` hostile queries cast SquadAI-only, so pack enemies inside a zone are invisible to
    Clear-style checks on that path.
