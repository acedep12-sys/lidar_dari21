# Step 5 — Missions & World Systems (READ COMPLETE ✅)

Files read in full (FIXED code, 23 files, 10,011 lines): all of `SquadAI/Public+Private/Quest/`.
Biggest: SceneDecorator.cpp (1618), MissionZone.cpp (1122), SplinePathActor.cpp (700),
PathExplosionBarrage.cpp (612), EnemyWaveSpawner.cpp (534), AtmosphericDustScatterer.cpp (488).

## 1. Two mission frameworks coexist (key architecture fact)

- **Framework A — zone/chain (gameplay-critical, what AI/HUD/audio consume)**:
  `QuestChain` → `MissionZone` (Reach/Clear/Defend) + X/Y/Z `EnemyWaveSpawner` + `SpawnerTrigger` +
  `SplinePathActor` + one-drop `AutoSpawnZone`. Chain lookup via global registry (`FindPreferred`).
- **Framework B — tag/objective (data-driven Director stack)**: `QuestDirector` auto-discovers
  `AQuestMission` actors by `Order`; missions own instanced `UQuestObjective` objects (`AutoZone`:
  one tag + mode); ticked 4Hz by `QuestTickerSubsystem`; GPS beacon `CurrentActiveGoal` in
  `QuestRegistry`; history + save bytes in `QuestLog`; startup checks in `QuestValidator`.
- Bridge points: `QuestObjective_AutoZone::OnStart` force-pushes `QuestGoal` move commands to ALL
  team-0 AI + sets the GPS beacon (which `SoldierAIController::GetEffectiveMoveGoal` falls back to).

## 2. Framework B — Director/Mission/Objective/Ticker/Log/Validator

- **QuestTypes**: `FQuestTag` (hashable name key), `EObjectiveMode` (Auto/Reach/Defend/Clear),
  `EMissionState`/`EObjectiveState`, `FMissionLogEntry` (save record: title/order/state/duration/time).
- **QuestObjective_AutoZone**: OnStart = resolve zone tag → set beacon → push move commands
  (registry-first, actor-iterator fallback) → S5-3 same-tag spawner scan (**actor-tag** scan — see
  OBS-13) + hostile snapshot → ResolveMode (Auto→Reach; was hardcoded Reach). Tick: **Defend**
  (spawner-complete OR survive `DefendDurationSeconds`; fail if outside > `MaxSecondsOutsideZone`),
  **Clear** (0 hostiles + grace: started-nonempty OR age > 5s), **Reach** (player in zone, or any
  ally within 600 as fallback — cheap distance check, deliberately NOT `GetEffectiveMoveGoal`).
- **QuestMission**: tick-off actor; Start → music (`SpawnSound2D` + fade-in) → objective chain;
  TickMission (elapsed + time limit + current-objective tick → advance/fail); `GetHudSnapshot`
  (title/active/RTL/timer/objective + `EnemiesRemaining` = whole-map `CountHostilesNear(…,999999)`).
- **QuestDirector**: discover (outliner-children or level-wide) + stable-sort by Order; auto-start
  after 1s; completed/failed → record-to-log (S5-5 — was zero callers) → advance (S5-4 — failures
  used to stall forever); 3s intermission.
- **QuestTickerSubsystem**: `UTickableWorldSubsystem` with **IsTickable-until-confirmed** (one discovery
  tick, then a 4Hz timer; zero cost on non-quest maps); `RunMissionTick` = TickMission + HUD broadcast
  + completion/failure routing.
- **QuestLog**: **GameInstance** subsystem (survives level transitions); manual binary
  ToBytes/FromBytes (count + title/order/state/duration/ticks per entry) for save integration.
- **QuestRegistry**: O(1) tag→actor map + `CurrentActiveGoal` GPS beacon (header warns: allies only).
- **QuestValidator**: non-shipping only, 0.5s deferred, silent without a director; checks director
  count, empty objectives, duplicate Orders, zone-tag spelling, AutoSpawnZone class/points; red/yellow
  on-screen messages.

## 3. Framework A — Chain/MissionZone/spawners/triggers/spline

- **QuestChain**: static `GQuestChains` + `FindPreferred` (active-first reverse scan, dead-prune,
  world filter — O(chains), no world scan); auto-discover + sort-by-`MissionIndex`; auto-start +
  delay; remove-then-add event binding; chain-complete → **+1500 XP + `DehlaviehDefender` achievement**;
  failure → restart-chain OR (broadcast + Reset + 1s restart-same-index); current-mission-only event
  filter; `SpawnLeaderSplinePath` editor helper.
- **MissionZone** (tick 0.5, start-off): Activate (save player transform, bind death; Reach =
  instant-complete if inside; Clear = bind + activate, instant-complete if spawnerless; Defend =
  countdown + wave-interval timer); Tick (Clear = event-driven + safety poll; Defend countdown).
  Complete (+800 XP `AwardQuestCompletionXP`); Fail; `SilentResetForLoadRestore` (B6-8: zero side
  effects); `RestartCurrentAttempt` (wipe X/Y/Z + stop template + zero counters + RespawnSquad +
  0.75s → rebind/re-activate). **Respawn stack**: `RespawnPlayer` (revive-in-place BUT SquadAI-health
  only — OBS-1) vs `RevivePawnAt` (full: repossess, capsule, movement, ragdoll-off, montage-stop,
  uncrouch, teleport, SquadAI Revive + cover-clear + memory-reset + StateTree-start, **pack-health
  restore**, input re-enable, ammo); `RespawnSquad` (player → saved/trigger loc, leader −280 fwd,
  allies V-rows); `RestorePackHealth` (BPC_Health*/Health* match, skip HealthComp, max→current,
  clear bIsDead variants); `ResetPlayerAmmo` (`BPC_WeaponCharacter` reflection, per-weapon maps,
  dual-name variants). Death binding: SquadAI `OnDeath` OR pack-probe (log-only) → **always** a
  0.15s poll with cached pack comp; `OnPlayerDied` (S5-1: revive-then-fail-or-restart — FailMission
  previously had zero callers). Spawner events (X/Y/Z only — template stack covered by the Tick poll;
  **mixed stacks risk early completion**, OBS-2). Progress (Reach binary / Clear killed÷total /
  Defend elapsed; audio notify every tick; broadcast on >0.5% change). `SetMissionState` (broadcast +
  audio notify + music crossfade: Active→combat override, else ambient override). Badge text:
  custom (Persian) or REACH/CLEAR/DEFEND.
- **EnemyWaveSpawner (X/Y/Z stack)**: Activate (one-shot gate, S5-7 prewarm-to-MaxAlive, next wave);
  quota → `OnWaveCompleted` → delay → next (loop-or-complete); `MaxAliveEnemies` gate with retry
  timer; pool-Acquire → fallback SpawnActor (`Owner=this`); 0.25s deferred fireteam join;
  `ResetSpawner` (deactivate + destroy tracked + **owner-scan sweep** + fireteam unregister);
  `CleanupDeadEnemies` (rebuild alive count; SquadAI `IsAlive` OR pack `BPC_Health` reflection;
  batched post-loop broadcasts); `OnEnemyDied` (unregister, linger→Release/Destroy, decrement,
  broadcast, unbind); spawn loc = disc + nav-project + ground-trace fallback. Default `AEnemySoldier`.
- **WaveSpawner (template stack)**: idempotent `StartWaves` (S5-6) + pool top-up capped at 20 (S5-7);
  waves = `DelayAfterPrevious` + `BatchSize`/`SecondsBetweenBatches`; spawn points are **actor-LOCAL**
  (MakeEditWidget → `TransformPosition` to world + ±200 jitter + nav project); per-spawn: pool →
  fallback → coordinator `AddEnemy` → fireteam register → `OnDeath` bind; death handler (linger→
  Release/Destroy, auto-compact at 2×+10, wave-cleared → next or `OnAllWavesCleared`); `CachedLiving`
  = O(1) death-driven counter; `IsSpawningActive` (S5-6 never-started gate).
- **EnemyPool**: per-class arrays; Prewarm (spawn @ 0,0,−10000 + Sleep); Acquire (first-available +
  Wake, O(1)); Release (linear class scan + Sleep); Sleep (hide, no-collision, tick-off, teleport
  away, abort pathing, controller tick-off but **keep possession**, movement off, health reset);
  Wake (teleport/show/collide/tick-on, StateTree start-or-restart else `SpawnDefaultController`,
  movement walking, mesh physics-off + `CharacterMesh`, capsule on, health reset).
- **SpawnerTrigger**: player-pawn-only (+ optional team gate); one-shot + destroy-after; activates
  linked X/Y/Z spawners; editor plane visual.
- **AutoSpawnZone**: one drop = QuestZone + WaveSpawner (`Tag+"_Spawner"`) + optional Coordinator
  (attack=center, staging=center+0.7r east); ring spawn points; editor arrow previews. (**OBS-7:
  feeds WORLD coords into the spawner's LOCAL-point array — double-transform. Verify HIGH.**)
- **SplinePathActor**: `GSplineGuides` registry + cyan editor spline; `EvaluateMatch` skip rules
  (freeWill / no-spline / len≤150 / from-not-done / nearby-fallback ≤3500 + leads-toward-mission
  via endpoint-distances + tangent-align>0.15 / toMismatch); `FindGuide` (0.35s/250cm static cache,
  explicit-ToMission −50000 score bias, pre-BeginPlay iterator fallback); `GetSoftFollowLocation`
  (goal-side direction sign, lookahead ≥650, end→final-goal handoff); `GetFollowLocationSkipping`
  (24×140cm hazard-skip walk); `GetCorridorSlotLocation` (row-back + ≤160 lateral); legacy conveyor
  march (off); editor one-shot enemy scatter; cyan/yellow/green/orange corridor debug + full dump.

## 4. Atmosphere, fire & destruction dressing

- **SceneDecorator** (the fire system): `CollectFireHazards` (O(fires), `SceneDecoratorFire` tag,
  r<30→180) feeds Step-4 AI avoidance. Build: editor=immediate (timers don't tick in editor worlds),
  game=per-entry GPU-courtesy defer; rejection sampling (count×20, MinSpacing), **3-channel ground
  trace** (WorldStatic→Visibility→WorldDynamic); Niagara/Cascade/Mesh as attached instance comps
  (double `ApplyWorldTM` pre+post-Register, cull distances, no-collision/no-shadow meshes); hurt
  boxes (entry-or-actor radius, clamped >220→180). Runtime: adopt tagged boxes else spawn at Niagara;
  0.25s `PollFireDamage` (+tick backup): XY+180Z inside-test, 8s heartbeat, enter/exit edges (burn
  widget + `SetPackBurning` + immediate hit + 1s-accrue DoT). Pack bridge: health-comp find (cached),
  fire-`DamageType` resolve (prop → class-scan → base, cached), `fireDamage`+`fireDamageCauser` writes,
  `SetIsOnFire`/`SetOnFireClear`, `HI_SetHealth(add=true,−dps)` as THE HUD-aware hit (comments warn
  absolute-set was a bar no-op and double-calling killed too fast), generic `CallPackFunction`
  (name-heuristic ProcessEvent arg fill). Diagnostics: `DumpDebugSnapshot` (FIREDBG_HUD3 tag) +
  `DumpPlayerProbe` (health-ish props, 8-deep hierarchy, all health funcs). Compat shim
  `SpawnFireDamageZone`→hurt box (separate actors don't survive PIE/World Partition).
- **FireDamageZone**: standalone player-only sphere (1s DoT + burn widget + crackle + HUD
  `SetPlayerBurning`); SquadAI comp OR pack reflection (3 name × double/float variants); self-stops
  on death/exit. (Conceptual overlap with decorator hurt boxes — OBS-11.)
- **BattlefieldDecorator**: mission-linked Niagara/Cascade scatter, ground-traced; S5-8 tracks
  **components** not actors (old array could never hold them → leaked emitters); loop mode.
- **SandstormWeatherDirector** (0.1s tick): Clear→Approaching(12s)→Haboob(duration)→Dissipating(15s)→
  Clear(120–300s random); intensity interp; targets 0/0.35/1/0.25; `TriggerSandstorm` (8s buildup) /
  `StopSandstorm` (10s); `GetCurrentAIVisibilityMultiplier` = lerp(1, 0.35, intensity) — the Step-4
  S5-9 sight-rescale source; 2D howl audio ∝ intensity.
- **PathExplosionBarrage**: default sizes S/M/L (180/35, 300/75, 480/140 + weights); runs while
  linked-mission (or chain-current) active + 0.5s poll; warning→boom loop (concurrency 2, ground
  pick 450–2200 around player, 10 tries, pending-overlap avoid; local-handle boom timer + id-guard —
  OBS-5); mortar VO + AI suppression 0.85 @ r×1.6 on warning; explode = Niagara AutoRelease + audio
  fallback chain (per-size → AudioManager S/M/L → tuning defaults) + distance-layered spatial sound
  (2500/45000, speed-of-sound) + concussion (r×1.5/r×4.5); damage = player 2D + falloff (1−0.5d/r,
  clamp 0.35–1) + AI via registry with 750-impulse ragdoll kills; tick-0.05 disc pulse + debug
  circles (yellow inner <0.45s); `TestStrikeNearPlayer` editor button.
- **AtmosphericDustScatterer** (0.25s tick): 5-zones/tick ground-traced build (+4000/−8000) + ditch
  detect (4 @400cm samples, ≥3 valid, depth≥100) + manual zones; then tick = `UpdateInterval` (0.5);
  streaming = Niagara (cull 1.6×, budget 10, proximity dedup) + ambient volumes (budget 1) + ditch
  volumes (budget 2); `HeterogeneousVolume` via `StaticLoadClass` with S5-10 null-safe skip;
  material apply via slot-0 + reflection.

## 5. Style notes (additions)

22. **Global-registry + Find\*** pattern (QuestChain, SplinePath, SceneDecorator): static weak arrays,
    world filter, dead-prune, static time/location caches.
23. **Timers over tick** (actors tick-off by default; 0.15–0.5s timers; tick-as-backup; tickable-until-
    confirmed subsystems).
24. **RemoveDynamic-before-AddDynamic** idempotent binding everywhere.
25. Pack bridging = reflection + multi-name fallbacks + verbose build-tagged diagnostics
    (`[SDDBG]`, `FIREDBG_HUD3`, `[PATHDBG]`, `[BARRAGE]`, `[MissionZone]`, `[WaveSpawner]`).
26. Editor-first UX: CallInEditor buttons, MakeEditWidget, auto-discover+sort, actionable error logs.
27. State setters fan out to audio (Notify + crossfade) and progress broadcasts are change-gated.

## 6. Observations for future fix prompts (NOT fixed now)

- OBS-1 (verify HIGH): `RespawnPlayer` never calls `RestorePackHealth` (SquadAI-only) → pack player
  may sit at 0 HP after `OnPlayerDied` → death poll re-fails instantly on re-activation → fail loop.
  `RevivePawnAt` has the restore; `RespawnPlayer` looks like the older copy.
- OBS-2 (verify): mixed-stack Clear — `OnSpawnerEnemyDiedEvent` counts/checks `LinkedSpawners` only;
  mixing X/Y/Z + template spawners in one mission can complete while template waves still run.
  (Single-stack missions are safe: template-only falls back to the Tick poll.)
- OBS-3: `CallNamedDamageFunctions` + `BroadcastZeroParam` have no callers (dead; `NotifyPackHealthUI`
  is the live path).
- OBS-4: `SpawnedActors` never filled (compat vestige) — clear-sweep harmless.
- OBS-5: boom timers use uncancellable local handles — safe via id-guard; `StopBarrage` mid-warning
  still runs a no-op `ExplodeStrike`. Note only.
- OBS-6: `BindPlayerDeathDelegate` always installs the 0.15s poll even when a pack `OnDeath` delegate
  is found (probe is log-only; can't AddDynamic to arbitrary delegates) — intended but misleading.
- OBS-7 (verify HIGH): `AutoSpawnZone` feeds WORLD ring coords into `WaveSpawner::SpawnPointLocations`,
  which treats entries as actor-LOCAL (`TransformPosition`) → auto-zone enemies spawn at
  spawner-loc + world-point (double-transformed). Manual (MakeEditWidget) use is correct.
- OBS-8: `GetHudSnapshot` runs a whole-map hostile count per 4Hz broadcast — O(n), acceptable, note.
- OBS-9: `IsSpawningActive` gate means a never-started template spawner never blocks Clear — intended.
- OBS-10: `FireDamageZone` vs decorator hurt boxes = two parallel fire-damage implementations
  (standalone actor vs PIE/WP-safe comps); consider converging on hurt boxes.
- OBS-11: `CheckClearCompletion` poll keeps running for template-only missions by design (event flag
  only set by X/Y/Z path) — intended, note.
- OBS-12: `ResolveDefaultHeterogeneousVolumeClass` runs `StaticLoadClass` per spawn when no class set
  — spawns are budget-rare (1–2), fine.
- OBS-13 (verify MEDIUM-HIGH): tag-channel mismatch — `QuestObjective` finds its Defend spawner via
  **actor tags** (`ActorHasTag`), but `WaveSpawner`/`AutoSpawnZone` only set the **registry** tag
  (`SpawnerTag` = `Tag+"_Spawner"`, never added as an actor tag) → Defend-via-spawner-completion may
  silently degrade to duration-only unless designers hand-add matching actor tags.
- OBS-14: Defend wave re-trigger calls template `StartWaves()` = full restart from wave 0 (S5-6
  idempotent re-init) — in-flight template waves reset every `DefendWaveInterval`; X/Y/Z needs
  `bLoopWaves=true` to repeat at all. Verify intended for both stacks.
- OBS-15: `UpdateProgress` notifies audio every 0.5s tick even when unchanged — Step 7 must confirm
  `NotifyMissionProgress` is cheap/idempotent.
- OBS-16: `OnDefendWaveTimerExpired` → `ActivateLinkedSpawners` re-activation is a no-op for active
  X/Y/Z spawners (by `bIsActive` guard) — same as OBS-14, X/Y/Z side.
- OBS-17: Spline legacy conveyor (`bMarchAlongSpline`) + editor enemy scatter are dormant-by-default;
  keep off.
- OBS-18: `AWaveSpawner` has no `Reset` (documented S5-6: Stop + Start re-inits) — asymmetric with
  X/Y/Z; fine.
- Cross-refs → Step 6: `QuestNativeHUD` (Get/IsWarmupVeilActive/SetPlayerBurning), `FQuestHudSnapshot`
  consumers, `OnHudUpdated` binding, game-over UI (chain failure branch). → Step 7: `SoldierRegistry`
  (GetAllSoldiers/QueryRadius/CountHostilesNear), `Progression` (AwardXP/AwardQuestCompletionXP/
  UpdateAchievementProgress), `AudioSubsystem` (Notify*/CrossfadeMusic/PlayTacticalVoiceline/
  GetActiveAudioManager/PlaySpatialSoundWithDistanceLayers/TriggerExplosionConcussion), `AudioManager`
  (explosion sounds/shake), Tuning (SpawnPointNavProjectExtent/CorpseLingerSeconds/
  DefaultExplosion*/bSimulateSpeedOfSound), Save (QuestLog bytes, `SilentResetForLoadRestore` caller).

✅ Step 5 complete — missions & world systems fully read (10,011 lines).
