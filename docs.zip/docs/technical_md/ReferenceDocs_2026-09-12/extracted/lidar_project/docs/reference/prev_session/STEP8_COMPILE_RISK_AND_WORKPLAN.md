# Step 8 — UE 5.7 Compile-Risk Review + Work Plan (UI first)

*Date: 2026-09-08. Method: `SquadAI.Build.cs` audit, `WITH_EDITOR` guard audit on all editor-only
API uses, include-chain verification (incl. an automated subsystem-include scan over all cpps),
UHT-hazard sweep (`GENERATED_BODY`, forward declarations, UPROPERTY types, default initializers),
UE 5.7 API-pattern checks, `SquadAI.h/.cpp` + `Config` review. No engine available, so StateTree
call-site signatures are flagged verify-on-compile rather than asserted.*

*ID note: **B6-12** (Step 6 save/load bug, root-caused in Step 7) and **B7-12** (Step 7 fort-preset
bug) are different bugs — similar numbers, unrelated.*

---

## 1. Compile-risk register

### C8-1 — HIGH — `FKismetEditorUtilities` call outside `WITH_EDITOR` (game builds fail)
- **File:** `Private/Actors/SquadAIAutoSetupManager.cpp:770`, inside `AssignWeaponPresetToBlueprint`
  (:731–777). The `#include "Kismet2/KismetEditorUtilities.h"` (:35) sits inside the file's only
  include guard (`#if WITH_EDITOR` :29–37), but the function body is unguarded.
- **Effect:** editor builds compile; **packaged game builds fail** (`FKismetEditorUtilities`
  undeclared).
- **Fix (2 lines):** wrap the SCS-template `CompileBlueprint` call in `#if WITH_EDITOR` / `#endif`.
  Also consider guarding the whole `AssignWeaponPresetToBlueprint` body — in game builds the
  factory calls feeding it already return `nullptr`, so the function is dead weight there.

### C8-2 — HIGH — `AssetRegistry` include + use in game builds, but editor-only dep
- **Files:** `Private/BlueprintLibraries/SquadAIBlueprintAssetFactoryLibrary.cpp:25` (unguarded
  `#include "AssetRegistry/AssetRegistryModule.h"`), `:707` (`FindAssetByNameContains`) and `:722+`
  (`CreateOrFindWeaponVisualPreset`) — all unguarded. `SquadAI.Build.cs` lists `"AssetRegistry"`
  only under `if (Target.bBuildEditor)`.
- **Effect:** game builds fail at the include (include path not provided); even past that, an
  unlinked module.
- **Fix (1 line, recommended):** move `"AssetRegistry"` into `PublicDependencyModuleNames` —
  AssetRegistry is runtime-safe (cooked registry exists in packaged games; `GetAssetsByClass` and
  `AssetCreated` work there). Alternative: guard line 25 + stub `CreateOrFindWeaponVisualPreset`
  for game builds — but the preset search is also useful at runtime, so prefer the dep move.
- Companion note: `USquadAIPackAssetResolverLibrary` is already correctly guarded (`#else return
  nullptr`) — no change needed there.

### C8-3 — MEDIUM — `IMPLEMENT_PRIMARY_GAME_MODULE` integration constraint
- **File:** `SquadAI.cpp:36` — `IMPLEMENT_PRIMARY_GAME_MODULE(FSquadAIModule, SquadAI, "SquadAI")`.
- **Effect:** SquadAI declares itself the **primary game module**. Correct only if the target
  project has no other game module. The owner's setup ("full UE project exists locally; repo module
  plugs into it") likely means a second game module exists → switch to `IMPLEMENT_GAME_MODULE`
  (2-arg) and register SquadAI as an additional module in the project's `.uproject`. If SquadAI is
  instead shipped as a *plugin*, `IMPLEMENT_PRIMARY_GAME_MODULE` is disallowed entirely — use
  `IMPLEMENT_MODULE`.
- Also from `SquadAI.cpp`: the global team-attitude solver (`SetAttitudeSolver`, Team0 vs Team1 =
  Hostile) installs at module startup — intended, but be aware any other module setting a solver
  will be overridden/overridden-by load order.

### C8-4 — CRITICAL (all builds) — `ETacticalVoicelineType::Command_Hold` doesn't exist (B7-4)
- **File:** `Private/Performance/SquadAIPlayerCombatBridge.cpp:228`.
- **Effect:** hard compile error in every target (editor included).
- **Fix options:** (a) add `Command_Hold` to the enum in
  `Public/Performance/SquadAIAudioSubsystem.h:29` + a voiceline array on `ASquadAIAudioManager` +
  a case in the subsystem's play switch (recommended — the med-kit heal moment deserves its line);
  (b) one-line change to an existing value (e.g. a generic confirm) as a stopgap.

### C8-5 — LOW — 3 missing includes masked by unity-build leakage
Automated scan: every cpp referencing `USquadAI*Subsystem::Get` / subsystem pointers was checked
against its own includes + its own header's includes. Exactly 3 gaps, all compiling today only
because `Private/HUD/QuestNativeHUD.cpp` (alphabetically earlier, includes both headers at :35/:40)
leaks declarations into the same unity blob. They break under `bUseUnityBuild=false`, IWYU-strict
setups, or unity reordering:
1. `Private/Performance/SquadAIPlayerCombatBridge.cpp` — add
   `#include "GameFramework/SquadAIInventorySubsystem.h"` and
   `#include "Performance/SquadAIAudioSubsystem.h"` (uses `USquadAIInventorySubsystem::Get`,
   `Inv->FirstAidKits`, `USquadAIAudioSubsystem::Get`, `PlayTacticalVoiceline`,
   `ETacticalVoicelineType`).
2. `Private/Actors/FirstAidKitActor.cpp` — add
   `#include "GameFramework/SquadAIInventorySubsystem.h"` (uses `::Get` + `FirstAidKits`).
- No other subsystem-include gaps found; `EGrenadeType` correctly arrives via the directly-included
  `TacticalGrenadeComponent.h`.

### C8-6 — LOW — StateTree call-site signatures unverifiable without the engine
Deps are correct (`StateTreeModule` + `GameplayStateTreeModule`), includes resolve to those
modules, and usage patterns look 5.x-native — but the StateTree API churned across 5.0–5.3, so
treat `Private/AI/StateTreeTasks/*` as **verify-on-first-compile**. If errors appear, they're
mechanical (context/signature updates), not architectural.

### C8-7 — INFO — unused but harmless module deps (trimmable, not wrong)
No `#include` from `EnhancedInput`, `Slate`/`SlateCore`, `SmartObjectsModule`,
`GameplayAbilities`, `GameplayTasks`, `SignificanceManager`, or editor-side `ToolMenus` was found.
They cost link time, not correctness. Leave alone until packaging, then trim.
Conversely every *used* engine module **is** declared: AIModule (perception, `GenericTeamAgentInterface`),
NavigationSystem, UMG (`UWidgetComponent`, `UUserWidget`), Niagara, InputCore, DeveloperSettings,
GameplayTags, Engine, Core/UObject. No `Json`/`Http`/`MediaAssets`/`LevelSequence`/`Landscape`/
`PhysicsCore`-direct includes exist, so no missing deps there.

### C8-8 — INFO — content referenced but not shipped (not a compile risk; blocks visuals)
`Config/DefaultEditorPerProjectUserSettings.ini` auto-reimports `SquadAI/Content/Textures` and
`Content/Textures` → `/Game/Textures`; `FSquadAIAssetHelper::LoadTextureSafe` (header-only,
`Public/Utilities/SquadAIAssetHelper.h:85`, uses Engine-side `FImageUtils::ImportFileAsTexture2D`
— no extra module dep needed) tries the `.uasset` path then 5–9 loose-file candidates
(`ProjectContentDir`, `ProjectDir`, `SquadAI/Content`, `Content`, `ProjectPluginsDir`). The repo
ships **zero textures/sounds**, so all menu art, previews, avatars, badges resolve to `nullptr`
until the owner supplies PNGs or cooked assets. First UI milestone dependency.

---

## 2. Verified safe (checked, no action)

- **Editor API block is correctly guarded otherwise:** `DuplicateAsset`, `CreateBlueprint`
  (7-arg + `BPTYPE_Normal`), `MarkBlueprintAsStructurallyModified`, all `CompileBlueprint` calls in
  the factory are inside `#if WITH_EDITOR`; `UnrealEd` + `AssetTools` are editor-only deps. ✓
- **UE 5.7 AssetRegistry patterns correct:** `FARFilter.ClassPaths` + `PackagePaths`,
  `UBlueprint::StaticClass()->GetClassPathName()`, `GetAssetsByClass(FTopLevelAssetPath)`. ✓
- **UHT sweep:** `GENERATED_BODY()` present in 100% of `UCLASS`/`USTRUCT` headers; forward-declared
  `UBlueprint*` / `USquadAIWeaponVisualPreset*` / `UMeshComponent*` / `UNiagaraSystem` in UFUNCTION/
  UPROPERTY signatures are legal; `TWeakObjectPtr` UPROPERTY arrays legal (`FWeakObjectProperty`);
  `TSubclassOf<UCameraShakeBase>` + `ClientStartCameraShake` valid in 5.7; `FText::FromString` /
  `FName(TEXT())` default member initializers compile and are UHT-safe; by-value USTRUCT members
  (`FSquadMenuTextConfig`, `FSquadAIMoveCommand`) have full definitions included. ✓
- **No UObject-before-ctor hazards:** `ConstructorHelpers::FObjectFinder` only in ctors;
  `LoadObject` fallbacks guarded by subsystem-null checks. ✓
- **Deprecated-but-present APIs fine in 5.7:** Cascade `UParticleSystem` references, `CreatePackage`,
  `FindPackage`, `StaticLoadClass`, `FScriptArrayHelper`, `FindFProperty`/`CastField`, `FKey`,
  `EAutoPossessAI`, `bIsUISound`, `SpawnSound2D` 8-arg, `ApplyRadialDamageWithFalloff` 12-arg. ✓
- **No cycles:** `SquadAIMainMenuSetupActor.h` → `SquadAIMainMenuHUD.h` is one-directional. ✓
- **Unity-build macros:** identical `SQUADAI_VERBOSE_DEBUG_LOG` definitions in 2 TUs — benign. ✓
- **C++ standard:** code is C++17-conformant, clean under 5.7's C++20 default. ✓
- **`FGenericTeamId::SetAttitudeSolver`** — valid Engine/AIModule API. ✓

---

## 3. Integration steps (owner's project)

1. Copy `SquadAI/` to `<Project>/Source/SquadAI/` (module root with `SquadAI.Build.cs`,
   `SquadAI.h/.cpp`, `Public/`, `Private/`, `Config/`).
2. Add to `<Project>.uproject` → `Modules`: `{ "Name": "SquadAI", "Type": "Runtime",
   "LoadingPhase": "Default" }`. If the project already has a game module, apply C8-3
   (`IMPLEMENT_GAME_MODULE`).
3. Apply C8-1 (guard), C8-2 (dep move), C8-4 (enum or call-site), C8-5 (3 includes).
4. Generate project files, compile editor target. Expect C8-6 as the only possible surprise area.
5. Supply UI textures (C8-8): loose PNGs under `<Project>/Content/Textures/` (auto-import) using
   the exact asset names in `SquadAIMainMenuSetupActor::AutoResolveAllTextureSlots`, or cooked
   `.uasset`s at `/Game/Textures/`.
6. Optional: compile once with `bUseUnityBuild=false` to prove C8-5-class issues are gone.

---

## 4. Work plan — UI / menus / HUD first (owner's priority)

### Phase 0 — Compile + baseline (prerequisites for everything)
C8-1, C8-2, C8-4, C8-5, integration §3. Deliverable: clean editor build, PIE runs, menu map opens.

### Phase 1 — Interaction prompts + E-key arbitration (gameplay HUD)
- **B6-17 + B7-18:** HUD draws prompts only for crates/kits. Add MedicalStation/Turret loops in
  `QuestNativeHUD.cpp` (≈ same pattern as :932/:1018). Decide barrels: prompt or no-prompt (they
  detonate by damage, not E — recommend no E prompt, maybe a hazard marker).
- **B7-19:** centralize E-key handling — today 4 actors poll `WasInputKeyJustPressed(E)` independently
  + HUD revive holds E + inventory screen maps E to `NextWeapon`. Recommend: single interaction
  manager (closest in-range candidate wins; inventory-open suppresses world interacts).
- **B7-20:** turret mount should lock/detach player movement (or at minimum show a mounted HUD state);
  today walking away silently dismounts via overlap-end.
- **B6-3:** `DrawFilledCircleArea` draws squares for R≤12 — fix or replace with a real circle draw
  (all minimap/compass dots affected).
- **B6-14:** gameplay HUD is 1080p-hardcoded — port the menu HUD's `UIScale` approach over.
- **B6-18:** static "N" on rotating minimap; **B6-20:** minimap never re-inits after respawn/player
  change (capture comp outered to pawn).

### Phase 2 — Main menu completion
- **B7-21 (largest UI gap):** 9 director texture slots (Quran/radio/wallet/pouch/canteen/dogtag/fallen
  notes + Loading/NightOps) have no HUD-side fields and MainMenuHUD renders no inventory/relic UI
  at all. Add HUD fields, extend `PushSettingsToHUD`, build the Fallen-Notes/collection screen.
- **B6-4 + B6-9:** Settings screen is a placebo (static rows, IDs 701–704 unhandled; volumes/language
  saved but never applied). Wire clicks → `ApplySettingsToEngine` → engine/audio apply.
- **B6-19:** fragile button-ID namespaces (500s/600s/`10` reused across screens) — safe today, but
  any new screen must follow the namespacing discipline; consider per-screen ID enums.
- **B6-21:** `ApplyPersianFarsiPreset()` in HUD ctor calls `LocalizationSubsystem::Get(this)` —
  audit subsystem availability at CDO time.
- **B6-22:** hardcoded identity dossier in inventory tab 4 — wire to profile/save data.
- **B6-16:** mortar call-in plays `Ally_IncomingGrenade` on the player — swap to a fire-support line
  (pairs with C8-4's `Command_Hold` addition).

### Phase 3 — Save/load integrity
- **B6-12 (root-caused, Step 7 §1.3):** `LoadLevelWithScreen` → `OpenLevel` destroys the widget and
  never applies save data. Fix design: GameInstance-held pending-apply (`PreLoadMap`/`PostLoadMap`
  delegate or `FCoreUObjectDelegates::PostLoadMapWithWorld`) that calls `ApplySaveDataToWorld`
  after the new world is ready; keep the loading widget in a layer that survives (e.g. GameViewport
  client widget created post-travel start, or engine loading screen).
- **B6-1:** pause-save slot mismatch (`"AutoSave_SquadAI"` literal vs 
...[truncated 2081 chars]