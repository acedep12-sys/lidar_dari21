# Step 7 — Audio Director, Performance Subsystems, Tactical Support, Environment, Actors, Pack Components, Editor Libraries

*Read-through date: 2026-09-08. Scope: `Private/Performance/*` (13 cpps), `Private/Tactical/*` support files,
`Environment/*`, `Public/Private/Actors/*` (11 actors), 5 leftover `Components`, 5 `BlueprintLibraries`.
All files fully read unless noted. Step 6 leftovers folded in: B6-10 verdict, B6-12 root cause.*

---

## 1. Performance subsystems (13 files)

### 1.1 SquadAIDifficultySubsystem — static difficulty multipliers
Pure data + `Get()` accessor. Difficulty enum (Recruit/Regular/Hardened/Veteran, 4 cards incl. Lethal)
scales enemy damage/health/accuracy and player XP. No tick, no state machine.
Read by AI controllers, weapon code, and HUD difficulty cards.

### 1.2 SquadAICinematicCombatSubsystem — slow-mo + kill-cam director
Owns global time-dilation effects (`SetGlobalTimeDilation` pairs with restore timers).
`NotifyEnemyEliminated(...)` is the last-kill slow-mo entry point — **see B7-3, it has zero callers**.
Encounter-volume slow-mo (`CombatEncounterVolume::CompleteEncounter`) does its own inline dilation
instead of calling this subsystem, so the two systems are parallel implementations.

### 1.3 SquadAILoadingScreenSubsystem — B6-12 ROOT CAUSE CONFIRMED
`LoadLevelWithScreen(LevelName, Title, Briefing)`:
1. builds the loading widget,
2. calls `UGameplayStatics::OpenLevel` — **which destroys the widget along with the old world**,
3. has **no seamless-travel delegate, no post-load hook, nothing that ever calls
   `ApplySaveDataToWorld` after the map transition**.

Consequences: `MarkLoadingComplete` / `HideLoadingScreen` never fire post-transition; every
map-transition "load" restarts fresh (B6-12). The pre-`OpenLevel` widget is pointless work.
Contains 8 hardcoded Farsi combat tips + 3 sector title/briefing branches
(Dehlavieh–Karkheh / Bostan–Chazzabeh / Khorramshahr–Arvand).

### 1.4 SquadAISharedThreatMemorySubsystem — shared enemy knowledge
Small subsystem: registry of last-known player/squad positions shared across AI controllers so
flankers and suppressors act on common intel. Read by StateTree tasks and the attack coordinator.
No tick; event-driven writes, polling reads.

### 1.5 SquadAIAssetCacheSubsystem — engine-shape + material cache
Caches `Cube/Cylinder` engine meshes and the default basic material behind `Get()` so procedural
builders (buildings, forts, trenches) don't repeat `LoadObject` calls. `GetCubeMesh()`,
`GetDefaultBasicMaterial()` with inline `LoadObject` fallbacks at every call site.

### 1.6 SquadAIPlayerDiagnosticSubsystem — player-state inspector backing
Small subsystem exposing player pawn health/ammo/position snapshots for the dev-debug overlay and
`PlayerWeaponDiagnostic`. Polling getters, no tick of its own.

### 1.7 SquadAISignificanceManagerSubsystem — LOD brain (4 Hz)
Eval timer at 4 Hz → applies 6–12 staggered bucket changes per frame. Buckets drive:
controller tick interval (0.05–1.0 s), actor tick interval (0.1–1.5 s), CMC interval, update-rate
optimizations (URO), fixed skeletal-mesh bounds, shadow on/off, anim-tick options. This is the
primary "50-AI battle" scaling mechanism.

### 1.8 SquadAIFXManagerSubsystem — pooled FX + budgets (HAS BUG)
Central `SpawnExplosionFX` / impact VFX / tracer gateway with Niagara slots
(`NS_Dirt_Explosion[_Medium|_Small]`, `NS_Explosion[_Medium|_Small]`) pushed from
`AutoSetupManager::BeginPlay`. Distance culling + per-second budgets intended.
**B7-1: `ImpactFXCountThisSecond` / `WeaponAudioCountThisSecond` increment in
`CanSpawnImpactVFX` / `CanPlayWeaponAudio` but are never reset** — `SecondTimer` is declared and
never used, and the subsystem is not tickable. After 20 distant FX checks all distant FX is culled
**forever**; after 24 gunshot checks all distant (>1500 cm) gunshots are muted **forever**.

### 1.9 SoldierRegistrySubsystem — 2D spatial hash of all soldiers
4000 cm cells, full rebuild every 0.2 s; `QueryRadius` used by mortars, barrels, turrets,
suppression paths. `ApplySuppressionAlongPath` samples every `CellSize*0.5` with a `QueryRadius`
per sample (fine at turret fire rates, worth watching for MG spam). Smoke clouds pruned in
`RunRebuild`. `BroadPawns` = player pawn only. Drives the "soldier down" radio callout when an
ally's suppression ≥ 0.65 (`AI->GetSuppression()`, line 221).

### 1.10 SquadAIPlayerWeaponDiagnosticSubsystem — HUD debug feed
Thin getters over the TPWCS weapon component (clip/reserve via the same reflection names as the
ammo crate) for the on-screen weapon debug block.

### 1.11 SquadAIAudioSubsystem — the audio director (840 lines, fully read)
Timer-driven `Tick` at **20 Hz (0.05 s)** doing: music crossfade, horde-stem mix, combat-cooldown
decay, Khuzestan ambience scheduling, per-type voiceline budget reset. 8-state machine
(Ambient/Combat/DefendIntro/DefendClimax/Victory/Defeat/…): Victory/Defeat play stinger + duck
music. Features: speed-of-sound delay (distance/34300 cm/s via lambda timers), close/distant
explosion + gunshot layering with `MaxConcurrentGunshots=6` / `MaxConcurrentExplosions=3` voice
caps, `MaxAudibleDistance=40000` cull, per-type voiceline anti-spam (3–6 s), playlist round-robin
via `const_cast` index, horde war-drum stem fading with enemy count (threshold 7).
Live inputs: `MissionZone` calls `NotifyMissionStateChanged` (:657) and `NotifyMissionProgress`
(:696). **B7-3: `NotifyEnemyEliminated` (last-kill slow-mo trigger) has zero callers.**

### 1.12 SquadAIDevDebugSubsystem — cheats + diagnostics (627 lines, fully read)
Console-callable toggles: god mode, infinite ammo, AI debug visuals, debug logs, refill ammo,
complete objective, teleport, spawn helpers. Findings:
- **B7-5**: `ToggleGodMode` only heals once — `bGodModeActive` has **zero readers** anywhere else,
  so there is no actual invulnerability.
- **B7-6**: `bDrawAIDebugVisuals` has zero readers — toggle does nothing.
- **B7-7**: `bInfiniteAmmoActive` has zero readers — toggle does nothing.
- **B7-8**: `ToggleDebugLogs` flips a static bool with zero log-category effect (placebo).
  (The *real* log gates are the `ASquadAIAutoSetupManager::ShouldLog*` statics — different system.)
- **B7-9**: `CompleteCurrentObjective` logs/advances local state but never calls `Complete()` on the
  objective — quest doesn't actually advance.
- `RefillAllAmmo` writes TPWCS ints via reflection (30/180).

### 1.13 SquadAIPlayerCombatBridge — player-input → game glue (641 lines, fully read)
`TickComponent` polls raw keys (no Enhanced Input): grenade throw, mortar call-in on MiddleMouse
release (cooldown-gated → `FireSupport->CallMortarStrike`), weapon switching, interact routing.
- **B7-4 (CRITICAL, compile error)**: line 228 references
  `ETacticalVoicelineType::Command_Hold`, which **does not exist** in the header enum (15 values,
  no `Command_*`). Fails compilation — Step 8 item.
- **B7-10**: Mortar double-fire — bridge (cooldown-gated, via FireSupport) **and**
  `QuestNativeHUD::DrawHUD` (direct `ATacticalMortarBarrageActor` spawn, no cooldown) both listen
  for the same MiddleMouse release → **two barrages per release**.
- **B7-11**: `DamageSoldierCharacter` bypasses `HealthComp.ApplyDamage`: sets `CurrentHealth`
  directly, manually sets `bIsDead`, broadcasts `OnDeath` — no damage events, no AI perception
  stimulus, god-mode/dev flags unchecked.
- `DamagePackEnemy` / `ApplyDamageViaReflection` use FDouble/FFloat reflection on `BPC_Health`
  `currentHealth`. Uses `USquadAIInventorySubsystem` + `EGrenadeType` with no direct include —
  include chain must be verified in Step 8 (likely transitive via `QuestNativeHUD.h`).

---

## 2. Tactical support systems

| File | Role | Key numbers / notes |
|---|---|---|
| `SquadAITacticalCommandSubsystem` | Squad orders | Issues HoldCover / SuppressSector / RegroupOnPlayer to all alive allies via registry |
| `SquadAIFireSupportSubsystem` | Mortar call-ins | 25 s cooldown; **B7-2: `TickCooldown` has zero callers → cooldown never elapses → after the first call-in, `CallMortarStrike` fails forever** (masked by the HUD direct-spawn path, which is why mortars still appear to work) |
| `SquadAITacticalPingSubsystem` | World markers | 5-ping cap, 8 s life, 20 Hz `TickPings` |
| `SquadAIRadioChatterSubsystem` | Farsi/English barks | 3.5 s anti-spam, 8 contexts |
| `TacticalGrenadeActor` | Frag + smoke | Frag = `ApplyRadialDamageWithFalloff` (165 → 20%, 0.35R inner) + radial impulse + Niagara via FXSys; smoke registers a registry cloud (1.25R, 18 s) then hides the actor with lifespan |
| `TacticalMortarBarrageActor` | Timed salvo | Ground-snap line trace → `FXSys->SpawnExplosionFX` → radial HE (`ShellDamage`, 0.3× min, 0.35R inner, 1.0 falloff) → `HUD->AddPlayerSuppression(0.85)` on nearby players → detonation sound (own slot or `Mgr->LargeExplosionCloseSound`, 1.4× vol) → `OnMortarBarrageFinished` + `Destroy()` after last shell |
| `SquadAILocalizationSubsystem` | ini string DB | GameInstance ini, 4-path search, then auto-generates a default template at `ProjectDir`; sections MainMenu/MapSelection/Armory/Traits/Profile/Loading/HUD/PauseMenu — **all Farsi, confirms UI strings live outside code** |

---

## 3. Environment (procedural builders)

### 3.1 DestroyedBuildingActor (.h 218 + .cpp 950, fully read)
No-tick actor; `BeginPlay → BuildBuilding`; editor `Build/Randomize/Clear`. Five styles:
TwoStorySniperRuins, SingleStoryMudbrick, WalledCourtyardHouse (nests a full mudbrick house),
VillageMarketStalls (3-stall row), OutpostObservationTower. Dual geometry path: 6 HISM components
(Walls/Floors/Wood/Sandbags/Metal/Rubble, all `BlockAllDynamic`) when `bUseHISMInstancing`, else
`AStaticMeshActor` cubes from the asset cache. Ground-snaps via 15 km-down trace and **moves its
own actor location**. `SpawnSuppliesAndDefenders`: med-kit + ammo crate (`bSpawnSupplies`),
roof MG with style-dependent Z (`bSpawnMountedHeavyMG`), breach barrel (`bSpawnExplosiveBarrels`),
raw `AEnemySoldier` defenders, first one on the sniper loft (`bSpawnHostileDefenders`, default off).
Middle spawner helpers (320–640) follow the identical HISM-vs-actor pattern (pattern-verified via
grep; only `SpawnWallSegment`/`SpawnRubblePile` read line-by-line).

### 3.2 DestroyedVillageCompoundActor (.h 124 + .cpp 249
...[truncated 12078 chars]