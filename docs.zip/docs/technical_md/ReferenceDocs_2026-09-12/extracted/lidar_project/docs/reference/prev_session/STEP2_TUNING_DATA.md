# Step 2 — Tuning, Data & Meta-Progression (READ COMPLETE ✅)

Files read in full (、私の detailed understanding):
- `SquadAI/Public/SquadAITuning.h` (442 lines) + `Private/SquadAITuning.cpp`
- `SquadAI/Public/GameFramework/SquadAIWeaponData.h` (weapon structs)
- `SquadAI/Public/GameFramework/SquadAIMapData.h` (map struct)
- `SquadAI/Public/GameFramework/SquadAIProgressionSubsystem.h` (422) + `Private/...cpp` (948)
- `SquadAI/Public/GameFramework/SquadAIInventorySubsystem.h` + `Private/...cpp` (318)
- `SquadAI/Public/GameFramework/SquadAIMainMenuGameMode.h` + cpp
- `SquadAI/Public/Utilities/SquadAIAssetHelper.h`
- `SquadAI/Public/SquadAIWeaponVisualPreset.h` + `Private/SquadAIWeaponVisualPreset.cpp` (325)

---

## 1. USquadAITuning (UDeveloperSettings, Config=Game)
**Access:** Project Settings → Plugins → Squad AI Tuning, or `USquadAITuning::Get()` (CDO read, zero-cost).
All gameplay numbers live here. Key values:

| Category | Keys |
|---|---|
| Audio/Music | DefaultAmbientMusic, DefaultCombatMusic, DefaultDefendClimaxMusic, Victory/DefeatStinger, Crossfade 2.5s |
| Audio/SFX | Explosion close/distant sounds, **bSimulateSpeedOfSound=true (343 m/s over 8km map)** |
| Cover Scanner | Chunk 1000×1000×500, 6 samples/axis, revalidate 30s, 2 chunk scans/frame, 16 queries/frame, 96 async traces/frame, crouch 95 / stand 180, min thickness 25, nav project 150, search radius 3500, partial resolve 0.6s, timeout 3s |
| Combat/Weapon | dmg 8, rate 12/s, spread base 1.5 +0.3/shot decay 5, range 10000, falloff from 2500, min mult 0.35, suppression radius 250 / 0.35 per bullet, global DamageMultiplier 1 |
| Combat/Health | max 100, invincible floor 1 |
| Combat/Aim | yaw rate 360, spring stiffness 14 / damping 1, spine cone 75°, max error 2.5° |
| Perception | sight 3500, lose-sight 4200, FOV 70°, hearing 2500, memory decay 0.2/s, suppression decay 0.4/s |
| Combat/Detection | detection 15000, close override 1800, max engage 8000, fallback fire 8000 + allowed |
| Allies | accuracy ×0.25, power 0.25, **count 4**, invincible false, spacing 200 |
| Enemies | accuracy ×0.65, aggression 0.4, suppression threshold 0.6, **max visible 50** |
| Leader | wait radius 1500, full-speed radius 800, speeds 400/120, invincible false, nav invoker 5000/10000 |
| Performance | significance interval 0.25s, max 16 hi-fi agents, dormant distance 8000, registry cell 4000, rebucket 0.2s |
| Difficulty | AllyPower E/N/H/L = .45/.25/.15/.05; EnemyDamage = .70/1/1.30/1.60; EnemyAccuracy = .40/.65/.80/.92 |
| Minimap/HUD | 7 icon textures, border color/thickness, material+font paths, font sizes (checklist 18, desc 20, badge 16, timer 24, counter 18), DistanceSuffix "m" |
| Mission Completion | popup 3s, background texture, message (Persian via \u escapes — OK) |
| Quest | tick 0.25s, corpse linger 8s, pool prewarm 30, spawn nav extent 120 |

⚠️ **BUG FOUND: `EnemyCounterText`** = `TEXT("\u00062F\u000634\u000645\u000646\u000627\u000646")` — corrupted.
Intended Persian "دشمنان" (U+062F U+0634 U+0645 U+0646 U+0627 U+0646) got mangled into `\u0006`+literal "2F" etc.
Renders as control chars + digits. → Fix in UI pass: `TEXT("دشمنان")`.

## 2. Weapon data structs (`SquadAIWeaponData.h`)
- `ESquadWeaponCategory`: BattleRifle / AssaultRifle / AntiTankRocket / MachineGun / SniperRifle (Farsi+English DisplayNames).
- `FSquadWeaponSpecialityTrait`: TraitID, Title/DisplayName (FA+EN), Description (FA+EN multiline), BadgeTag (with emoji), IconTexture.
- `FSquadWeaponDefinition`: WeaponID, names FA/EN, Caliber, HistoricalRole FA/EN, Category, descriptions,
  PreviewTexture, **9 ratings 0–1** (Damage, FireRate, Accuracy, Range, RecoilControl, Mobility, ArmorPenetration, EffectiveRange, Handling),
  MagazineCapacity, MaxReserveAmmo, SpecialityTraits[], RequiredPlayerLevel, XPCostToUnlock, bDefaultUnlocked, bIsUnlocked.

## 3. Map data (`SquadAIMapData.h`)
- `FSquadMapDefinition`: MapID, **LevelPackageName** (e.g. `L_Khuzestan`), names FA/EN, Subtitle,
  SituationBriefing FA/EN (multiline, shown on hover), PreviewTexture, bIsSelectable, LockReasonFarsi,
  RequiredPlayerLevel, CompletionXPReward, EstimatedPlaytime (Farsi string).

## 4. USquadAIProgressionSubsystem (UGameInstanceSubsystem)
**The meta-game brain.** Static `Get(WorldContext)`. Persists to slot `"SquadAI_PlayerProgression"` (via USquadAISaveGame fields).

- **Profiles:** `FSquadPlayerProfile` (ProfileID, PlayerName default "رزمنده خط‌شکن", AvatarID default Avatar_Rostami,
  stats: EnemiesHunted/Eliminated, TanksDemolished, Playtime, MissionsCompleted, TriageRevives, AlliesRevived, Accuracy 78.5, Headshots;
  progression: PlayerLevel/CurrentLevel (both exist!), TotalXP, CurrentLevelXP, SkillPoints, AttributeRanks `TMap<uint8,int32>`,
  UnlockedWeaponIDs[], EquippedWeaponID default G3A3). Create/Switch/Delete, SetAvatar/Name, **CyclePresetCallsign** (7 Farsi callsigns).
- **XP curve:** `XP(L) = round(800·L^1.25 + 400·L)` → L1≈1200, L2≈2704... **+1 skill point per level-up**, multi-level loop.
- **XP sources:** AwardXP generic; Tank +300; Revive +150 (+HeroicMedic progress); Quest completion default +800 (+MissionsCompleted, +DehlaviehDefender/FirstBlood progress); achievement rewards.
- **Attributes (7, max rank 10, 1 SP/rank):** MovementSpeed (+4%/rank speed), MaxHealth (+10 HP/rank), Stamina (+10%/rank),
  RecoilControl (−5%/rank recoil, floor ×0.50), ReloadSpeed (+6%/rank), FieldReviveSpeed (+8%/rank), OrdnanceCapacity (+1 per 2 ranks).
- **Armory catalog (5 weapons, hardcoded in InitializeCatalogs, textures via `FSquadAIAssetHelper::LoadTextureSafe`):**
  | ID | Cat | Mag/Reserve | Unlock | Ratings Dmg/Rate/Acc/Rng | Traits |
  |---|---|---|---|---|---|
  | G3A3 | BattleRifle | 20/140 | default | .88/.55/.86/.90 | HeavyCaliber 💥, LongRangePrecision 🎯 |
  | AK47 | AssaultRifle | 30/180 | default | .78/.78/.72/.75 | DesertReliability 🌪️, HighMobility ⚡ |
  | RPG7 | AntiTank | 1/6 | lvl 3, 2500 XP | 1.0/.20/.65/.80 | TankDestroyer 🛡️, BunkerBreaker 💣 |
  | MG3 | MachineGun | 100/300 | lvl 5, 4500 XP | .82/.98/.68/.88 | AreaSuppression 🔥 |
  | SVD | Sniper | 10/60 | lvl 7, 6500 XP | .96/.35/.98/1.0 | SilentMarksman 👁️ |
- **Unlock logic:** `IsWeaponUnlocked` hardcodes G3A3/AK47/None = true, else catalog bDefaultUnlocked, else profile list.
- **Achievements (4):** FirstBlood (350XP, target 1), DehlaviehDefender (1500XP, target 3), HeroicMedic (800XP, target 5), RostamiHonor (2500XP, target 5).
- **Maps (3):** Dehlavieh_Karkheh (`L_Khuzestan`, selectable, lvl 1, 1200 XP, ۲۰-۳۰ دقیقه) / Bostan_Chazzabeh (`L_Bostan`, 🔒 lvl 4, 2000 XP) / Khorramshahr_Arvand (`L_Khorramshahr`, 🔒 lvl 8, 3500 XP).
- **Doctrine nodes (5, `GetProgressionNodes` builds fresh each call):** LeadershipTactics→Stamina (1SP), PrecisionMarksmanship→RecoilControl (1SP),
  CombatEndurance→MaxHealth (1SP), IrregularTactics→OrdnanceCapacity (2SP), FieldEngineering→ReloadSpeed (2SP). `bUnlocked` derived from attribute ranks.
- **Events:** OnXPGained, OnPlayerLevelUp, OnAttributeUpgraded, OnWeaponUnlocked, OnAchievementUnlocked, OnProfileChanged.

⚠️ **Issues spotted (fix-phase candidates):**
  1. `UnlockWeapon()` never checks level nor charges `XPCostToUnlock` — costs are display-only. `CanUnlockWeapon` checks level but nothing calls it before unlock.
  2. Multi-profile is **session-only**: Save/Load persists only ActiveProfile-derived fields; extra profiles lost on restart.
  3. `RecordEnemyEliminated()` awards **0 XP** (only tanks/revives/quests/achievements grant XP).
  4. `PlayerLevel` and `CurrentLevel` are duplicated fields; only PlayerLevel is used.
  5. Doctrine-node unlock state isn't persisted separately (derived from attribute ranks — by design, but UI must reflect it).

## 5. USquadAIInventorySubsystem (UGameInstanceSubsystem) — tactical backpack
- **Arsenal (6, names/descs overridable via `[Armory] WeaponN_Name/Desc` localization):** AK47 (30/30/150), G3A3 (20/20/120),
  RPG7 (1/1/6), MG3 (100/100/300), SVD (10/10/40), **Knife (1/1/1 melee)** — note: Knife exists here but NOT in armory catalog.
- `EquipSelectedWeapon(Pawn)`: if `ASoldierCharacter` → writes WeaponComp (name, clip, reserve, `Damage = DamageRating×40`);
  else reflection fallback on any component with "Weapon" in name → sets `ActiveWeapon`/`CurrentWeapon` FStr/FName (TPWCS bridge).
- **Fallen notes:** `[FallenTroopNotes]` NoteCount (default 6), NoteN_Title/Body. `OnInventoryOpened()` reloads + advances note + syncs grenade counts from player's TacticalGrenadeComponent.
- **Radio:** `[RadioStations]` StationCount (default 5), StationN_Freq/Name; ToggleRadioPower; default playing.
- **Quran:** `[QuranVerses]` VerseCount (default 4), VerseN_Arabic/Translation; default verse وَمَا النَّصْرُ... 
- **Supplies:** FirstAidKits 3, Frag 2, Smoke 2, Canteen 85%.

## 6. ASquadAIMainMenuGameMode
- `HUDClass = ASquadAIMainMenuHUD`, `DefaultPawnClass = ASpectatorPawn`. Logs init in BeginPlay. (Menu level's GameMode.)

## 7. FSquadAIAssetHelper::LoadTextureSafe(PackagePath, RelativePngPath)
- Try `LoadObject<UTexture2D>` package first → else search disk candidates (ProjectContentDir, ProjectDir, `SquadAI/Content`, `Content`,
  Plugins `SquadAI/Content`, + `Textures/<BaseName>.png` variants) → `FImageUtils::ImportFileAsTexture2D`. Returns nullptr if all fail.
- Used everywhere for UI textures (weapons, maps). **Null-tolerant callers required** (audit in UI pass).

## 8. USquadAIWeaponVisualPreset (UPrimaryDataAsset)
- Per-weapon visual bundle: soft ptrs for muzzle/trail/impact (Cascade+Niagara), fire/tail/empty sounds, fire/crouch-fire/reload/equip montages,
  aim blendspaces, projectile class + explosion VFX/sound, sockets (Muzzle, LeftHandIK, ShellEject), skeletal mesh. `LoadAllAssets()` sync-loads all.
- `AutoPopulateFromTPWCS()` (CallInEditor): finds `DT_Weapons` (searches `/Game/ThirdPersonWeaponCombatSystem/...`, ThirdPersonMP, TPWCS, Game paths + AssetRegistry fallback),
  reads row for WeaponID with **prefix-matched reflection** (handles hashed BP names): VFXInfo (muzzleFlashC/N, bulletTrailC/N), soundsInfo.fireSound,
  baseInfo.weaponMesh, animationInfo (firingAnimID/reloadingAnimID/equippingAnimID) → resolves montages via hardcoded `FTpwcMontageLookup` map
  (pistol, rifleHip, rifleIronsights, rpg, shotgun, shotgunAuto, thrown). Heavy debug logging. `MarkPackageDirty()` at end.
- **Confirms: project integrates marketplace pack "ThirdPersonWeaponCombatSystem" (TPWCS)** — many bridge components reference it.

## Cross-links for later steps
- Progression → SaveGame fields (Step 7 save system), → FarsiTextHelper (Step 6), → WeaponComp fields (Step 3).
- Tuning → read by AI/cover/quest/HUD everywhere (`USquadAITuning::Get()`).
- Inventory → TacticalGrenadeComponent::GetFragCount/GetSmokeCount (Step 3), → Localization `GetString` (Step 7).
- WeaponVisualPreset → TPWCSVisualsComponent + adapter/bridge components (Step 3/7).
