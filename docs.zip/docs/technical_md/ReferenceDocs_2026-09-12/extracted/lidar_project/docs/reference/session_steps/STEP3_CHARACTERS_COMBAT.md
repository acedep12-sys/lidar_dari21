# Step 3 — Characters & Combat Components (READ COMPLETE ✅)

Files read in full (FIXED code, 22 files, 5,760 lines):
- Characters: `SoldierCharacter.h` (572) + `.cpp` (1339) + `PresentationHelpers.inc` (48),
  `LeaderCharacter.h` (203) + `.cpp` (320), `AllySoldier.h` (126) + `.cpp` (245),
  `EnemySoldier.h` (40) + `.cpp` (32), `SquadLeaderTypes.h` (46)
- Components: `WeaponComponent.h` (185) + `.cpp` (1088), `HealthComponent.h` (81) + `.cpp` (132),
  `AimComponent.h` (98) + `.cpp` (253), `TacticalGrenadeComponent.h` (88) + `.cpp` (201),
  `SquadAITPWCSVisualsComponent.h` (97) + `.cpp` (334)
- Animation: `SoldierAnimInstance.h` (151) + `.cpp` (81)

## 1. ASoldierCharacter — abstract base (ACharacter + IGenericTeamAgentInterface)

- **Ctor**: creates Aim/Weapon/Health/Grenade/Adapter comps; movement (orient-to-move, 720°/s, walk 400,
  crouch enabled, half-height 44); PerceptionStimuli (sight+hearing+damage, auto-register); NavInvoker; TeamId=1.
- **BeginPlay**: downed rules (leader/enemy = no, ally = yes); 4.5s spawn grace; pack-bridge timer
  (0.15s heroes / 0.5s others); `OnTakeAnyDamage` bind in pack mode; NavInvoker register (20000/30000);
  `bCanEverAffectNavigation=false` on ALL prims (NavMesh protection); TeamId from faction; adapter init +
  pack-safe; TPWCS tags; controller team id; RegisterWithSystems; accuracy copy; OnDeath bind;
  player-only progression apply (speed ×, +bonus HP, accuracy ×(2−recoil)); enemy URO anim opts.
- **Pack damage bridge** (all reflection, double→float→int): `TryBindPackDamageDelegate` (finds BPC_Health,
  marks bound — vestigial, see OBS-10); `SyncPackHealthToSquadAI` (8 prop-name variants; first-read sync;
  damage → grace-restore OR hero clamps (leader 35 / ally 1) → `HealthComp->ApplyDamage` chokepoint;
  heal → sync up; keeps polling forever — HUD bar depends on it); helpers Clamp/Restore/GetMax/ResetPackDeathFlags;
  `OnAnyDamageReceived` (chokepoint + same-frame hero clamp against one-shot pack deaths).
- **TakeDamage**: leader = 25% chip, floor 35; else ApplyDamage + random hit-react montage + `UAISense_Damage` report.
- **Downed**: `EnterDownedState` (stop fire/aim/AI/move, capsule ignore Pawn/Vehicle, ragdoll collapse +
  downward impulse, `Ally_ManDown` line, `HUD->NotifyAllyDowned`); `ApplyReviveProgress`;
  `CompleteRevive` (Revive, pack restore to PACK max + death-flags clear, capsule restore, mesh physics-off +
  Teleport reattach + visibility + AnimInstance reinit, walk 450, `RestartStateTree`, re-register).
- **HandleDeath** (FIXED — old unconditional-downed block is now conditional): leader → HP 50, alive;
  ally → downed; other downable → downed; player → stop only (mission restart lives elsewhere); enemy →
  unregister, **B7-3** cinematic hook, kill voicelines, StateTree stop, movement/capsule off, death montage
  (+ delayed ragdoll: max(2s, 90% length)) else instant ragdoll + impulse, pack `bIsDead` propagation,
  `DetachFromControllerPendingDestroy`, LifeSpan 10.
- **Cover**: SetCoverState (crouch sync), SetCurrentCover (leans→side, low+over→peek), ClearCover.
- **Identity**: `IsSquadLeader()` = IsA(ALeaderCharacter) OR tag OR name contains "Leader"/"Rostami" (OBS-6).
- **Montages**: 7 fire + 7 reload slots selected by cover matrix (low/high × left/right/over + crouch + base).
- **Weapon visual/IK**: attach w/ offsets (classic mode only), socket transforms (world / mesh-space /
  relative-to-`hand_r`), muzzle; `GetWeaponIKRuntimeData` (effector + dynamic elbow via `lowerarm_l` +
  rotation distribution + grip); `GetSoldierAnimRuntimeData` (speed/direction/cover/aim/combat-ready aggregate).
- **Presentation** (`.inc`): state machine Dead > Firing > Aiming > Moving > Idle from bWantsToFire/AimComp/AIC.
- **Grace**: `ResetSpawnGracePeriod` + one-shot timer → `EndCombatGracePeriod`.

## 2. ALeaderCharacter — Rostami (immortal, quest-paced)

- Pacing: player > 1500 → speed 0; hazard sprint 720; else walk 400 × `AIC->PathSpeedScale` (clamped .45–1),
  lerped 400→120 across 800–1500. Waypoint FSM: NotReached/Moving → Arrived → WaitingForClear → next,
  linger-gated, area-clear via `Registry->CountHostilesNear` (default radius 1500). API: Set/Begin/Advance/
  Reached/AreaClear/Location/PlayerDistance/Complete + snapshot struct.
- **Tick enforces immortality**: `bIsDowned=false`, `bIsDead=false`, HP ≥ 50 (every 0.25s tick).
- Presentation mirror (combat/aim/fire/quest/waypoint/player-dist), LOD-bucketed refresh 0.1–0.75s,
  debug state text (Dead/Combat/WaitingForPlayer/QuestComplete/WaypointClear|Contested/FollowingWaypoint/Idle).

## 3. AAllySoldier — immortal-ish, PowerLevel dial

- `PowerLevel` 0–1 (default 0.25, tuning-fed): accuracy = lerp(.05,.85), damage = lerp(.20,1.40),
  fire-rate = lerp(.70,1.30); per-stat overrides (−1 = derive). HP 150, invincible flag from tuning.
- Tick 0.2s: downed allies' bleedout floored at 15s @ 0.1× decay → **never bleed out** (OBS-7).
- Leader resolve: override → static weak cache → SoldierRegistry scan → TActorIterator fallback.
- Same LOD presentation mirror as leader (leader-location/distance variant).

## 4. AEnemySoldier — mortal, tuning-driven

- BeginPlay pulls accuracy/aggression/suppression-threshold + MaxHealth from tuning; `bInvincible=false`.
- Coordinator fields: `AssignedAttackPoint` + `AttackPointLeash` 2500 + `CurrentPhase` (EAttackPhase).

## 5. UHealthComponent — THE damage chokepoint

- `ApplyDamage`: cheat-god → 0 (B7-5) · dead/non-positive → 0 · spawn-grace (non-enemy) → 0 ·
  leader → 25% chip, floor 35, broadcast, return · else subtract → invincible-clamp (only if NO downed mechanic) →
  broadcast Damaged+Changed → player-HUD directional indicator → HP≤0: downed-enter (if mechanic) else die
  (if !invincible). `ApplyExternalDamage` = ApplyDamage + 4-param broadcast. `Heal` (**clears bIsDead**, OBS-4).
  `Revive` = full. BeginPlay fills MaxHealth/InvincibleMin from tuning.

## 6. UWeaponComponent — hitscan + bursts + penetration + TPWCS player-damage stack

- Burst FSM (Idle/Firing/Cooldown), tick 0.05s self-disabling; spread recovery, heat cooling (0.35/s),
  `bWantsToFire` 0.25s pulse reset for AnimBP bools.
- `FireAtTarget`: pack-mode gate → alive gate → **lead prediction** (registry/player velocity @ 600 m/s) →
  **muzzle-LOS gate** (blocked-by-world suppresses shot; blocked-by-health-actor allows) → spread → hitscan →
  suppression → heat/spread/timing → fire anim → casing-clatter timer (0.35s) → ally `Ally_Reloading` at burst
  end → OnFired. `StartBurst` (pack mode: 0.25s anim delay). `CanFire` = not cooling.
- `PerformHitscan`: 30cm muzzle-clearance nudge → Visibility trace → **registry ray pass** (95cm radius,
  3 body points, same-team skipped) → **player proximity pass** (150cm, 3 points, team friendly-fire check) →
  blocker damage (attach-chain health walk else raw TakeDamage) → **penetration** (depth<2, reverse-trace
  thickness 2–40cm, 0.5× damage recurse). Damage = base × falloff × DamageMultiplier × tuning multiplier.
- Spread = CurrentSpread/Accuracy cone (cap 20°); falloff = lerp(1, minMult) from 2500→10000.
- Suppression via `Registry->ApplySuppressionAlongPath` + **bullet-whiz** (50–500cm near-miss, manager fallback).
- Muzzle: pack socket → logical shoulder (105 up / 35 fwd) → mesh socket → eye+50fwd.
- **TPWCS player stack** (`ApplyTPWCSPlayerDamage`): SquadAI HC → TakeDamage → ApplyDamage → HUD notify →
  direct `currentHealth` prop write → `HI_TakeDamage` via `ProcessEvent` with **by-TYPE param fill**
  (float/double=damage, class=UDamageType, controller→instigator, other object→causer; OBS-14 multi-dip risk).
  `EnsureTPWCSPlayerHealthInitialized` safety net (Max 0 → set 100 + refill unless genuinely dead).
  `ResolveTPWCSDamageFunction` (FindFunction fast path + TakeDamage-substring enumeration fallback).
- **Ammo is tracked but never consumed** (OBS-3).

## 7. UAimComponent — spring aim + body-yaw separation

- Tick OFF until `SetAimTarget` (TG_PrePhysics); fully disabled in pack mode (TPWCS V2 owns aim).
- Body: target+`bRotateWholeBodyWhenAiming` → `FixedTurn` @ 540°/s combat rate (actor and/or controller
  rotation per safety flags); else only cone-overflow @ 360°/s past 75° spine cone.
- Spine: semi-implicit Euler, stiffness 14, critical damping 2√k·ζ — stable at any dt.
- Outputs: aimed rotation (+ random error 2.5° yaw / 1.25° pitch), spine offset clamped (75°/50°),
  `IsAimedAtTarget`. LOD≥3 AI snaps (no spring).

## 8. UTacticalGrenadeComponent — counts, cooldown, G/H input

- 2 frag / 2 smoke (max 4 each), 3s cooldown, launch 1600 cm/s + 0.28 up-arc; AtLocation arc = 0.35×dist
  (clamp 150–600). G/H edge-trigger with **single-listener rule** (combat bridge owns input when present).
  Spawns `ATacticalGrenadeActor` (AlwaysSpawn, instigator set), decrements, writes back to Inventory
  (player only), plays `Leader_OrderEngage` (OBS-5 — wants a frag-out line), broadcasts thrown+inventory.
  BeginPlay pulls counts FROM inventory (player); `RefillGrenades` clamps + writes back.

## 9. USquadAITPWCSVisualsComponent — PURE visuals, zero gameplay

- `FindComponents` (BPC_Weapon* by name; weapon mesh by `TPWCS_WeaponMesh` tag/`WeaponMesh` name;
  char mesh by `Mesh`/`CharacterMesh0`/fallback). `ResolvePreset` (+ AssetRegistry auto-find by WeaponID).
- `InitializeWeaponPose` sets **only** left-hand IK (comment: touching AnimBP-owned state broke the AnimBP).
- `SetAimPose` (aimingState byte + traceEndPoint + aimedActor + AI-controller handle) / `ClearAimPose`.
- `PlayShotVisuals`: firing montage @1.5× + `bIsShooting?` 0.1s pulse + muzzle flash (Cascade+Niagara) +
  beam trail (Source/End/Target params + Scale) + impact + **spatial sound w/ distance layers**
  (1800/30000, speed-of-sound) via audio subsystem, `PlaySoundAtLocation` fallback.
- Reflection Set-helpers with **name-variant arrays** (`bIsShooting?`/`bIsShooting`, etc.) — TPWCS BP names vary.

## 10. USoldierAnimInstance — C++ computed AnimBP inputs

- `NativeUpdateAnimation` → `GetSoldierAnimRuntimeData(thresholds...)` → mirrors 30+ `bAnim*` vars
  (locomotion/state/cover/aim/IK/grip) so AnimBPs need no EventGraph math. Cached SoldierOwner+SoldierAI.

## 11. Style notes (additions to Step 2 §8)

11. **File-local `static` helpers** for reflection/lookup (no header pollution).
12. **Name-variant arrays** for every pack reflection touch (`{"currentHealth","CurrentHealth","Current Health",...}`).
13. **Classic/Pack dual paths** on nearly every system (aim, muzzle, damage, anim, weapon attach).
14. **Self-disabling ticks** + LOD-bucketed presentation (0.1/0.2/0.35/0.5/0.75s).
15. **By-TYPE `ProcessEvent` param fill** for calling BP-only interface functions.
16. **Verbose diagnostic logs** (`FireAnim:`/`DeathAnim:`/`[DamageBridge]`) that name the exact failure
    (skeleton mismatch, slot setup, missing AnimInstance) — keep this habit for new code.

## 12. Observations for future fix prompts (NOT fixed now)

- OBS-1: Weapon `BeginPlay` tuning sentinels mismatch header defaults (Damage 8≠15, FireRate 12≠8,
  SpreadPerShot 0.3≠0.4, Decay 5≠4) → tuning fill silently skipped for 4 fields.
- OBS-2: `HandleDeath` ally-voiceline branch unreachable (allies return earlier) — dead code.
- OBS-3: Ammo never consumed (clip/reserve tracked+displayed, `FireAtTarget` never decrements, no reload trigger).
- OBS-4: `Heal()` clears `bIsDead` — healing a corpse resurrects it.
- OBS-5: Grenade throw plays `Leader_OrderEngage` — needs a dedicated frag-out/smoke-out line.
- OBS-6: `IsSquadLeader()` sniffs names/tags ("Leader"/"Rostami") — any such-named actor turns immortal-ish.
- OBS-7: Allies never bleed out (15s floor @ 0.1×) vs `MaxBleedoutTime` 45s + HUD timer — reconcile display.
- OBS-8: `CompleteRevive` hardcodes walk 450 (ignores pacing/progression).
- OBS-9: Enemy corpse LifeSpan 10s vs tuning `CorpseLingerSeconds` 8s — two competing timers (pool? Step 5).
- OBS-10: `TryBindPackDamageDelegate` always reports bound; real work is the poll — delegate path vestigial.
- OBS-11: `ApplyTPWCSPlayerDamage` multi-dip risk (SquadAI HC + TakeDamage + ApplyDamage + prop write + HI_).
- OBS-12: Leader HP floors disagree (HealthComp 35 vs Leader Tick 50) — HUD may dip-then-snap.
- OBS-13: Player proximity hit radius 150cm vs soldier ray 95cm — generous player hitbox (design?).
- OBS-14: `SetLifeSpan(0)` in CompleteRevive cancels pending destroy — correct, but also cancels any
  designer-intended lifespan on that actor (edge case).
- Cross-refs → Step 4: SoldierAIController API surface (HasCombatThreat, CurrentLODBucket, PathSpeedScale,
  RestartStateTree, StopCombatPresentation, StopMovement, StateTreeComp, ReleaseHeldCoverReservation),
  SoldierRegistry (QueryRadius, CountHostilesNear, ApplySuppressionAlongPath, GetAllSoldiers, Register/Unregister),
  AISignificanceManager. → Step 5: `ATacticalGrenadeActor::LaunchGrenade`, corpse/pool handling.
  → Step 6/7: QuestNativeHUD Notify* API, AudioSubsystem voicelines + spatial sound, AdapterComponent,
  CinematicCombat `NotifyEnemyEliminated`, DevDebug `ToggleGodMode`.

✅ Step 3 complete — Characters & Combat fully read (~5,760 lines).
