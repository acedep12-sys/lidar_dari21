# Step 4 — AI Brain (READ COMPLETE ✅)

Files read in full (FIXED code, 35 files, ~7,060 lines):
- Controller: `SoldierAIController.h` (413) + `.cpp` (1986)
- Fireteams: `EnemyFireteamSubsystem.h` (75) + `.cpp` (379), `EnemyAttackCoordinator.h` (84) + `.cpp` (248)
- Commands: `SquadAICommandTypes.h` (67)
- StateTree tasks: EngageTarget (76+319), TakeCover (70+580), FollowLeader (68+263),
  LeaderPath (48+182), EnemyMission (36+143), HoldPosition (31+35), ShooterAIStateTreeData (99+59)
- Cover: `CoverTypes.h` (68), `CoverScanner.h` (94) + `.cpp` (404),
  `CoverSystemSubsystem.h` (104) + `.cpp` (567), EQS generator+test (23+48 / 23+70),
  `TacticalCoverGeneratorActor.h` (72) + `.cpp` (95)
- Shared memory: `SharedThreatMemory.h` (70) + `.cpp` (162)

## 1. ASoldierAIController — perception + memory + movement + combat glue

- **Ctor**: CrowdFollowing path-follower, Perception + StateTree + GameplayTasks comps, tick 0.1s, TeamId 255.
- **BeginPlay**: tuning pull (memory/suppression/combat ranges); ping subscribe; `SetupPerception()` **immediate**
  + 1s guarded fallback (S4-11 — killed the 1s spawn deafness; 2s StateTree net kept deliberately).
- **OnPossess**: team from soldier faction (name-sniff fallback, OBS-13); **runtime-spawns adapter** if the
  pawn lacks one; tick stagger by UniqueID; StateTree **Start-vs-Restart** (RestartLogic on dormant ST is
  silently ignored — the "AI stands idle forever" fix) + 2s force-start safety net; perception bind.
- **Team attitude**: pawn→controller team-agent resolution; **pack player pawns = team 0**
  (else Neutral → enemies idle instead of fighting the player).
- **Tick**: suppression decay (×0.5 in cover, × significance multiplier) → UpdateMemory → perception +
  registry polls (skippable at low LOD) → direct combat fallback → direct enemy movement (LOD<5) →
  leader mission pathing (+ fire-sprint flag) → B7-6 AI debug gizmos → S5-9 weather-sight poll (0.5s).
- **Commands**: `FSquadAIMoveCommand`/`FSquadAIAimCommand` mirrored to adapter; `ClearAimCommand` resets
  pack blackboard keys (`enemyActor`, `bIsInAttackRange?`) + restores orient-to-movement.
- **Fire avoidance** (all leaders + fire-nudged goals): `GatherFireHazards` (0.25s static cache, world-id
  keyed, fed by `SceneDecorator::CollectFireHazards`) → `AvoidFireHazards` (inside→sprint out; goal-push;
  4-iteration detour with **chord-vs-`FireSprintThroughMaxWidth`** sprint-through decision + perpendicular
  candidate scoring + nav projection) → `ApplySplineAndFireToGoal` (mission fallback → spline guide
  `GetFollowLocationSkipping` → fire avoid → 0.45s hesitate + 1.15s sprint window + look-at + trench detect
  → heading-based `PathSpeedScale` 0.62/0.82/1 × trench 0.68 → PATHDBG log + red/cyan/green-yellow draws).
  `GetEffectiveMoveGoal` (command → CurrentGoal → QuestRegistry; leaders get spline, others fire-nudge);
  `GetAllyCorridorSlot` (spline corridor or V-fallback); `RedirectIfPathHitsFire` (nav-path scan @ 0.45× pad).
- **Combat presentation** (all via adapter): SetCombatAimTarget (+ blackboard + focus + orient-off),
  TryStartBurst/IsBurstFiring/HasCombatAimCommand, StopCombatPresentation.
- **Perception**: sight/hearing/damage, ALL affiliations; S5-9 storm rescale (iterator-cached director,
  0.02 hysteresis, baselines kept so scaling never compounds); `OnPerceptionUpdated` (pawn+alive filter,
  verbose log, spotted/alerted VO, upsert); `UpdateMemory` (decay-or-refresh, purge dead); `UpsertPerceivedHostile`
  (update-or-add-if-visible + `SharedThreatMemory::ReportThreat`); `PollPerceptionForHostiles` (sight sense);
  `PollRegistryForHostiles` (0.25s, 0.75s @ LOD≥3, range cap 4500, LOS budget 3/1, close-range auto-recognize).
- **Direct combat fallback**: gates (threat conf ≥ 0.15 → alive → range → **S4-3 tuning gate** (OBS-2) → LOS |
  close-override) → aim+focus → first-engage VO + log → movement (fireteam-hold @ 2800, close @ 1500,
  allies never auto-advance) → 1s burst cadence + **AI grenades** (smoke if suppression ≥ 0.70;
  frag @ 800–2200, 35% roll).
- **Direct enemy movement** (enemies ONLY — allies would zigzag): threat advance (>550 dist or no LOS,
  lateral de-stack, 300 accept) / halt-to-fire / fireteam slot / player hunt (500–12000, octant spread) /
  Clear|Defend zone defense (0.5s scan cache, 600 accept).
- **Queries**: `GetPrimaryThreat` (conf×1000 − dist²×0.001, skips dead + grace); `HasLineOfSightTo`
  (0.12s single-target cache, **smoke-block check**, attach-chain walk); HasNearbyHostile (memory+registry).
- **Cover API**: controller-held move goal + reservation (survives StateTree re-entry — the anti-restart core);
  `RequestCover` async → `PendingCoverResult`/`bCoverQueryFinished`/`bLastCoverQuerySucceeded` fields.
- **Leader mission pathing**: warmup gate → combat block → 3500 player pacing → goal chain
  (effective → mission → quest-zone) → fire hesitate (stop + look-at) → redirect → 180 accept (80 sprint) →
  150-radius/1.5s repath throttle → focal point → PATHDBG.
- **Suppression**: `AddSuppression` + 0.55 crossing → `Ally_UnderFire` (allies only).

## 2. StateTree tasks (all: owner-or-pawn controller resolve, PATHDBG/verbose-gated logs)

- **EngageTarget**: enter (real cover → Waiting+crouch; open → Peeking immediately) · tick: downed→crouch;
  no-threat/conf<0.2/out-of-range → Succeed (reposition, never shoot hills); LOS required except in Waiting;
  **suppression gate** (enemies only — allies threshold 100, OBS-7); Waiting→Peeking (stand+aim+**single**
  burst start — re-starting snaps the montage); Peeking (aim tracking, **blocked-shot detection**:
  0.5s muzzle→threat poll, 3 strikes → Succeed/relocate; cover → Cooldown on duration/suppression×1.2;
  open → re-burst loop); Cooldown → Waiting or Succeed after 3 cycles. Params: 3-shot bursts, peek
  0.8–2.0s, cooldown 0.5–1.5s, range max(4500, tuning 8000).
- **TakeCover**: enter (8s reentry cooldown → Succeed so Engage isn't starved; pack close-combat ≤2200m+LOS
  → skip; **resume controller goal** on re-entry; 0.75s query throttle; `RequestCover` max(2500, tuning 3500))
  · WaitingForResult (reserve-new-then-release-old → move; else `BuildFallbackCoverGoal`; timeouts →
  Succeed-to-open-engage) → Moving (600 accept: real → crouch + **Rotating phase** (yaw-only RInterp 8/s,
  Step-4-#10 fix); fallback → clear + Succeed; 0.75s re-request; 8s stuck → Succeed) → Rotating → Arrived.
  Exit: **transfer reservation to controller** if still using (the anti-circle fix), else release; never
  clears goal/cover (Engage needs them). Fallback builder: obstacle-intercept first (7 offsets × 3 standoffs,
  nav-projected, natural-cover verified, mission-guard +350) → scored grid (4 fwd × 7 side, **no-retreat**
  guards, covered-score 2.5×progress − travel − side) → emergency lateral step.
- **FollowLeader**: downed-self → crouch · **revive priority** (downed ally ≤2500: approach 120 / crouch +
  `ApplyReviveProgress`) · leader find (override → cache → registry → iterator, 0.5s miss throttle) ·
  corridor-or-V slot · staggered repath (drift > max(600,550) or catch-up, ≥1.15+0.2×slot s, UniqueID jitter,
  fire-nudged) · shoot-while-follow (conf > 0.3, 2.5s). Never succeeds (anti-zigzag).
- **LeaderPath**: enter clears cover if calm · close combat (<1500: cancel move, aim, one cover request →
  move 300 → arrive 350 → Succeed; 1.5s timeout → Succeed) (OBS-16: arrival clears cover flags — verify) ·
  3500 player pacing · `UAITask_MoveTo` with 500-radius task reuse.
- **EnemyMission**: warmup gate · goal chain (effective → threat ≤12000 → player ≤12000 → mission zone →
  chain current; 12km cap kills omniscient cross-map hunting) · at-goal 300 → hold-alert · repath throttle
  (same-200 + moving + <2s skip) · partial-path MoveTo. Never succeeds.
- **HoldPosition**: aim-at-threat (+70 up) or stop presentation; optional duration → Succeed.
- **Evaluators**: Threat (primary + conf + visible + last-loc, TreeStart-primed), Suppression, Health.

## 3. Cover system — chunked async scanner + query dispatcher

- **CoverTypes**: `FCoverChunk` (points, scan flags, `NextLocalID`, 30s revalidation); `FCoverQuery`
  (querier/threat/radius/callback/chunks); `CoverHash` (floor-to-chunk; `(X<<16)|(Y&0xFFFF)` — **OBS-1:
  round-trip breaks for Y<0**, reservations silently fail there).
- **CoverScanner** (plain C++, 4-phase): floor samples 6×6 nav-projected around **pawn Z** (±2500,
  ±50000 fallback) → 8 dirs × 5 heights async traces (450cm, O(1) handle→context map) → harvest
  (best dir needs ≥2 blocked heights) → classify (High = crouch+head; Low = knee/crouch; Partial = head-only)
  + leans (perp-clear @ chest, over = chest-blocked + head-clear) + arc (blocked-dirs<80cm ÷ 7) + standoff
  70cm + dedup (25cm + 0.8 normal-dot). Query scoring: facing .4 + arc .3 + height .2/.14/.06 + leans .1.
  S4-9 bit-packed sample keys (negatives-safe); heights {15, 35, crouch, 100, stand}.
- **CoverSystemSubsystem** (tickable-only-when-busy): `RequestCoverAsync` (chunks + queue + per-chunk Z-ref)
  → 1 chunk scan/frame (S4-8) with **deliberate full-chunk budget overrun** (throttled verbose note; the old
  break starved samples → "no real cover") → finalize loop → resolve on all-ready **or** partial (0.6s +
  usable chunk) **or** 3s timeout (keeps waiting if partial found nothing). `ResolveSingleQuery`: skip
  reserved → radius → mission-guard (+900 unless close) → score (threat×1.5 + proximity×1.25 +
  mission-progress×0.0015) → **top-8 live verification** (protected +2, peek-shot +1 from 4 peek points) →
  best > 0. Reservations, `InvalidateArea` (explosions), `ForceScanArea`, color-coded debug draw
  (green/yellow/orange/red + purple reserved + cyan normals).
- **EQS**: generator (unreserved points in radius) + test (≤50cm match → `ScoreAgainstThreat`, SetScore) —
  visual-debug path; AI uses async directly.
- **TacticalCoverGeneratorActor**: Bake = `ForceScanArea` + grid raycast **count only** (S4-4 — the baked
  array fed nothing; BP API unchanged).

## 4. Shared threat memory + fireteams + coordinator

- **SharedThreatMemory**: `IsTickable()=false`, **timer-driven** 0.25s decay (auto-stops when empty);
  `ReportThreat` (higher-confidence wins, OBS-9: losers don't refresh time); team-filtered queries +
  best-threat; decay 0.15/s + 10s forget + invalid purge.
- **EnemyFireteamSubsystem** (timer-driven 0.5s assign, auto-stop): one team per spawner key;
  Register/Unregister (slots, AI flags, swap-remove); `AssignTeam` (alive + centroid + best-threat;
  leader = closest-to-threat else closest-to-centroid; threat-relative frame; roles cycle
  Lead/Suppress/FlankL/FlankR/Assault with geometric goals — lead @ threat−1400fwd, suppress @ −2400±450,
  flanks @ −500 ∓1800+250n, assault @ −800−200n ±280; no-threat V-formation on leader; Z = pawn Z;
  members `IngestSharedThreat` @ max(0.55, conf×0.85); 3s TEAMDBG log).
- **EnemyAttackCoordinator** (actor, 4Hz, off until `BeginAttack`): Gather (60% @ 800 staging or 15s) →
  Suppress (8s) → Flank (6s, 40% flankers to staging→attack-right +1500 point) → Assault (50% @ 600 or 20s)
  → Hold; min 4 to start; only sets `AssignedAttackPoint` + `CurrentPhase` per enemy (their ST does the rest).
- **CommandTypes**: `ESquadAIMoveMode` (None/QuestGoal/FollowLeader/CombatCover/HoldPosition) +
  `ESquadAIAimMode` (None/CombatTarget/InvestigateLocation) with `IsValid()` (mode set + non-zero location).

## 5. Style notes (additions)

17. **Controller-held state** for anything StateTree re-entry could reset (cover goal, mission goal, chain cache).
18. **Repath/move-request throttles everywhere** (0.75/1.0/1.25/1.5/2.0/2.5/3.0s by system) + same-goal radii.
19. **Static caches with world-id keys** + iterator-cached directors/zones (0.25–0.5s refresh).
20. **Chord math** for hazard crossing; candidate-score lambdas; geometric formation math (no data tables).
21. **Verbose-gated logs** (`AreVerboseDebugLogsEnabled`): `[SquadAIDiag]`, `[TEAMDBG]`, `PATHDBG`,
    `[SquadAIMemoryDebug]` — filter strings documented in comments.

## 6. Observations for future fix prompts (NOT fixed now)

- OBS-1 (verify HIGH): `CoverHash::ChunkToHash`/`FCoverPoint::GetChunkKey` round-trip corrupts **Y<0**
  chunks (Y −1 → 65535) → `ReserveCover`/`ReleaseCover` silently miss → AIs stack on one point / leak
  reservations on half the map. S4-9 fixed sample keys, not this one.
- OBS-2: header says keep `bAllowDirectCombatFallbackFire=false` "for production", but BeginPlay
  overwrites it from tuning (=true) → fallback fires by default. Confirm intended default.
- OBS-3: `CachedMaxChunkScans` header default 2 vs tuning 1 — Initialize wins; stale default only.
- OBS-4: V-formation math exists 3× (`GetAllyCorridorSlot`, `ComputeSlotPosition`, fireteam no-threat
  branch) — drift risk; consider one helper.
- OBS-5: static `GCachedQuestZone` has no world key (PIE re-run staleness; WeakPtr mitigates).
- OBS-6: `DirectCombatBurstCooldown` (1.25) is dead — code hardcodes 1.0s.
- OBS-7: allies' suppression gate threshold 100 = immune to suppression-gating (design?).
- OBS-8: fallback plays `Ally_EnemySpotted` for everyone incl. enemies (enemies get `Enemy_Alerted`
  only via perception events).
- OBS-9: `ReportThreat` losers don't refresh `LastUpdateTime` → shared threats can expire mid-observation.
- OBS-10: TakeCover Rotating eases full rotator toward yaw-only target — brief tilt possible on slopes.
- OBS-11: fireteam suppress/assault slot alternation uses ternaries with post-increments — subtle, verify offsets.
- OBS-12: `IsTickable()=false` + live `Tick()` in SharedThreatMemory/Fireteam = timer-driven by design,
  but "Tick at 4Hz" comments are stale.
- OBS-13: team/name sniffing (`"Leader"`/`"leader"`/`"Ally"` substrings) same fragility as Step 3 OBS-6.
- OBS-14: `CoverScanner::TraceBudgetPerFrame` dead since S4-8 (kept for Configure signature).
- OBS-15: EQS test builds unconfigured `FCoverScanner` per match — safe today (scoring uses no tuning),
  fragile if scoring ever reads tuning.
- OBS-16: LeaderPath arrival clears cover flags after moving TO cover — verify intended.
- OBS-17: `HasLineOfSightTo` single-target 0.12s cache thrashes under multi-threat checks (minor).
- OBS-18: `PerceptionMemory` + `TerrainCoverHelper` deleted in S4 batch (unreferenced parallel impls) —
  **delete those 4 files locally too** if your project still has them (pristine zip = restore path).
- Cross-refs → Step 5: MissionZone (MissionType, loc), QuestChain (FindPreferred/bIsActive/GetCurrentMission),
  QuestZone, QuestRegistry (CurrentActiveGoal), SplinePathActor (FindGuide/GetFollowLocationSkipping/
  GetCorridorSlotLocation/LogAllGuides/CorridorHalfWidth), SceneDecorator::CollectFireHazards,
  SandstormWeatherDirector::GetCurrentAIVisibilityMultiplier. → Step 6: QuestNativeHUD (Get/IsWarmupVeilActive).
  → Step 7: SoldierRegistry (QueryRadius/GetAllSoldiers/GetBroadPawns/ApplySuppressionAlongPath/
  CountHostilesNear/IsLineOfSightBlockedBySmoke), AISignificanceManager, DifficultySubsystem,
  AudioSubsystem (voicelines), Adapter (move/aim/burst API), PingSubsystem, DevDebug (bDrawAIDebugVisuals),
  AutoSetupManager::AreVerboseDebugLogsEnabled.

✅ Step 4 complete — AI brain fully read (~7,060 lines).
