# Bug Register (restructured 2026-09-10 — actionable core)

The verbose per-fix narratives were archived (`archive/BUG_REGISTER_verbose_2026-09-10.md`).
What remains is what still needs a human or an engine: **§A verify checklist**,
**§B decisions**, **§C one-line fix log** (regression reference), **§D lost items**.

Status marks: `VERIFY` (fixed in code, needs engine confirmation) · `ASSET` (code wired,
needs the PNG installed) · `DECISION` (needs owner call) · `LOST` (unrecoverable).

## A. In-engine verify checklist (work top to bottom)

### A1. Your prompt demands (menu/manager) — the ones you reported broken
- [ ] **Profiles:** create 2+ profiles, switch between them (IDs 410+), set different
  avatars (400+), restart — all persist; chosen avatar shows in the main-menu header.
- [ ] **Farsi name:** type a profile name with OS keyboard on English — Persian chars still
  appear (ISIRI keymap); try the on-screen Farsi keyboard + FA/EN toggle (ID 453).
- [ ] **Cells bar:** progression screen shows a hollow bar that fills cell-by-cell with
  upgrades — no sci-fi styling.
- [ ] **Armory:** weapon art large (168px rows + widescreen showcase); G3A3/AK47 usable
  from the start; locked weapons show level+XP reason; Unlock (298) deducts XP and works;
  Equip (299) works. **Medals (I-1):** click every achievement card — nothing launches.
- [ ] **Fonts:** all menu + HUD text at 1.15× (`HUDFontScale`, tunable in-editor).
  If still small, raise the multiplier — layout is unaffected by design.
- [ ] **Borders:** chiseled/3D frames behind every menu section + pause/inventory/veil.
- [ ] **Maps:** all 3 theater previews render (Dehlavieh, Bostan, Khorramshahr). If any shows
  "empty iron", read the Output Log `[MainMenu] Map preview missing for MapID` line — it
  names the file to install.
- [ ] **Difficulty:** 4 cards incl. new era-accurate Legendary (no fantasy vibe); picking
  one launches deployment (only from the map screen).
- [ ] **Quran/radio:** small bare images, verses render line-by-line (not letter-by-letter),
  diacritics intact.
- [ ] **Supplies:** inventory counts (medkits/grenades/smoke) match gameplay; throws
  decrement; zero grenades = cannot throw; crates/pickups refill; medkit use consumes one.
- [ ] **Health card + ID tag:** card icon left of the HP bar; metal tag in wallet Card 2.
- [ ] **Notes:** placeholder art shows; drop `Note1.png`… into `Textures/Notes/` → appears.
- [ ] **Leader/allies:** Rostami can never die or be downed; allies down but never die;
  reviving a downed ally never makes them vanish; no skeletal-mesh teleport error in log.
- [ ] **HP bar:** drains smoothly from spawn (no freeze-until-near-death).
- [ ] **Revive:** no phantom damage right after revive/respawn (grace window active).
- [ ] **Enemies:** advance/attack instead of wandering in circles (if circling persists, it
  is movement-level — repro with verbose AI logs).
- [ ] **Pause → menu:** reaches the main menu; if it shows a config error instead, fix
  `MainMenuLevelName` on the HUD (that error replaced the silent drop-back-to-game).
- [ ] **Fist:** full-color fist icon on the unarmed weapon plate (replaces mono stock).
- [ ] **Shaper torture:** run console `TestFarsiShaping` → 6 IN/OUT lines, all sane.
- [ ] **Living menu (J-1):** bottom-third dust streaks drift, embers rise, fog bands crawl,
  sand motes float, emblem flickers like lamplight. Toggle `bReducedMenuMotion` freezes it.
- [ ] **Menu polish (J-2):** button hover eases (~150ms, slight grow + glow); click dips the
  button; screen changes fade; subtle film grain over everything (toggle `bMenuFilmGrain`).
- [ ] **In-game HUD AAA (K-1):** low-HP vignette throbs with heartbeat + tunnel when critical;
  fire flickers in two bands with ember specks; suppression tunnels and sways; hitmarkers punch
  outward (kill = larger + red + ring); directional arcs glow; weapon-plate health bar has gloss/recess.
- [ ] **Full difficulty set (K-2):** all 4 cards share painterly paper-edge, no baked text — Recruit
  (dawn berm), Regular (keffiyeh advance), Hardened (RPG trench), Lethal (legend veteran) — plus
  new medals velvet (green + tulip) and loading trench (night flare) installed to `Textures/`.

### A2. Systems fixed this workspace (spot-check)
- [ ] **Loading screen:** survives travel, shows ≥1 s, auto-completes (P1-6).
- [ ] **Damage:** one SquadAI + one pack-enemy hit = exactly one damage path and one death
  event; last-kill slow-mo can trigger (P1-1/P1-4).
- [ ] **Difficulty:** survives respawn/pool/travel (P1-3). **Fire:** single-DPS, opt-in only,
  no fire boxes on non-fire decor (P1-9).
- [ ] **Audio:** one stinger at mission end; crossfades don't swell; shot VFX single-pipeline
  (P1-A1…A4). **Deaths:** exactly-one notifications; pooled reuse doesn't early-Clear (P1-Q).
- [ ] **Travel:** widget/menu travel never crashes on stale delegates (H-1/H-2); save/load
  cross-map restores once, no duplicate rewards (B6-8/P0-3).
- [ ] **Settings:** clicks actually apply (motion blur, subtitles gate chatter, FOV,
  volumes, language live re-skin) (B6-4/B6-9/P1-L2).
- [ ] **Art audit:** `SquadAI.CheckAssets` → `[SQUADAI_ASSET_AUDIT]` lists what's found vs
  missing; game never visibly breaks on missing art (procedural fallbacks).

## B. Decisions needed from owner

| # | Decision | Blocks | Notes |
|---|---|---|---|
| D1 🔴 | C8-3 module macro: keep `IMPLEMENT_PRIMARY_GAME_MODULE` vs `IMPLEMENT_GAME_MODULE` + `.uproject` entry | First compile | Only blocking question left |
| D2 | UMG future (B6-2/P1-8): delete the two suppressed UMG stacks vs finish minimap/compass binding | Polish | Canvas HUD is live; UMG collapsed + swept |
| — | D3 damage scope, D4 bleedout ("allies never die" per owner), D5 briefing nav (fixed P1-7), D6 kill-XP (Tuning `KillXP`), D7 AI ammo (by design) | — | All resolved, no action |

## C. Condensed fix log (one line per fix — regression reference)

- **P0:** P0-2 dup `Command_Hold` case deleted · P0-3 public `RestoreMissionState` wrapper.
- **P1:** P1-1 single-path damage + pack XOR + bridge re-baseline + AI damage sense ·
  P1-2 diagnostics dev-gated, bridge first/unconditional · P1-3 `ApplyToSoldier` hooks ·
  P1-4 zone-owned last-kill + real headshot flag · P1-6 travel-surviving loading +
  handshake · P1-7 Briefing→ID 13 · P1-9 fire opt-in + MAX-DPS · P1-A1…A4 stinger/crossfade/
  fallback/VFX · P1-Q1 exactly-one death + idempotent binds · P1-Q2 pool re-registration ·
  P1-P1/P1-P3 audit/FX gates · P1-L1 Farsi digits/separators/tashkeel · P1-L2
  `OnLanguageChanged` + saved-lang honor · P1-L3 `TestFarsiShaping` harness ·
  P1-5 slow-mo math verified correct · P1-8 UMG→D2.
- **B4/B5:** all AI-brain + mission items fixed (S4/S5 batches; 2 stacks by design).
- **B6:** slots/getter, circle draw, settings apply, ammo fields, completed count, surgical
  restore, half-settings residuals, ally write path, post-load ticker, GameUIScale, shape/
  sweep/slot perf, voiceline path, prompts/N/re-init, **global-ID rule** (F-G3), CDO guards,
  dossier wiring.
- **B7:** budgets, cooldowns, slow-mo caller, headshot, `CommandHoldVoicelines`, cheats,
  mortar path, bridge chokepoint, prompts, E-arbitration, turret lock, relic screen.
- **C8:** C8-1/2/4/5 fixed · C8-3→D1 · C8-6 StateTree sigs cleared · C8-8 art track.
- **Step2/3:** EnemyCounterText, unlock gate+deduct, multi-profile persist, 0-XP kills,
  level dup sync, NavInvoker→Tuning, G/H EI entries, revive walk cache, floors/XP→Tuning,
  leader override, bridge rename, multi-dip closed, AI-ammo + escape cleared.
- **F-batch:** F-C1…F-G14 (dup case, UPROPERTYs, includes, guards, counter text, unlock,
  IDs, chunk sign, spawner space/tag, pack-HP, kit gate, resurrect, equip, sentinels,
  UMG sweep, hearing, dead fetch).
- **G (prompt):** G-1 leader immortality (incl. pack-side veto) · G-2 all-mesh revive ·
  G-3 travel validation · G-4 pack-scale cache · G-5 revive grace ×2 paths ·
  G-6 repath throttle + hysteresis · G-7 armory restyle + fallbacks · G-8 borders both
  HUDs · G-9 map path ladder + diagnostic · G-10 lines verified · G-11 counts verified +
  medic voiceline · G-12 card/tag wiring · G-13 note slots + drop-in · G-14 1.15× both HUDs.
- **H (mega-5 hunt):** widget NativeDestruct unbinds, EndPlay unbinds, relic cache,
  leader chip→Tuning.
- **I-1 (mega-6):** achievement IDs 500+i → 520+i + difficulty branch state-guarded.
- **J-1 (mega-7):** living menu — 42 ground-dust streaks, 16 ember sparks, 6 fog bands,
  sand 45→70, emblem lantern flicker, `bReducedMenuMotion` accessibility toggle.
- **J-2 (mega-8):** AAA polish — eased hover ramps (~150ms, 1.03 grow), press dip, 350ms
  screen fade, film grain (`bMenuFilmGrain`); research-backed timing (100–200ms feedback).
- **K-1 (mega-9):** in-game HUD AAA — layered blood vignette (heartbeat double-thump), dual-band fire,
  tunnel suppression (sway), punch hitmarker (scale + glow + kill ring), directional glow, plate gloss;
  7 edits, validators clean.
- **K-2 (mega-9 art):** difficulty set unified painterly paper-edge + medals + loading — **DELETED** in mega-10 per pale/android feedback.
- **L-1 (mega-10):** 5 replacements saturated (volumetric dust, golden hour, baked brass borders, G3/RPG forward), KhuzestanDesertWar from rostami ref + triple-depth panels/text — **superseded** by L-3 (baked borders removed).
- **L-2 (mega-11, your 4 notes):** **Borders separate** — `UI_Frame_TacticalBorder_Gold.png` + `UI_Frame_MedalSocket.png` as distinct assets (PBR brass, not baked); code `DrawChiseledTacticalPanel/Box` now triple-depth (shadow 0.45 + highlight 0.09 + recess 0.18 + pinstripe 0.55 + 1.8px laser) and 9-slice path when texture assigned (Unreal `Canvas` + `LoadTextureSafe` + `DrawTexture` 9-slice). **Soulful gaze** — Recruit/Regular **replaced borderless** looking at camera (Hardened you rated best kept as template; Recruit now has Iran patch, Regular keffiyeh run, both eye contact). **Loading unrealistic** — replaced with net-helmet muddy trench, soulful faces (was CGI doll). **Honor system** — medals background **cleaned** (no baked circles); new per-icon `FrameMedalSocketTexture` drawn in `DrawAchievementsScreen` (80×80 frame + 68×68 icon) for exact placement (fallback to `DrawChiseledTacticalPanel`); honors code now `MEGA-11` tagged. Weapons verified barrel-forward. Art moved to `content/texture/` per your folder (mirrored). 15 PNGs, validators clean.


- **AAA-MM (2026-09-12 main-menu restructure):** `AAA-MM-1` legacy UMG ignored/removed at Canvas draw time per owner order; `AAA-MM-2/3` command header + telemetry pill rebuilt; `AAA-MM-4` true transparent-center 9-slice frame overlay added to `DrawChiseledTacticalPanel` while preserving procedural fallback; `AAA-MM-5` main menu rebuilt as AAA command deck + commander dossier + utility rail. New texture foundation delivered in `Content/Textures/` (gold/crimson frame, medal socket, buttons, loading bar, health card, fist). Validator clean; needs local UE compile/PIE.


- **AAA-B2 (2026-09-12 map/difficulty/armory + no-gold palette):** `AAA-B2-0` default theme changed from gold to Rostami field-slate/teal (compat filename retained); shared pinstripe/button hover cooled; `AAA-B2-1` Map Select rebuilt as recon board; `AAA-B2-2` Armory rebuilt as gunsmith workbench; `AAA-B2-3` Difficulty rebuilt as cinematic deployment cards; `AAA-B2-4` difficulty-card click guard corrected to `NewGameDifficulty` while medals stay `520+i`. Field-slate texture pack regenerated. Validator clean; needs local UE compile/PIE.

## D. Lost / irrecoverable

- B7-12…17/22…26 (Step-7 doc truncated in all copies) — re-derive from code if symptoms
  appear. Everything else ever reported is in §C above.


- **AAA-B3 (2026-09-12 progression/profile/achievements direct workspace pass):** `AAA-B3-0` milestone progress track cooled to field-slate/teal; `AAA-B3-1` Progression rebuilt as doctrine operations board + persistent `ActiveProgressionInspectIdx` so the inspector/action no longer falls back to node zero; `AAA-B3-2` Profile rebuilt as service dossier while preserving profile/avatar/name/keyboard IDs; `AAA-B3-3` Achievements rebuilt as separate-socket honors case while preserving medal IDs `520+i`. New Batch 3 texture set generated into all active texture mirrors. Validator clean; needs local UE compile/PIE.


- **AAA-MW-1 (2026-09-12 reference-style main menu):** per owner reference screenshot, main menu Canvas UI rebuilt into modern-warfare-style dark glass/brass layout with top-left profile strip, left command stack, right mission/objective/map cards, top utility rail, and bottom quick-start CTA. Main menu labels are English-only; Arabic/Persian codepoint check for `DrawMainMenuScreen` returned 0. Existing navigation IDs preserved. Validator clean; needs local UE compile/PIE.
