# Fix Log — errors I found myself (applied 2026-09-10)

All fixes applied to `extracted/lidar_rostami_a_FIXED/SquadAI/`, each with an `F-` code tag in a comment
at the edit site. Verification after every batch: patched `validate_codebase.py` (230 files — zero brace/
paren issues) + full-label duplicate-`case` rescan (**0** remain) + targeted greps below.

## Compile blockers (editor AND packaged builds)

- **F-C1** `Private/Performance/SquadAIAudioSubsystem.cpp` — deleted the 2nd identical
  `case ETacticalVoicelineType::Command_Hold:` (duplicate-case hard error). `case` count now 1.
- **F-C2** `Public/SquadAIWeaponVisualPreset.h` — `UPROPERTY(Transient)` on all 12 `Loaded*` cache members
  (bare `TObjectPtr` = UHT-rule violation + GC-invisible: muzzle/trail/montage/sound assets were collectible).
- **F-C3** `Private/Actors/SquadAIAutoSetupManager.cpp` — moved `SquadAIFXManagerSubsystem.h` + `NiagaraSystem.h`
  includes to top level (BeginPlay uses them at runtime; packaged builds failed) + removed a duplicate
  TPWCSVisuals include.
- **F-C4** same file — `PostEditChangeProperty` definition wrapped in `#if WITH_EDITOR` (matches the guarded
  declaration); deleted the `#else Super::…` branch (that API doesn't exist in game builds).

## Data corruption

- **F-D1** `Public/SquadAITuning.h:409` — `EnemyCounterText` was U+0006 control chars + literal hex digits →
  `TEXT("دشمنان")`.

## Gameplay / logic

- **F-G1** `SquadAIProgressionSubsystem.cpp` — `UnlockWeapon()` was unconditional and free; now gates on
  `CanUnlockWeapon()` and deducts `XPCostToUnlock` from `TotalXP` (the safe wallet: level-ups run off
  `CurrentLevelXP`, so spending never de-levels) + syncs the active `SavedProfiles` entry. `CanUnlockWeapon()`
  also gained the XP check with a Farsi fail reason.
- **F-G2** `SquadAIMainMenuHUD.cpp` — armory unlock button enable/label now come from `CanUnlockWeapon()`
  (was level-only → dead button when gated by XP); label shows cost, or the fail reason when gated.
- **F-G3** same file — **real 600–609 ID collision**: Farsi-keyboard branch sat above the load-slot branch in one
  shared handler, so load-slot and relic-card clicks typed Persian chars instead (load branch unreachable).
  Slots → 700s (+ handler), relic cards → 750s (hover-selects, no handler needed). 700/750 ranges were free.
- **F-G4** `Public/SquadTypes.h:95` — `GetChunkKey()` decoded Y without sign-extension (Y −1 → 65535), so
  `ReserveCover()` silently missed on negative-Y map halves → AIs stacked on one point. One-cast fix.
- **F-G5** `WaveSpawner.h/.cpp` + `AutoSpawnZone.cpp` — auto-zone ring coords are WORLD-space but the spawner
  ran them through `TransformPosition()` (double-transform: enemies at 2×Center + offset). New
  `bSpawnPointLocationsAreWorldSpace` flag; manual/MakeEditWidget local use unchanged.
- **F-G6** `AutoSpawnZone.cpp` — spawned spawner now also gets the zone tag as an ACTOR tag
  (`Tags.AddUnique(Tag.Tag)`): Defend lookup searches actor tags, the registry `SpawnerTag` alone never matched.
- **F-G7** `MissionZone.cpp::RespawnPlayer` — added the missing `RestorePackHealth(Player)` (pack player sat at
  0 HP → death poll re-failed instantly) + `HealthComp->Revive()` instead of manual flags (broadcasts).
  Mirrors the known-good `RevivePawnAt`.
- **F-G8** `FirstAidKitActor.cpp::ConsumeKit` — ground kit was consumed even at full HP + full stock (5).
  Now returns `false` early (kit stays) unless the player needed healing or a kit could be banked.
- **F-G9** `HealthComponent.cpp::Heal` — no longer clears `bIsDead` (healing a corpse resurrected it);
  `Revive()` is the only un-dead path. Companions: dev god-mode cheat now calls `Revive()` (F-G9b); bridge
  medkit guard skips the dead so no kit is wasted on a corpse (F-G9c).
- **F-G10** `SquadAIInventorySubsystem.cpp::EquipSelectedWeapon` — fell off the end with `return true` when no
  component matched → `false` + warning log.
- **F-G11** `WeaponComponent.cpp::BeginPlay` — 4 tuning sentinels mismatched header defaults (15/8/0.4/4 vs
  8/12/0.3/5), so tuning fill silently never ran for Damage/FireRate/Spread/Decay. Sentinels corrected.
- **F-G12** `QuestNativeHUD.cpp` BeginPlay sweep — blanket `WBP_` match collapsed the owner's own widgets too;
  narrowed to the explicit legacy/pack list (mirrors the periodic sweep).
- **F-G13** frag grenade + explosive barrel + mortar shell — detonation now calls
  `UAISense_Hearing::ReportNoiseEvent` (4.5/5.5/7 km ranges): explosions were completely silent to AI hearing.
- **F-G14** `SquadAIProgressionSubsystem.cpp::SaveProgressionToDisk` — removed dead `SaveSys` fetch (null-guard
  only; body uses `UGameplayStatics`).

## Deliberately NOT changed (queued for your next prompt — §2 of NOTE_ERROR_AUDIT.md)

Design-judgment items (0-XP kills, NavInvoker radii, input legacy, revive speed, HP floors, name-sniffing,
AI defaults, mission edge cases, ID-namespace discipline), the `IMPLEMENT_PRIMARY_GAME_MODULE` integration
decision, StateTree signature verification, and anything needing engine headers or art.
In-engine spot-checks for this batch: unlock a weapon with insufficient XP (reason shows, no deduct) →
earn → unlock (deducts) · load-slot clicks load (no Farsi chars typed) · relic clicks don't type · kit at
5 + full HP stays on the ground · respawn restores pack HP · explosions alert nearby AI · AI reserves distinct
cover on negative-Y map areas.
