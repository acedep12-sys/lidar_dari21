# Code Style & Fix-Workflow Rules (binding for every edit)

Conventions observed across the module + hard rules learned from two sessions. Per-system details live in
the STEP docs; this file is the enforceable core.

## A. Module / compile hygiene (verified by scans)

1. Every engine `#include` root must map to a `Build.cs` module; editor-only headers (`Kismet2`,
   `AssetTools`, `UnrealEd`) inside `#if WITH_EDITOR` in `.cpp` only — and any *use* of them must be
   guarded too (C8-1, F-C3, F-C4 class of bug).
2. Guarded declaration ⇔ guarded definition, always paired (F-C4). Check packaged (`WITH_EDITOR=0`)
   mentally for every editor-touching edit.
3. `TObjectPtr` member ⇒ `UPROPERTY()` above it, no exceptions (`Transient` for runtime caches) (F-C2).
4. No `private:` API may be called cross-class without a friend or public wrapper (P0-3 class of bug).
5. Includes must be direct, not unity-leak-dependent (C8-5). New subsystem use ⇒ new include.
6. Global engine state set in `StartupModule` must carry a comment with its replacement path (P-2).

## B. Gameplay code conventions (as found — follow them)

7. **Damage chokepoint:** all SquadAI damage flows through `UHealthComponent::ApplyDamage` (leader/grace/
   invincible/cheat rules live there). No direct `CurrentHealth`/`bIsDead` writes outside `HealthComponent`
   and save/restore paths (B7-11, F-G7, F-G9).
8. **Revive vs heal:** `Revive()` is the ONLY path that clears `bIsDead`; `Heal()` never resurrects (F-G9).
9. **Pack bridge:** fuzzy multi-name reflection (double→float→int tolerant), cached components, throttled
   warnings, retry-forever (no self-disabling searches), pack-max-aware restores (never hardcoded 100).
10. **Consumption rule:** never consume/destroy a pickup unless it did something useful — capacity + need
    checks BEFORE the consume point (O3, F-G8).
11. **Menu button IDs are GLOBALLY unique** (the click handler is one shared chain; per-frame rebuild only
    isolates registration, not handling) — F-G3 corrected the old per-screen rule. New screen ⇒ new range.
12. **E-key:** exactly one consumer per press — HUD arbitration owns it (`TryConsumeWorldEPress`), revive wins
    over props, turret exit stays ungated (B7-19).
13. **AI tuning:** all numbers in `USquadAITuning`, read via `Get()`; BeginPlay sentinels must match header
    defaults exactly (F-G11). Subsystem `Get()` static accessors; `DECLARE_DYNAMIC_MULTICAST_DELEGATE` for
    BP-observable changes; `USquadAI*` save slots named `SquadAI_*`.
14. **Cover reservations** keyed by `(FIntPoint, LocalID)`; hash helpers must round-trip negatives (F-G4).
15. **Farsi strings:** `TEXT()` literals ( Persian directly) or single `\uXXXX` escapes; files stay bytesafe
    UTF-8; never double-escape; bounded text auto-shrinks (Q7/M3); test shaping at real sizes.
16. **Null-tolerant art:** every texture draw site needs a procedural fallback (TEXTURE_AUDIT rule); code must
    never visibly break when art is missing.

## C. Fix-workflow rules (process — non-negotiable)

17. **Fix-marker tags:** every edit carries `// <ID>:` (`F-G1:`, `S5-3:`…) explaining what/why. No silent edits.
18. **Atomic apply:** one writer per file (parallel same-file edits clobber); scripts assert exact match counts
    and write per-file-atomically (fail safe, no partial writes).
19. **Re-validate every batch:** patched `validate_codebase.py` + full-label dup-case rescan + targeted greps
    before reporting done.
20. **Register discipline:** `BUG_REGISTER.md` updated with every fix (status + fix ref + location).
21. **Never-compile-tested discipline:** every batch ships in-engine verification steps; engine-only APIs go to
    the first-compile watchlist, never asserted.
22. **Workspace-is-deliverable:** no patch scripts for the owner, no manual file ops, no images in workspace
    (use→path map in `IMAGE_USE_MAP.md` instead).
