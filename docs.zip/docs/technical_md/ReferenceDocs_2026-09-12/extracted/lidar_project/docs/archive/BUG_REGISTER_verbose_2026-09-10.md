# Bug Register — single source of truth (updated 2026-09-10)

Status: `FIXED` (in workspace code) · `OPEN` (queued) · `CLEARED` (false alarm / by design) ·
`DECISION` (needs owner call) · `ENGINE` (verify on first compile) · `LOST` (unrecoverable from docs).

## P0 — release blockers (REVIEW_CONSOLIDATED)

| ID | Issue | Location | Status | Fix / note |
|---|---|---|---|---|
| P0-1 | Archive not buildable as UE project (no .uproject/Content/maps/pack) | repo level | DECISION | Owner has full project locally; integration steps in WORK_PLAN Phase 0 |
| P0-2 | Duplicate `case Command_Hold` (hard error) | AudioSubsystem.cpp:549-559 | FIXED | F-C1 (2nd identical case deleted; rescan 0) |
| P0-3 | Save calls **private** `Chain->StartMissionAtIndex` (hard error, no friend) | SaveSystem/SquadAISaveLoadSubsystem.cpp:417 → QuestChain.h:99-102 | FIXED | F-P03: public `AQuestChain::RestoreMissionState(SavedActive)` wrapper (REVIEW's recommendation); call-site switched; private calls now internal-only |

## P1 — critical / important (REVIEW_CONSOLIDATED)

| ID | Issue | Status | Fix / note |
|---|---|---|---|
| P1-1 | Three damage authorities; `DamagePackEnemy` bypasses events/AI/quest | FIXED | Player path FIXED (P1-1 batch): single TakeDamage (was 3x SquadAI-side) + pack func-XOR-fallback (was 2x) + `PostMirroredPackDamage` bridge re-baseline (kills delayed 4th application); pack-enemy hits now emit AI damage sense (4 sites). Pack-enemy parity CLOSED (P1-1b): Clear credit was already handled via `CleanupDeadEnemies` poll + `OnSpawnerEnemyDied`; added cine last-kill moment (zone-owned) + pooled-pack-member recycle (plug pool leak). |
| P1-2 | Diagnostics/combat auto-attach in production | FIXED | Diagnostic attach dev-gated (`UE_BUILD_DEBUG\|\|DEVELOPMENT`, forced-done otherwise); combat bridge attaches FIRST in ALL builds (gameplay-owned); wall-check fix + 5s timer unconditional. Role comment updated. |
| P1-3 | Difficulty only touches live soldiers; respawn/travel restore defaults | FIXED | New `UDifficultySubsystem::ApplyToSoldier` (extracted behavior) hooked at `RegisterWithSystems` (BeginPlay spawns, revives, post-travel) + `WakeEnemy` (pooled re-acquires skip BeginPlay). SetDifficulty walk kept for mid-game changes. |
| P1-4 | `NotifyEnemyEliminated(this,false,false)` — last-kill never fires | FIXED | Zone-owned: `CompleteMission` (Clear) fires `NotifyEnemyEliminated(null,false,true)` exactly once; cine guard relaxed for null+last (pawn was only null-checked). |
| P1-5 | Slow-mo `Duration*Dilation` direction | DISPUTED | My analysis: game-time timer + `Duration*Dilation` = Duration real seconds = CORRECT. In-engine timing check decides |
| P1-6 | Loading screen is a flash (widget dies at OpenLevel; `MarkLoadingComplete` callerless) | FIXED | Travel-surviving layer: widget nulled pre-travel, re-created via OnPostWorldInitialization in destination world (SpawnLoadingWidget shared by both paths); destination handshake: 0.25s readiness poll (BeginPlay+PC, 1s min display, 30s failsafe) auto-calls MarkLoadingComplete. Callers already route try-subsystem-else-OpenLevel — no caller changes. |
| P1-7 | Menu ID-10 collision (Briefing unreachable) | FIXED | Briefing button moved to globally-unique ID 13 (B6-19 rule); ID 10 = Profile only. TacticalBriefing reachable via bottom command bar; Back(99) verified present. |
| P1-8 | UMG quest HUD minimap/compass are stubs; two HUD architectures | DECISION | Same as B6-2: Canvas is live, UMG suppressed — delete UMG or finish it (owner call) |
| P1-9 | SceneDecorator fire-hazard defaults | FIXED | `bEnableFireDamage` default true→false (opt-in per entry or explicit force-all); per-entry DPS honored with actor fallback (was: actor always); new `FireDPSBySphere` map + poll aggregates overlaps by MAX (never summed). |
| P1-A1 | Victory/Defeat stinger double-play | FIXED | Removed redundant voiceline stinger calls at mission end — `SetAudioGameState` (PlayStinger: stops prior + ducks music) is the single owner. No other Victory/Defeat callers. |
| P1-A2 | `PlayTacticalVoiceline` no-manager fallback | FIXED | No-manager path now plays Tuning stingers for Radio_MissionSuccess/Fail (mirrors music fallback); other types have no tuning assets and stay silent (documented). |
| P1-A3 | Crossfade old-track volume | FIXED | New `CrossfadeStartVolume` captured at fade start; VolOut fades from captured absolute instead of the new target (kills loud-state swell). |
| P1-A4 | `PlayShotVisuals` double pipeline + ungated | FIXED | Niagara-preferred single pipeline per preset (Cascade fallback); muzzle/trail/impact gated by `CanSpawnImpactVFX` (fail-open). Fire-sound fallback path left (rare, has own distance layers). |
| P1-Q1 | Death unregisters before completion; duplicate owner notifications | FIXED | Exactly-one enforced: template spawner now unbinds in HandleSpawnedDied (was: stale owner double-counted pooled reuse -> early Clear) + Remove-before-Add idempotent binds in both spawners. Order verified benign: completion reads owner counters set-before-broadcast; registry consumers (leader/allies/HUD/significance) unaffected. |
| P1-Q2 | `BeginPlay` resets vs pool/wave reuse (difficulty/tuning) | FIXED | WakeEnemy calls RegisterWithSystems (profile applied AFTER registration; supersedes P1-3 standalone apply, absolute-set so re-apply safe) + symmetric SleepEnemy unregister (kills prewarm phantoms). Register/Unregister moved protected->public; both managers AddUnique-idempotent. |
| P1-P1 | DevDebug texture audit in `Initialize` | FIXED | Boot audit dev-gated (Debug/Development); on-demand preserved via `SquadAI.CheckAssets` Exec console command. |
| P1-P2 | Diagnostic wall-fix timer + runtime attach | FIXED | Same fix as P1-2 (timer kept: functional wall-check reapply, not diagnostic). |
| P1-P3 | Direct spawners bypass FX budgets | FIXED | `CanSpawnImpactVFX` gates (fail-open) in dust scatterer, BattlefieldDecorator.SpawnEffect, barrage strike (one gate covers fireball+dirt layers). Dust cap/teardown + decorator single-pipeline/teardown verified already sound. |
| P1-L1 | Farsi renderer fragile (digits, mixed text, diacritics) | FIXED | Digit runs (ASCII/Persian/Arabic-Indic) stay forward; number-separator stickiness (12:34, 100%); tashkeel PRESERVED + transparent to joining (was: stripped). ZWNJ-drop unchanged (CLEARED harmless). |
| P1-L2 | Language change doesn't refresh live world widgets | FIXED | Central OnLanguageChanged (native + dynamic) broadcast by setter (change-guarded) + ReloadFromDisk; MainMenuHUD + SetupActor subscribe/re-skin; SetupActor honors saved language (was always-Persian, ApplyEnglishMilitaryPreset had zero callers). QuestNativeHUD verified per-draw live. |
| P1-L3 | EN labels through Farsi draw path; RTL/LTR mixing untested | FIXED* | `TestFarsiShaping` Exec torture-test (mixed EN/FA, digits, timers, diacritics, ZWNJ, ligatures) logs shaper IN/OUT — one console command. *Visual confirm in engine. |

## B4 — AI brain bugs (Step 4 §7) — all FIXED except noted

#1 PerceptionMemory → S4-1 deleted FIXED · #2 TerrainCover → S4-2 deleted FIXED ·
#3 fallback-fire switch → S4-3 FIXED · #4 GeneratedCoverLocations → S4-4 FIXED (count int) ·
#5 patrol globals → S4-5 deleted FIXED · #6 reservation release → §1d FIXED · #7 omniscient hunt → 12000 gate FIXED ·
#8 trace spike → S4-8 mitigated (2→1 serialize + throttled log; full-chunk scans by design) ·
#9 MakeSampleKey → S4-9 int64 FIXED · #10 teleport-rotate → Rotating ease FIXED ·
#11 perception delay → S4-11 FIXED (immediate + fallback; 2 s timer clarified non-bug).

## B5 — mission bugs (Step 5 §8) — all FIXED (S5-1…S5-10)

FailMission callers · DefendTimerHandle deleted · ResolveMode modes · ticker Failed path · quest-log records ·
drive-level spawner unification (two stacks remain **by design**) · pool prewarm on activation ·
SpawnedEffects tracking · weather→sight rescale · dust null-fallback + pack-enemy zone counts.

## B6 — UI/HUD/save (Step 6 §8)

| ID | Status | Note |
|---|---|---|
| B6-1 slot mismatch | FIXED | `GetAutoSaveSlotName()` getter |
| B6-2 UMG suppressed | DECISION | Same as P1-8 (owner: delete or finish UMG; sweep now gated by `bSuppressLegacyUMG`) |
| B6-3 square circles | FIXED | Real circle draw |
| B6-4 settings placebo | FIXED | Clicks → `ApplySettingsToEngine` |
| B6-5 | CLEARED | `HasAnySaveGames` exists |
| B6-6 ammo field | FIXED | L1: `CurrentClipAmmo`+reserve |
| B6-7 completed==active | FIXED | Real `CompletedMissionCount` |
| B6-8 load restarts chain | FIXED | Surgical restore (§9) — introduced P0-3, also FIXED (row above) |
| B6-9 half-applied settings | FIXED | Volumes/language/FOV + residual CLOSED: motion blur via r.MotionBlurQuality, subtitles gate chatter box, CachedSettings+GetCachedSettings (sensitivity/invert exposed for out-of-module look input — verified zero in-module consumers). |
| B6-10 XP not gathered | CLEARED | Progression self-persists |
| B6-11 allies write-only | FIXED | L2 apply path |
| B6-12 post-load apply | FIXED | L4 post-travel ticker + P1-6 widget-layer residual CLEARED (travel-surviving layer + destination handshake). |
| B6-13 | CLEARED | Single timestamp |
| B6-14 1080p HUD | FIXED | H3 GameUIScale |
| B6-15 perf costs | MITIGATED | Shape cache, sweep backoff, slot cache; guidance/mortar traces remain (perf note) |
| B6-16 wrong voiceline | FIXED | Single bridge mortar path |
| B6-17/18/20 prompts/N/minimap | FIXED | Prompt loops, rotating N, pawn-change re-init |
| B6-19 ID namespaces | CORRECTED | Old rule ("per-screen unique is enough") was WRONG — the click handler is shared. New rule: menu button IDs must be **globally** unique (proven by F-G3) |
| B6-21 CDO subsystems | FIXED | No subsystem calls at CDO time |
| B6-22 dossier | FIXED | Profile-wired |

## B7 — audio/perf/tactical (Step 7) — B7-1…11 FIXED; B7-12…17,22…26 LOST

B7-1 budgets · B7-2 timestamp cooldown · B7-3 slow-mo caller · P1-4 FIXED (real headshot flag from TakeDamage bone + 1s freshness; last-enemy stays zone-owned) ·
B7-4→C8-4→F-C1 FIXED (`CommandHoldVoicelines` array wired with LeaderOrderMove fallback — works assetless; designer fills sounds later) ·
B7-5…9 cheats wired · B7-10 single mortar path · B7-11 bridge chokepoint · B7-18 prompts · B7-19 E-arbitration
(verified) · B7-20 turret lock · B7-21 relic screen. B7-12 (fort preset, name only) + B7-13…17/22…26: LOST
(Step-7 doc truncated in all copies) — re-derive from code if symptoms appear.

## C8 — compile risks (Step 8 §1)

C8-1 FIXED · C8-2 FIXED · C8-3 DECISION (PRIMARY vs GAME_MODULE — owner) · C8-4 FIXED ·
C8-5 FIXED · C8-6 CLEARED (6/6 task Enter/Exit decl==def + override — uniform sig, compiles-or-errors-loudly) · C8-7 info · C8-8 asset track.

## Step 2/3 read-phase issues

- EnemyCounterText corruption → FIXED (F-D1). Unlock free/unconditional → FIXED (F-G1/F-G2).
  Multi-profile session-only → FIXED (verified: `SavedProfiles` + switch-save).
- FIXED (mega-batch): 0-XP kills (RecordEnemyEliminated awards Tuning KillXP + bumps both counters; was callerless) ·
  `PlayerLevel`/`CurrentLevel` dup (synced — profile screen was frozen at 1) · NavInvoker→Tuning radii ·
  G/H (single-listener verified + `ThrowFrag/SmokeForward` EI-ready UFUNCTIONs; full EI map = content-only) ·
  revive walk (cached/restored) · leader floors→Tuning · `IsSquadLeader` (override in BeginPlay normalization) ·
  `TryBindPackDamageDelegate`→`InitPackHealthBridge` (was callerless).
- Step3-#2 multi-dip: FIXED via P1-1 batch (single-path player damage; re-measured up to 4× incl. delayed bridge re-apply — all closed).
- CLEARED: AI ammo infinite (by design — pack owns the mag) · `MissionCompletionMessage` double-escape
  (was already correct single escapes).

## F — this session's fixes (archive/FIXLOG_SELF_FOUND.md) — all FIXED + verified

F-C1 dup case · F-C2 12× UPROPERTY · F-C3 packaged includes · F-C4 PostEdit guard · F-D1 EnemyCounterText ·
F-G1 unlock gate+deduct · F-G2 armory button · F-G3 600→700/750 IDs · F-G4 chunk-key sign · F-G5 spawner
world-space · F-G6 spawner actor tag · F-G7 respawn pack-HP · F-G8 kit-consume gate · F-G9 Heal resurrect
(+cheat/bridge companions) · F-G10 equip return · F-G11 sentinels · F-G12 WBP sweep · F-G13 explosion hearing ·
F-G14 dead fetch. Post-fix: validator 230 files clean, dup-case rescan 0.

## This session's OBS follow-ups (from STEP2…8 notes)

- FIXED via F-batch: Step2 OBS-1/3/5/7 · Step3 OBS-1/4 · Step4 OBS-1(decode) · Step5 OBS-1/7/13 ·
  Step6 OBS-1/6 · Step7 OBS-1/noise/pickup · Step8 C-1/2/3.
- CLEARED: Step2 OBS-2 · Step4 OBS-1-injectivity worry · Step5 encounter re-query · Step6 OBS-3.
- QUEUED (design/nits, see archive/NOTE_ERROR_AUDIT §2 + STEP docs): Step2 OBS-4/6/8/9/10 · Step3 OBS-2/5/6/7/8/10/12/13/14 ·
  Step4 OBS-2…18 residuals · Step5 OBS-2/3/4/5/6/8/9/10/11/12/14/15/16/17/18 · Step7 difficulty-live-only (merge
  with P1-3) · Step8 §3 engine watchlist (`USCS_Node::SetParent`, `UDecalComponent::SetLifeSpan`,
  `ExportTextItem_Direct`, input-key APIs, URO deprecation, `SoldierCharacter.h:435` IWYU include).

## G — prompt gaps (PROMPT_GAPS.md, 2026-09-10)

| ID | Demand | Status | Note |
|---|---|---|---|
| G-1 | Leader Rostami must never die | FIXED | Closes pack-side one-shot bypass: bridge resurrects pack side when leader pack HP hits 0 between polls (veto twin) + override included in BeginPlay tag normalization; floors/damage-scale moved to Tuning. |
| G-2 | Healed/revived allies vanish (+pack teleport error) | FIXED | RevivePawnAt (the TELEPORT path) now freezes + re-shows ALL skeletal meshes incl. CharacterMesh0 + unhides (was GetMesh-only; CompleteRevive path already covered). |
| G-3 | Pause→main menu returns to game | FIXED | Pre-travel map validation (package + asset-registry scan; dep already present): missing map stays paused with error instead of silent drop-back-to-combat. Post-travel verify kept as backstop. |
| G-4 | HP bar frozen until near-death; correct after first death | FIXED | Root cause: MaxHP=self-normalized to CurHP when max-read failed on bigger scale → forced 1.0 until HP<100. Per-component observed-scale cache; never self-normalizes. |
| G-5 | Phantom directional damage after revive | FIXED | LIVE BUG: grace timer only reset at BeginPlay — never on revive/respawn. Now reset at end of CompleteRevive + in MissionZone::RevivePawnAt (after ClearCover). Verify in engine. |
| G-6 | Enemies wander/circle instead of attacking | FIXED* | Same-goal repath throttle now covers idle-failed (was every-tick fail-spam = jitter) + 300/450 arrival hysteresis + immediate first path. *In-engine behavior verify still recommended. |
| G-7 | Armory weapon art small/square/ugly | FIXED | Procedural fallback plates (thumb + showcase: topo grid + caliber watermark + name) replace blank holes when art missing; textured path untouched (168px thumbs already landed). |
| G-8 | 3D borders "for everything in menu" | FIXED | Row was stale: 34× DrawChiseledTactical in QuestNativeHUD verified (pause 3, inventory 21, veil 3). |
| G-9 | Map previews show "empty iron" | FIXED | Aligned: `Textures/Map_Preview_<MapID>.png` tried before legacy bare `<MapID>.png` (bare stem could never match authored `Map_Preview_*` files). Wired UPROPERTY + data-texture paths kept first. |
| G-10 | Quran verses word-by-word | ENGINE | Line loop + DrawFarsiTextBounded verified in code; P1-L1 tashkeel preservation covers Quranic diacritics — visual verify only |
| G-11 | Grenade/medkit counts: inventory-limited vs game-unlimited | FIXED* | Dual-layer heal verified correct in code (bridge restores pack side, SquadAI Heal reflects to BPC_Health, bHealed gate, no-resurrect); medkit now barks dedicated `Ally_Healing` voiceline (was: hold-position order). *Counts-sync verify in engine. |
| G-12 | Health card has no texture wired | FIXED | `HUDHealthCardTexture` slot wired (`/Game/Textures/HUD_Health_Card` + `Textures/HUD_Health_Card.png` fallback), drawn as 22px card icon left of HP bar; procedural layout unchanged when absent. Asset file still TODO (user). |
| G-13 | Handwritten notes as user-supplied images + placeholder now | FIXED | Data-driven slots: NoteID + wired NoteImage + ImageFile drop-in (`Textures/Notes/<stem>.png`, cached; INI `Note%d_Image`, default `Note%d`) rendered in relic inspect + rows; legacy index-list + placeholder kept as fallbacks. True drag-drop import = future engine-side feature. |
| G-14 | All fonts bigger | FIXED* | `HUDFontScale` (1.15) was bounded-path-only; now also applied in plain `DrawFarsiText` + `GetFarsiTextSize` (60 bounded + 24 plain callers covered). Tune the multiplier in-editor. *Visual pass. |
| DONE (prompt, pending engine verify) | Profile list+switch+avatars · main-menu avatar · Farsi name input (ISIRI 2901) · cells progression bar · weapon activation (F-G1/F-G2) · spawn grace · revive SquadAI-teleport · quit-flow attempt | ENGINE | Evidence in PROMPT_GAPS.md |

### G-batch fix record (2026-09-10, 16 edits, validator clean)
- G-1 FIXED (workspace): `bIsSquadLeaderOverride` flag (tick on level Rostami) + BeginPlay auto-tag + class-name
  check + HandleDeath veto now restores PACK side too + clamp warning when pack comp missing. Verify: Rostami unkillable.
- G-2 FIXED (workspace): CompleteRevive now freezes + re-shows ALL skeletal meshes (pack CharacterMesh0 included).
  Kills the teleport error + invisible-revived-ally. Verify: heal → ally visible, no error.
- G-3 FIXED (workspace): same-map guard — fake travel now shows a config error instead of loading back into game.
  If error appears, fix `MainMenuLevelName` on the HUD.
- G-4 CORRECTED: already fixed last session (MIN-across-sources bar) → ENGINE verify only.
- G-6 PARTIAL: team guards added to threat selection + shared intel (friendly-hunting impossible now). If circling
  persists it is movement-level → in-engine repro with verbose AI logs.
- G-7 FIXED (workspace): armory rows 88→116, thumbs 80×55→168×92 widescreen with tactical frame, re-spaced text.
- G-8 CORRECTED: already done (34× `DrawChiseledTacticalBox` in QuestNativeHUD) — earlier "ZERO" claim was wrong
  (checked the wrong function name). No code change.
- G-9 PARTIAL: once-per-MapID error log added (shows which MapID fails). Rest is asset-side: place/import PNGs.
- G-10 CORRECTED: line-based verses verified in code → ENGINE visual verify only.
- G-11 FIXED* (mega-5): dual-layer heal verified + dedicated `Ally_Healing` voiceline (enum appended last per BP-compat rule, 4s throttle, AudioManager array) → counts-sync verify.
- G-12 PARTIAL: metal tag render added to Card 2 (was wallet-only). "Crap image" = verify local assets imported.
- G-13 placeholder DONE already (FallenNotes art drawn in notes tab); drag-drop user images = future feature.
- G-5/G-14: FIXED in mega-5 (grace reset x2 revive paths; HUDFontScale extended to plain text path) — verify in engine.

## H — self-found static hunt (mega-5, 2026-09-10) — all FIXED except noted

Delegate symmetry audit (33 AddDynamic vs 20 RemoveDynamic): self-binds to own
components/overlaps die with their owner (SAFE); spawner death binds covered by P1-Q1;
mission-state binds are level-actor-to-level-actor (die together, SAFE); ping bind has
EndPlay unbind (SAFE). The genuine leaks were the two UMG widgets + two missing EndPlay
unbinds — all fixed below. Per-frame audit: relic-screen TActorIterator (fixed); FProperty
per-frame reflection measured negligible (FindFProperty = name-map lookup x small enemy
counts — DROPPED, no churn); shaped-text frame cache already covers DrawFarsiText.

| ID | Demand | Status | Note |
|---|---|---|---|
| H-1 | QuestHUDWidget binds world-subsystem ticker, never unbinds | FIXED | Added NativeDestruct: removes OnHudUpdated bind (ticker outlives the widget — next broadcast would hit a dead listener). |
| H-2 | QuestCompletionWidget never unbinds on destroy | FIXED | Added NativeDestruct: unbinds ActiveChain missions (SetQuestChain only unbound on swap). |
| H-2b | BattlefieldDecorator EndPlay lacks delegate unbind | FIXED | EndPlay now removes LinkedMission OnMissionStateChanged (early-destroy hardening). |
| H-2c | SplinePathActor EndPlay lacks delegate unbind | FIXED | EndPlay now removes TriggerMission OnMissionStateChanged (early-destroy hardening). |
| H-g | Relic screen runs TActorIterator every frame | FIXED | Setup actor (level singleton) resolved once into CachedRelicSetupActor (TWeakObjectPtr + fwd decl). |
| H-dup | HealthComponent leader chip hardcodes 0.25/35 | FIXED | New Tuning members LeaderChipDamageFraction (0.25) + LeaderMinChipHealth (35), [Leader] config; null-safe fallback keeps old values. |
