# Work Plan — phased roadmap (updated 2026-09-10)

Order: compile → verify in-engine → queued gameplay fixes → production hardening → new systems.
Art runs as a parallel track. Nothing here is compile-tested; every phase ends with acceptance checks.

## Decisions needed from owner (blocking marked 🔴)

| # | Decision | Options | Blocks |
|---|---|---|---|
| D1 🔴 | C8-3 module macro | Keep `IMPLEMENT_PRIMARY_GAME_MODULE` (SquadAI is the only game module) vs switch to `IMPLEMENT_GAME_MODULE` + `.uproject` entry | Phase 0 compile |
| D2 | UMG future (B6-2/P1-8) | Delete the two suppressed UMG stacks vs finish minimap/compass/snapshot binding | Phase 3 (P1-8) |
| D3 | Damage authority (P1-1/Step3-#2) | Confirm single-path refactor scope: SquadAI-only first, or SquadAI+pack together | Phase 2 scope |
| D4 | Bleedout rule | Keep "allies never die, bleedout frozen" vs bleedout timer that kills | Phase 2 (ally rules) |
| D5 | Briefing screen | Restore nav (grid entry) vs delete `TacticalBriefing` screen | Phase 2 minor |
| D6 | Kill-XP economy | Award per-kill XP? amount? (kills=0, tank=300, quest=800 today) | Phase 2 balance |
| D7 | AI ammo | Confirm infinite-AI-ammo by design (pack owns player mag) | clears Step3-#5 formally |

## Phase 0 — Compile (workspace + owner, 1 round-trip)

1. Apply P0-3 fix (workspace): public `AQuestChain::RestoreMissionState(SavedActive)`; save code calls it.
2. Owner: integrate module into local UE 5.7 project (copy `SquadAI/` → `Source/SquadAI/`, `.uproject` module
   entry, D1 macro), generate project files, compile Development Editor.
3. Watchlist (Step8 §3 + C8-6): StateTree signatures, `USCS_Node::SetParent`, `UDecalComponent::SetLifeSpan`,
   `ExportTextItem_Direct` 5-arg, `WasInputKeyJustPressed`/`IsInputKeyDown`, URO deprecation warning,
   `GFrameCounter` include (`HAL/PlatformTime.h` if lean PCH). Paste any error back → fix in workspace.
4. Optional but recommended: one `bUseUnityBuild=false` compile to prove include hygiene.
- Acceptance: clean editor build, PIE starts with zero red errors in 10 s.

## Phase 1 — In-engine verification (owner,_workspace on standby)

- Run `reference/prev_session/VERIFICATION_CHECKLIST.md` §§0–6 + `reference/prev_session/TEXTURE_AUDIT.md` §4 (reproduced in
  this plan's Appendix) + the F-batch spot-checks (archive/FIXLOG_SELF_FOUND.md tail): unlock deduct, slot clicks,
  kit-at-cap, respawn pack-HP, explosion AI reaction, negative-Y cover, Briefing reachability (expect: orphaned).
- Log greps: `Post-travel apply` · `Travel to menu` · `SQUADAI_ASSET_AUDIT` · `TakeCover` (Verbose).
- Every failure → new or updated `BUG_REGISTER.md` row → fix in workspace → owner re-pulls.

## Phase 2 — Queued gameplay fixes (workspace, prioritized)

1. P1-1 + Step3-#2: single-path player/enemy damage refactor (HIGH — 3× damage live today).
2. P1-3: difficulty profile at registration/spawn (+ save/load path).
3. P1-4: encounter-owned last-kill detection (slow-mo input).
4. P1-9: decorator fire-hazard defaults (off + per-entry DPS).
5. P1-A1…A4: stinger single-play, voiceline fallback, crossfade volume, single-pipeline shot VFX via FX budget.
6. P1-Q1/Q2: authoritative death notification ordering; pool-vs-BeginPlay tuning.
7. Step2/3 residuals: kill XP (D6), dup fields, NavInvoker radii, EI grenade input, revive speed, HP floors,
   name-sniffing, TryBind rename. Briefing nav (D5). `CommandHoldVoicelines` array wiring (needs asset).
8. Step4/5/6 residuals per register (minor).

## Phase 3 — Production hardening (workspace)

- P1-2/P1-P2: dev-gate diagnostics, cheats, auto-attach, wall-fix timer (`UE_BUILD_DEVELOPMENT`/profiles).
- P1-6: travel-surviving loading layer + destination handshake + cancel/fail paths.
- P1-P1/P1-P3: gate texture audit; FX/audio budget enforcement for direct spawners; lifetimes/teardown.
- P1-8/D2: UMG delete-or-finish. P1-L1/L2: Farsi hardening + language-changed refresh.
- P1-5: slow-mo timing check (expect: current code correct).
- Health-state invariant doc (current/max/dead/downed/ragdoll/registration owners).

## Phase 4 — New systems (deferred until owner asks; from STEP8)

P-1 packaged-build CI · P-2 multi-team solver (replaces `SquadAI.cpp` 2-team global) · P-3 replication ·
P-4 SmartObjects · P-5 significance LOD · P-6 GameplayAbility migration · P-7 vehicles · P-8 melee/stealth UI ·
P-9 day/night weather · P-10 attachments. Dependencies in `reference/session_steps/STEP8_COMPILE_AND_PLAN.md` §6.

## Art track (parallel; no PNGs in workspace)

57 unique `/Game/Textures` paths (see `IMAGE_USE_MAP.md`); code fallbacks cover all missing art (verified).
Priority: avatars → difficulty cards → fist color → radio/Quran tabs → menu vista → maps/weapons/progression/
silhouettes. Era rules (binding): 1980–88 Iranian side — steel helmets/keffiyehs/plain headbands/G3s/canvas
webbing/palms/turquoise dome/red tulip/girih star/Persian script/red crescent; zero readable Latin, zero
Western/WWI/US vibes; wallet closed with zero contents.

## Appendix — acceptance tests (merged: REVIEW + prev checklist + F-batch)

- Build: clean editor + (once) non-unity compile; PIE 10 s, zero red errors.
- Menu: every button reaches its state; slots load without typing chars; relic clicks don't type; unlock shows
  cost/reason and deducts; difficulty survives travel (after P1-3).
- Save/load cross-map: player/mission/allies/supplies/ammo/weapon/difficulty restore once, no duplicate rewards.
- Combat: one SquadAI + one pack enemy take exactly one damage path and one death event (after P1-1/Step3-#2).
- Encounter clear: exactly one last-kill event, correct slow-mo real duration, one stinger (after P1-4/P1-5 check).
- Fire: single volume DPS, no double damage, no fire boxes on non-fire decor (after P1-9).
- AI: no circling, distinct cover incl. negative-Y regions, explosions alert AI, storm slows acquisition.
- Kits/grenades: full-HP+full-stock kit stays; throws decrement once; crate refills.
- Stress 30 min: budgets reset, no stale decals/components, no unbounded loads.
