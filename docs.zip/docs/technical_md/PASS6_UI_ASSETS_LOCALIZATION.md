# Pass 6 — UI, assets, and localization

**Repository:** `lid_rostami123` at `1578dfb276d153cfac960d41275273339a0484a9`
**Source inspected:** `/home/user/project/extracted/source-full/Source/SquadAI/`
**Date:** 2026-09-21
**Status:** static source analysis only; no `Source/SquadAI` file was modified

## Scope and confidence boundary

Files traced end-to-end:

- `Private/HUD/` and `Public/HUD/`: `QuestNativeHUD` (385 + 3568 lines), `SquadAIMainMenuHUD` (636 + 4658), the seven small UMG widget classes (`QuestHUDWidget`, `QuestMissionWidget`, `QuestChainHUD`, `QuestCompletionWidget`, `MissionBriefingWidget`, `MissionMinimapWidget`, `CompassWidget`), `SquadAILoadingScreenWidget`, `SquadAIMainMenuWidget`, `FarsiTextHelper`.
- `Localization/SquadAILocalizationSubsystem` (77 + 449), plus a machine comparison of every static string-key usage against the built-in INI template.
- Asset pipeline: `Utilities/SquadAIAssetHelper.h`, `Performance/SquadAIAssetCacheSubsystem`, `BlueprintLibraries/SquadAIPackAssetResolverLibrary`, `BlueprintLibraries/SquadAIBlueprintAssetFactoryLibrary`, `Performance/SquadAILoadingScreenSubsystem`, `Config/DefaultEditorPerProjectUserSettings.ini`, `SquadAI.Build.cs`.
- Consumers: `GameFramework/SquadAIInventorySubsystem` (localization-backed arsenal/notes/radio/Quran), `Performance/SquadAIPlayerCombatBridge` (Esc/I input polling), `SaveSystem/SquadAISaveLoadSubsystem` settings application, `Actors/SquadAIMainMenuSetupActor`, `GameFramework/SquadAIMainMenuGameMode`.
- Archived review `docs/reference/prev_session/STEP6_UI_HUD.md` and the AAA menu patch docs (`AAA_MAIN_MENU_RESTRUCTURE_2026-09-12.md`, `IMAGE_USE_MAP.md`, `BUG_REGISTER.md`, `UI_POLISH_READTHROUGH.md`) for status comparison.

The archive contains **zero image/font/INI assets** — no `.png`, no fonts, no `SquadAILocalization.ini`. Consequently every asset statement below classifies as: *code contract verified* / *asset presence unverifiable in this archive* / *host project owns the asset*. The host project's Content, maps, GameModes, and Blueprint widgets remain unknown.

---

## 1. Executive conclusion

### 1.1 Three UI stacks, one actually authoritative — but by name-matching, not by contract

| Stack | Driver | Runtime status |
|---|---|---|
| Legacy UMG quest widgets (7 classes) | `QuestTickerSubsystem` snapshots + direct `AQuestChain` pulls | **Alive in code, suppressed at runtime** — `AQuestNativeHUD` collapses them by class-name substring at BeginPlay and via a periodic sweep |
| UMG menu shell + loading widget | `USquadAIMainMenuWidget`, `USquadAILoadingScreenWidget` | Menu shell is removed per-frame by `SquadAIMainMenuHUD`; loading widget is spawned by the loading subsystem and survives travel |
| Canvas HUDs (`AQuestNativeHUD`, `ASquadAIMainMenuHUD`) | `AHUD::DrawHUD()` immediate-mode | **The live UI.** ~8,900 lines of C++ doing everything UMG normally does: input hit-testing, localization, shaping, layout, animation |

The architecture is functional in development, but three structural weaknesses surface consistently:

1. **Suppression is string matching, not a lifecycle contract.** `AQuestNativeHUD::BeginPlay` and its sweep collapse any `UUserWidget` whose **class name contains** `WBP_`, `Weapon`, `Ammo`, `QuestHUDWidget`, `MissionBriefingWidget`, `CompassWidget`, `TPWCS`, etc. Any legitimate project widget that happens to contain "Weapon" or "Ammo" in its class name is silently hidden. The module simultaneously compiles five UMG widget classes it instructs itself to destroy.
2. **Localization is a custom INI subsystem, not UE's localization framework.** It works for `fa`/`en`, but the built-in INI template does not match the keys the code queries (~79% of queried keys are absent from the template), sections consumed by the inventory subsystem are missing entirely, and the output file is written to `ProjectDir()` — unsuitable for packaged/distributed builds.
3. **Settings→menu state has a confirmed boot-order leak** (P6-1) that produces a mixed-language main menu, and **the pause menu cannot be closed with Esc** despite its own label promising it (P6-2), because the Esc poller lives in a component that stops ticking while paused.

Most archived Step 6 defects (B6-1, B6-3, B6-4, B6-6, B6-7, B6-8, B6-9, B6-14, B6-15, B6-17, B6-18, B6-20, B6-21, B6-22) are **verified fixed in current source**. The Pass 6 work is therefore not re-finding old bugs; it is measuring what remains: two confirmed functional defects, one wide localization contract mismatch, one asset-import perf pattern, and a stack of design-by-substring assumptions.

### 1.2 Confirmed defects (new, not in previous passes)

- **P6-1 (functional, medium):** `ASquadAIMainMenuHUD::CachedMenuSettings` is loaded only in `NavigateToState(Settings)` and after settings clicks. On menu boot with an **English** saved setting, the menu renders mixed Persian/English and reports the wrong quality preset until Settings is opened or something is changed.
- **P6-2 (functional, medium):** The pause menu's "ادامه نبرد [Esc]" label is unreachable. Esc/[P] is polled by `USquadAIPlayerCombatBridge`, a pawn component whose ticking stops under `SetGamePaused(true)`; `DrawPauseMenu` itself reads only mouse input. Resume only works by mouse click.
- **P6-3 (contract, medium):** Localization INI template ↔ code key mismatch. 62 static queried keys; only 13 exist in the generated template. Missing: `[Inventory]`, `[FallenTroopNotes]`, `[RadioStations]`, `[QuranVerses]` sections entirely, 15 `[HUD]` helper keys, 19 `[MainMenu]` keys (including template providing `SubTitle`/`Btn*` aliases while code queries `GameSubtitle`/`Button*` names — user edits to the shipped keys silently do nothing), `Key_en`/`[Section.en]` overrides work but the shipped Persian defaults for those sections are not exported.
- **P6-4 (packaging, high for shipping):** `SquadAILocalization.ini` is written to `FPaths::ProjectDir()` if missing. At `ProjectDir` root it is not a staged content path; in an installed packaged build the directory is typically read-only. `ReloadFromDisk`/`GetActiveFilePath` therefore target an invalid location post-shipping. Same category: `FSquadAIAssetHelper` loose-PNG lookups at `FPaths::ProjectDir()/Content` etc. — fine in editor, silent-fall-back in shipping.
- **P6-5 (perf, low–medium):** Per-frame disk-stat storm in `DrawPauseMenu` and `DrawDeploymentVeil` when their textures are missing: `LoadTextureSafe` scans ~13 candidates with `FPaths::FileExists` + `FImageUtils::ImportFileAsTexture2D` attempt **every frame** until a texture is found or forever if absent. `BeginPlay` sites are guarded so only-missing cases loop.
- **P6-6 (policy, low):** Name-substring widget suppression (see §1.1#1) can hide unrelated project widgets; substring matching is the only mechanism.

---

## 2. UI stack inventory and ownership

### 2.1 `AQuestNativeHUD` — gameplay Canvas HUD (`QuestNativeHUD.h/.cpp`)

**BeginPlay (lines 83–148):** resolves ~20 textures through `FSquadAIAssetHelper::LoadTextureSafe` (weapon icons, veil art, button plates, loading bar, inventory items, notes art), forces `bSuppressLegacyUMG = true`, and collapses existing UMG widgets by class-name substring.

**Font resolution (317–336):** `SquadAITuning.HUDFontPath` → `Tuning.HUDFont` → `GEngine->GetMediumFont()`. The tuning object is the **only Persian font hook**; nothing in the module guarantees a Farsi-capable font — without one, all shaped text renders as tofu/Harfbuzz-missing glyphs. Asset presence unverifiable.

**Per-frame (`DrawHUD`, 2272–2477):**

1. `GameUIScale = clamp(ClipY/1080, 0.70, 1.35)` — resolution scaling exists (B6-14 fixed).
2. Dev hotkeys via `SquadAIDevDebugSubsystem`.
3. Legacy widget sweep every 1.5 s, backing off to 10 s after 3 consecutive empty sweeps (`TObjectIterator<UUserWidget>` + substring match, 115–146 and 2308–2331).
4. Exclusive modes (early return): pause → inventory → deployment veil.
5. Vignettes (low-HP, fire, suppression), directional damage arcs, hitmarker, reticle.
6. Compass ribbon with mission + leader pips (B6-18 fixed: leader pip drawn regardless of chain state).
7. Mortar aim marker / danger zones; middle-mouse aims, and a comment at 2408–2411 documents that firing was moved to the combat bridge (archived B6-16 wrong-voiceline + duplicate spawn fixed).
8. 3D pings, battlefield prompts (ammo, downed ally + revive progress, first-aid, **medical stations and turrets included now** — B6-17 fixed at 1264–1365).
9. Objective guidance vision (24-sample ground-clamped ribbon, throttled to 4 Hz).
10. Minimap with `USceneCaptureComponent2D`: re-init on pawn change/dead component fixed (B6-20, 423–493), ortho capture, rotating border "N", off-map border pips.
11. Squad status panel (leader + up to 3 allies, HP/bleedout bars, grenade counts), radio subtitles (gated by `bEnableSubtitles` cached setting), mission objective card (**only `AQuestChain`/`AMissionZone`** — director/encounter authorities invisible, matching Pass 5), defend countdown banner.

**Feedback API:** `NotifyDamageReceived` (8-slot ring), `NotifyHitConfirmed`, `NotifyAllyDowned`, `SetPlayerBurning` (connects to fire-status booleans from Pass 5), `AddPlayerSuppression`.

**Pause menu (2692–2949):** five Canvas buttons with localized strings from `[PauseMenu]` (all nine keys **are** in the template), save to `SaveSys->GetAutoSaveSlotName()` with toast (B6-1 fixed), restart/quit paths validate map existence (`DoesMapAssetExist`) and post-verify travel (G-3). **Defect P6-2** lives here: only mouse click resumes.

**Inventory (2951–3568):** Tab/I open via bridge; `DrawInventoryScreen` closes on I/Esc **locally** (this one works because the HUD reads input directly in `DrawHUD`). Six tabs; weapon carousel with localized names from `[Armory]`; **equip actually patches `WeaponComp` fields** (display name, clip, reserve, damage×40) or pack reflection (`ActiveWeapon`/`CurrentWeapon` properties) — `EquipSelectedWeapon` returns false rather than lying (F-G10 fixed). Notes/radio/Quran/wallet/supplies tabs are all data-driven from the inventory subsystem; dossier reads live profile (`BloodType`, `DogTagNumber` — B6-22 fixed).

**Direct data dependencies:** soldier registry for dots; quest chain for objective card; `USquadAITuning` for icons/font/minimap material; `FSquadAIAssetHelper` for textures; localization for ~26 keys; inventory/progression/save/radio/chatter/ping/command subsystems.

**Progress note:** health percent reads SquadAI `HealthComp` plus pack reflection (`currentHealth/CurrentHealth/Health/HP` variants), with per-component observed-max caching (G-4): correct in isolation, and it matches the blended native+pack health architecture that Passes 3–5 flagged as fragile.

### 2.2 `ASquadAIMainMenuHUD` — menu Canvas HUD (`SquadAIMainMenuHUD.h/.cpp`)

~4,700 lines, fully immediate-mode. Structure:

- `DrawHUD` (1685–1902): forces `bUseProceduralCanvasMenu = true`, removes `ActiveMenuWidget` per frame (AAA-MM-1), resets the per-frame Farsi shape cache, draws background (aspect-correct Ken-Burns or material or obsidian fallback — no aspect distortion, AAA-MW-24), particle layers (sand motes 135, ground dust 920, embers 118 — frozen under `bReducedMenuMotion`), scanlines, screen switch, hover sound, click processing.
- Screens: Main (reference palette + command-deck layout), MapSelect (recon board with list/detail, locked maps disable deploy), Armory, PlayerProgression (doctrine grid + inspector), PlayerProfile (slots, avatar, Farsi ISIRI-2901 virtual keyboard + physical keymap, preset chips), Achievements, Difficulty (4 cinematic columns, launch), LoadGame (4 slots), Settings, TacticalBriefing, RelicCollection.
- Rendering helpers: `DrawNineSliceFrame` (AAA-MM-4, 1204–1239 — correct corners/edges, center omitted), integrated as overlay inside `DrawChiseledTacticalPanel` (1269–1277) with procedural fallback. `AQuestNativeHUD::DrawChiseledTacticalBox` has **no 9-slice integration** — documented in `IMAGE_USE_MAP.md` as intentional (`UI_Frame_TacticalBorder_*` is menu-only so far).
- Settings screen is **real now** (B6-4 fixed): quality cycle (701), language toggle fa/en (702), SFX/Voice steppers (705–708), all persisting through `SaveSettings`→`ApplySettingsToEngine`.

**Input model:** mouse-rect `ClickableButtons` rebuilt every frame; button IDs are screen-scoped by convention — global uniqueness is enforced in current code (medals moved to 520+, difficulty 501–504 state-guarded, load slots 700–703).

**Language model:** `BeginPlay` reads saved `LanguageCode` and applies a preset; `OnLanguageChanged` subscription re-skins; screens select strings via `bMenuEnglish` ternaries (~235 sites) plus a 261-entry exact-match Persian→English map for dynamic strings, plus digit normalization (Persian/Arabic→ASCII for English mode). **Defect P6-1** is in this flow — see §4.

**External dependencies:** progression (maps/weapons/profiles/nodes/achievements), save subsystem, loading subsystem, difficulty, localization, ~60 texture slots auto-resolved via `LoadTextureSafe`.

### 2.3 Suppressed UMG widgets (compiled but hidden)

- `UQuestHUDWidget` + children (`MissionBriefingWidget`, `MissionMinimapWidget`, `CompassWidget`): snapshot-driven; minimap/compass wiring are explicit empty stubs ("Extension point"). Children implement a real `NativePaint` minimap, NineSlice briefing, compass strip.
- `UQuestMissionWidget`, `UQuestChainHUD`, `UQuestCompletionWidget`: direct `AQuestChain` pull/bind, correct Farsi shaping.
- `USquadAIMainMenuWidget`: thin shell whose actions duplicate the Canvas menu (New/Continue/Load/Delete/Settings/Quit). It duplicates stale behavior (e.g. `ContinueGame` ignores loading-screen transition availability; `DeleteSaveSlot` exists on the UMG path but not the Canvas path).

These are dead weight at runtime but compiled, and their class names seed the suppression list. Decision D2 from the archived register remains open: delete or retain as an opt-in UMG path.

### 2.4 Loading experience

`USquadAILoadingScreenSubsystem` (GameInstance): shows the loading widget pre-travel, correctly **drops its reference before `OpenLevel`** (P1-6), recreates the widget in the destination world via `OnPostWorldInitialization`, and completes via a 0.25 s handshake poll requiring `HasBegunPlay && PC != nullptr`, with a 30 s timeout failsafe. Tips/sector text are language-aware. Watch item: `SpawnLoadingWidget` silently no-ops if the destination PC does not yet exist at the post-world-init callback; the poll fallback will eventually auto-dismiss, so worst case is a transition with no visible loading screen on some platforms — note, not a confirmed defect.

Separately, the in-level **deployment veil** inside `AQuestNativeHUD` gates gameplay with its own ~2.4 s progress + Enter/Space prompt. Two loading UXs coexist by design (subsystem for travel, veil for in-level warmup); visual coherence is acceptable but the veil's texture auto-resolve does per-frame disk stats when assets are missing (P6-5).

---

## 3. Farsi/RTL rendering pipeline

`UFarsiTextHelper` (419 lines): 41-entry presentation-form glyph table (isolated/final/initial/medial + right-join-only flags + Persian Kaf/Ye/Pe/#:/Gaf/Che), Lam-Alef ligatures, tashkeel preserved, ZWNJ dropped, Persian digit conversion, token-based BiDi reordering with bracket mirroring and number-separator preservation. `ShapeAndOrder` = digits → shape → reorder.

Both Canvas HUDs shape at draw time with a **per-frame cache** (`ShapedTextFrameCache`, B6-15). Curve cost is O(41·N) shaping per unique string per frame; acceptable at current string counts. `SetJustification(Right)` used for UMG widgets; Canvas uses centered/bounded draws.

RTL correctness is good for its scope; limitations worth knowing before extending: the reorder reverses **whole RTL token runs**, keeps LTR runs forward, and is intentionally not a full Unicode BiDi implementation. Scripted behavior (numbers, [E]/[G] control hints in brackets, mixed FA/EN unit text) is handled correctly in the common HUD strings.

**Font contract:** Canvas path uses `GEngine->GetMediumFont()` unless `SquadAITuning.HUDFont/HUDFontPath` is set; menu HUD uses `TitleFont/MenuFont/BodyFont` from the setup actor, else engine default. Unreal's default engine fonts do not cover Persian/Arabic. The module provides no font asset (archive has none). **If the host project font pipeline is incomplete, all Persian text breaks.** This is the single most important asset presence to verify locally.

---

## 4. Localization subsystem deep-read

### 4.1 What it is

`USquadAILocalizationSubsystem` (GameInstance): parses a custom INI (`[Section]\nKey=Value`), default language `fa`, with:

- `[Section.en]` sections or `Key_en` suffixes for per-language overrides.
- A compiled-in **English fallback table** for 8 sections (MainMenu, MapSelection, Armory, Traits, Profile, Loading, HUD, PauseMenu, Inventory headers, FallenTroopNotes, RadioStations, QuranVerses).
- `SetCurrentLanguage` broadcasts `OnLanguageChanged`/`OnLanguageChangedNative` (native subscribers: menu HUD, menu setup actor). `ReloadFromDisk` also rebroadcasts so live holders re-skin.
- Template auto-generation at `ProjectDir()/SquadAILocalization.ini` if not found at any of 4 candidate paths.

### 4.2 Template ↔ consumer mismatch (machine-verified, P6-3)

Scripted comparison of all static `GetString`/`GetLocalizedText`/`SquadAIHUDLocal` call sites against the generated template:

| Section | Queried keys | In template | Missing (examples) |
|---|---|---|---|
| MainMenu | 20 | 1 (`GameTitle`) | All `Button*`, `Difficulty*`, `GameSubtitle` — note the template provides **different names** (`SubTitle`, `BtnStartGame`, `BtnMapSelect`, `BtnArmory`, `BtnProfile`, `BtnSettings`, `BtnSaveGame`, `BtnExit`, `Watermark`) that the code never queries |
| Loading | 4 | 3 | `DeploymentVeil` |
| PauseMenu | 9 | 9 | — |
| HUD | 15 | 0 | All helper keys (`AmmoCratePrompt`, `ReviveHoldPrompt`, `PickupFirstAid`, `MedicalStation*`, `MountedTurret*`, `ExplosionDanger`, `RadioHeader`, `ObjectiveGoalDefault`, ...) |
| Inventory | 11 | 0 | Section absent entirely |
| FallenTroopNotes | 1 | 0 | `NoteCount` (and whole section) |
| RadioStations | 1 | 0 | `StationCount` (and whole section) |
| QuranVerses | 1 | 0 | `VerseCount` (and whole section) |
| **Total** | **62** | **13** | **49 keys / 4 sections** |

Runtime behavior today is **correct by fallback**: `SquadAIHUDLocal` passes an English default when in English mode, so both languages display sensibly. What is broken is the promised contract "any string is editable in Notepad": 79% of subjects are invisible to the template, and the [MainMenu] alias names are authoritative-looking decoys whose edits are ignored. Also, the English fallback table covers `weapon6_*` (bayonet) but the generated `[Armory]` template stops at Weapon5 — overriding the knife via INI is likewise non-obvious.

**Recommended correction (no source contract break):** generate the template from the same key registry the code uses (centralize keys), or at minimum regenerate the template string with every queried key and drop the unused alias names. Add the four missing sections with their counts and numbered items.

### 4.3 Packaged-build path (P6-4)

Auto-creation target `FPaths::ProjectDir()/SquadAILocalization.ini` and the loose-file texture lookups (`ProjectDir()/Content/...`, `ProjectPluginsDir()...`) are editor-development patterns. For a shipped build: `ProjectDir` is the install root (read-only under Program Files / console); the INI cannot be created there, and `ProjectContentDir` loose `.png` files are not staged by default packaging (only `.uasset` and explicitly staged non-asset files). Options: move runtime INI to `FPaths::ProjectSavedDir()` (writable; intended for exactly this), and stage the reference INI/loose textures via packaging settings, or import UI textures as real `.uasset`s for shipping (the `LoadObject` leg of `LoadTextureSafe` already supports that).

### 4.4 Runtime value flows

- Settings language persists in the settings save slot (`FSquadGameSettingsSaveData.LanguageCode`, default `fa`), applied at `USquadAISaveLoadSubsystem::Initialize`→`ApplySettingsToEngine`, and toggled live from menu Settings (702).
- `SquadAIInventorySubsystem` re-reads localized data on every inventory open (weapon names/descs, notes, stations, Qur'an), preserving selection indices — good live-language behavior.
- Radio chatter reads live language per message.
- `ApplyPersianFarsiPreset`/`ApplyEnglishPreset` force `LocSys->SetCurrentLanguage` — subscription order makes this safe against re-entry.

---

## 5. Asset contract review

### 5.1 `FSquadAIAssetHelper::LoadTextureSafe(path, looserel)`

Order: `LoadObject` at `/Game/...` → loose `.png` candidates (`ProjectContentDir`, project root, `SquadAI/Content`, `Content`, plugin content) → `FImageUtils::ImportFileAsTexture2D` from disk. No texture pool — each successful loose import creates a fresh `UTexture2D` (caller holds it via UPROPERTY). Guarded call sites (`if (!X) X = LoadTextureSafe(...)`) in `BeginPlay` are fine. **Unguarded call sites inside `DrawPauseMenu`/`DrawDeploymentVeil` perform per-frame stat/import attempts while assets are missing (P6-5).** Cheap fix: resolve once at BeginPlay with a "missing means stop trying" bool.

Other auto-resolve facts: `Config/DefaultEditorPerProjectUserSettings.ini` auto-reimports `SquadAI/Content/Textures`→`/Game/Textures` and project `Content/Textures`→`/Game/Textures` in the **editor** — development ergonomics, not a shipping path. `Menu/loading` backgrounds intentionally prefer the loose clean PNG over a possibly-polluted `.uasset` (AAA-MW-27), an unusual precedence worth documenting.

### 5.2 `USquadAIAssetCacheSubsystem` (World)

Caches basic-shape meshes/materials and arbitrary path caches; `GetSharedDynamicMaterial` pools MIDs by (material, parameter, color). `FlushDynamicCache` calls `PrewarmCanonicalAssets()` — prewarm of engine basic shapes during a flush is benign. Correctly null-tolerant on `/Engine` assets.

### 5.3 Editor-only asset factory/resolver

`USquadAIBlueprintAssetFactoryLibrary` — `CallInEditor` blueprint/preset builders, all paths `WITH_EDITOR`-gated with null returns at runtime; `SquadAI.Build.cs` gates `UnrealEd/AssetTools` behind `bBuildEditor` but **also lists `AssetRegistry` as a hard runtime dependency** "for the weapon-preset factory outside WITH_EDITOR" (Build.cs comment). Build correctness is fine (AssetRegistry loads at runtime); note the factory's runtime behavior is null by design. `USquadAIPackAssetResolverLibrary` is entirely editor-gated; packaged behavior is empty returns.

### 5.4 Texture registry

`IMAGE_USE_MAP.md` enumerates ~60 PNGs (frames, buttons, bar, backgrounds, difficulty, map/weapon previews, avatars, traits, HUD icons, inventory items). The code references essentially all of them with procedural fallbacks — missing art must never hard-break UI. Off-file asset presence cannot be verified here; `SquadAI.CheckAssets` console audit exists (`[SQUADAI_ASSET_AUDIT]` log) for local verification.

**Font is the one un-fallbackable asset** (§3): no procedural fallback for missing glyph coverage.

---

## 6. Settings and save integration (UI-visible)

`FSquadGameSettingsSaveData` (audio×4, sensitivity, invert Y, subtitles, quality, FOV, motion blur, vsync, language). `ApplySettingsToEngine` covers quality + vsync via `UGameUserSettings`, volumes via `USquadAIAudioSubsystem::ApplyVolumeSettings` (clamped, applied to music/ambience/AI mixes), language via localization, FOV via camera manager, motion blur via `r.MotionBlurQuality`, subtitles read by the radio-subtitle draw. Residual: menu-theme music on the menu setup actor plays unscaled (PlaySound2D default volume), and `MouseSensitivity`/`bInvertYAxis` are exposed in `GetCachedSettings()` for the host's look-input owner (module has no SetupPlayerInputComponent — host boundary, correctly documented).

Save/load UI path: Canvas pause "Save" writes to the subsystem autosave slot with toast (works); main-menu Load lists 4 slots (`SquadAISave_Slot0..3`). See Pass 5 for the mission-state caveats. `USquadAIMainMenuWidget` UMG duplicate offers Delete, Canvas does not — divergence but Canvas is authoritative.

---

## 7. Defect list

| # | Severity | File:Line | What |
|---|---|---|---|
| P6-1 | **Medium — mixed-language menu + wrong settings display until Settings is opened** | `Private/HUD/SquadAIMainMenuHUD.cpp:578–596` (assignments only at 806, 4379, 4390, 4403) | `CachedMenuSettings` default-constructs to `LanguageCode="fa"` and preset 3; `BeginPlay` applies the saved language's preset but never loads the working copy. All `bMenuEnglish` gates (~235 sites) then disagree with the preset text; quality row shows default. Fix: initialize `CachedMenuSettings = SaveSys->LoadSettings()` in `BeginPlay` before applying the preset (or read `Loc->GetCurrentLanguage()` directly at the top of `DrawHUD`). |
| P6-2 | **Medium — pause menu Esc/[P] promise unreachable** | bridge `Private/Performance/SquadAIPlayerCombatBridge.cpp:27–31, 257–266` + `Private/HUD/QuestNativeHUD.cpp:2817–2949` | `USquadAIAudioSubsystem`-independent: `SetGamePaused(true)` stops the pawn component's ticks, so the Esc poll dies exactly when the menu opens; `DrawPauseMenu` reads mouse only. Label text `[Esc]` lies. Fix: handle `EKeys::Escape`/`EKeys::P` inside `DrawPauseMenu` (same pattern as inventory's I/Esc handler at 2999). |
| P6-3 | **Medium — Notepad-editable localization contract broken ~79%** | `Private/Localization/SquadAILocalizationSubsystem.cpp:355–449` (template) vs usage table in §4.2 | Generate template to cover every queried key/section, remove unused alias keys, add missing sections/items. |
| P6-4 | **High for shipping — localization file and loose textures use non-staged paths** | `...Localization...cpp:201–238`, `Public/Utilities/SquadAIAssetHelper.h:48–83` | Move runtime INI to `ProjectSavedDir()`; stage/convert loose textures for packaged builds. |
| P6-5 | **Low–Medium — per-frame disk stats while textures missing** | `Private/HUD/QuestNativeHUD.cpp:2833–2835, 1476–1479` | Resolve once at BeginPlay and remember failure instead of retrying each frame. |
| P6-6 | **Low — class-name substring widget suppression** | `Private/HUD/QuestNativeHUD.cpp:115–146, 2308–2331` | Replace with an explicit interface/tag (`SquadAI.SuppressHUD`) or opt-out list; document the suppression contract on the compiled-but-dead UMG classes. |
| P6-7 | **Watch — loading widget silently absent if no PC at post-world-init** | `Private/Performance/SquadAILoadingScreenSubsystem.cpp:137–156` | Spawn retry inside `PollDestinationReady` until ready. |
| P6-8 | **Note — settings volumes Master/Music not shown in UI; menu theme music ignores settings** | settings row set at `SquadAIMainMenuHUD.cpp:4174–4179`, menu theme play at `SquadAIMainMenuSetupActor.cpp:71–78` | Design gap, minor. |

Out of scope but confirmed: Pass 5's mission-authority mismatch remains — the objective card is `QuestChain`-only and suppressed UMG starts would not fix that.

---

## 8. Archived Step 6 comparison

All 22 archived B6 items re-checked against current source:

- **Fixed:** B6-1 (autosave slot via getter), B6-3 (scanline-filled circles, `DrawFilledCircleArea`), B6-4 (settings functional with 701–708 handlers), B6-5 (n/a — cleared), B6-6 (`CurrentClipAmmo`), B6-7 (separate `CompletedMissionCount` field + surgical restore in `QuestChain::RestoreMissionState`), B6-8 (mission restore no longer clobbered by `StartChain`), B6-9 (volumes/language/FOV/motion blur/subtitles applied), B6-13 (n/a — cleared), B6-14 (`GameUIScale`), B6-15 (per-frame shape cache + sweep backoff), B6-17 (medical station/turret prompts exist at 1264–1365), B6-18 (leader pip unconditional), B6-20 (minimap re-init), B6-21 (language applied in BeginPlay — but see P6-1 cache leak), B6-22 (dossier reads profile).
- **Re-scoped/unchanged-by-design:** B6-2 (UMG suppression still architectural — now P6-6), B6-10–12 (progression persistence and post-travel restore — covered by Pass 5 mission/save analysis), B6-16 (mortar firing moved to bridge — comment at 2408–2411), B6-19 (menu ID namespaces now globally de-conflicted by convention — enforced only by discipline).
- **New in Pass 6:** P6-1 … P6-5.

The archived doc's biggest claim — Canvas is the only live HUD — remains true and is now stronger (UMG classes still compiled, still suppressed).

---

## 9. Product/architecture questions to resolve before code edits

1. **Localization model:** keep the custom INI subsystem (fix template + move to `Saved/`), migrate to UE native localization (LOCTEXT + `.locres`, no runtime Notepad editing), or dual-path? This decision affects every string in both HUDs.
2. **UMG policy:** delete the five suppressed widget classes (dead code) or formally keep them behind a config flag with a documented contract (and stop the name sweep for owned classes)?
3. **Asset shipping model:** import UI textures as `.uasset` for shipping (current `LoadObject` path already supports it) vs stage loose PNGs (keeps hot-drop workflow); decide per-art category.
4. **Font guarantee:** which font asset is the single Persian fallback, and where does the host wire it (`SquadAITuning` vs menu setup actor)? No fallback exists if both are unset.
5. **Settings surface:** expose Master/Music sliders or keep SFX/Voice only; scale menu music by settings?
6. **Deployment UX:** keep the two-layer loading (travel widget + in-level veil) or merge into one flow?

---

## 10. Recommended correction order (UI slice, no cross-pass work)

1. **P6-1 + P6-2** — two localized edits, both self-contained in the two Canvas HUDs (initialize settings copy at BeginPlay; handle Esc/P inside `DrawPauseMenu`). No API change.
2. **P6-3** — regenerate INI template content from a single source of keys; keep the section/key scheme and fallback table intact.
3. **P6-5** — one-time resolve with a failure latch in both HUD draw sites.
4. **P6-4** — relocate INI creation/read to `ProjectSavedDir()` with migration from existing legacy paths; document packaging story for loose textures.
5. **P6-6** — replace substring suppression with an opt-out/interface contract; keep the classes while the decision is pending.
6. Deferred: loading-spawn retry (P6-7), settings-surface expansion (P6-8), and the five §9 product decisions.

No `Source/SquadAI` code has been modified.
