# S18b — fixes from your screenshots + log

## Log verdict: the import itself was clean
- `auto-filled 10 material slot(s) ... (0 not found)`
- all 9 meshes `mesh ready`, `M_TrenchDrum / M_TrenchAmmoCan / M_TrenchCanvas` built and saved
- `enabled 'Used with Instanced Static Meshes' on M_MS_Srf_VT`
- `built 712 instances in 17/21 categories along 48 m` — the new code **did** compile

**One real bug, and it was mine:** UE's Python API strips the leading `b` from bool
properties, so `bSandbags` is `sandbags`, not `b_sandbags`. Three toggles silently failed:

```
Failed to find property 'b_use_custom_mesh_materials' ...
Failed to find property 'b_sandbags' ...
Failed to find property 'b_wire_sets' ...
```

That also means **`bUseCustomMeshMaterials` never got set** — the props were still being
painted with your family materials on that run. Fixed in the script.

Two harmless engine notes you can ignore (they self-heal): `M_TrenchScorch` / `M_TrenchRug`
`needed to have new flag set bUsedWithInstancedStaticMeshes`.

## What changed

| Your note | Fix |
|---|---|
| sandbags too tall, you'll do your own | `bSandbags` default **false**, both sandbag meshes **cleared** on the actor and no longer migrated |
| two wire lines, old one ugly | prop belts now suppress **all** cylinder wire — coils *and* the stake-to-stake strands (only the coils were suppressed before). `bKeepProceduralCoils` brings them back |
| want the nicer wire variety / cross-wood ones | **4 wire-set slots** (`CustomWireSetMesh`..`4` + per-mesh lengths, 4 new HISMs). Script assigns `Set_B` 210, `Set_C` 510, `Set_F` 325, `Set_E` 264 — the builder picks per segment, random flip, 16 % blown gaps. `Set_A`, `Set_D`, `Set_G` and `Wire_Iron_Pigtail` are migrated too as spares |
| Persian carpets | `bPrayerRugs` default **false** + set false by the script |
| random dark cloth | that was `SM_Cloth_01` with no material resolved. Mesh **removed** from the migration and the slot cleared; `tarps` also set false. Flip `tarps` back on for the procedural ridge awning |
| random ladders on the ground | new `LadderChance`, default **0.16** (was a hard-coded 0.64 — 4× too many) |
| plank edges too straight, "this is not a cabinet" | new `RagPlankEnds()` + `bRaggedPlankEnds`: every plank gets 1-2 corner bites and a 50 % splinter spiking past each end, at random yaw/roll. Applied to dugout roof planks, duckboard fallback planks, firing-step treads, fallen debris, and revetment boards (top/bottom ends) |
| electricity/comm poles | kept — `comm_wire` explicitly set true. Only the *barbed* wire got replaced |

Build-stats line now `/24 categories`. All new markers: `grep -rn "S18-FIX" source`.

## Run order (same as before)
1. compile `source/SquadAI/.../TrenchDetailSplineActor.{h,cpp}`
2. `scripts/RUN_IN_TRENCH_PROJECT.py` in the Megascans project (brings the extra wire meshes)
3. open the trench map in the game project → `scripts/RUN_IN_SQUADAI_PROJECT.py` → **Ctrl+S**

## Knobs you'll probably want to tune in the Details panel
- `LadderChance` — 0.16 now; 0 kills ladders entirely
- `WireSetLengthCm..4` — if a belt overlaps or gaps, the length value is off for that mesh
- `bRaggedPlankEnds` — off = the old clean cube planks
- `bKeepProceduralCoils` — on = old cylinder wire *and* the props
