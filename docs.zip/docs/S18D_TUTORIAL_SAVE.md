# S18d — batch 1 of 4: explosions can finally hurt the player (`S18-BOOM`)

## The bug
`TacticalMortarBarrageActor`, `TacticalGrenadeActor` and `ExplosiveBarrelActor`
all damaged the world with `UGameplayStatics::ApplyRadialDamageWithFalloff`,
which routes through `AActor::TakeDamage`. Your player pawn is a **pack
Blueprint** whose health lives on a Blueprint health component — it never
implements that path, so your own artillery (توپخانه), enemy barrages, grenades
and exploding barrels were all completely harmless to you.

## The fix
New `USquadAIExplosiveDamageLibrary` (`Public/Tactical/SquadAIExplosiveDamage.h`):

- `ApplyExplosiveDamageToPlayer(...)` — same linear falloff as the engine call
  (full damage inside the inner radius, down to the min fraction at the outer
  radius), then multiplied by a friendly-fire scale.
- Damage is delivered by: native `HealthComponent` → **reflection** onto the
  pack health component (`currentHealth` / `CurrentHealth` / `Health` / `HP`,
  float or double) → `TakeDamage` as a last resort.
- Line-of-sight check: a solid blocker between the blast and your chest cuts the
  damage to 25 % instead of nullifying it.
- Triggers the same screen suppression AI soldiers get from a near miss.

All three explosive actors now add the player to the engine call's ignore list
(so he can never be damaged twice) and call the library afterwards.

### Tuning
Each actor gained `PlayerDamageMultiplier` (Explosion category, default **0.5**
as you chose — hurts badly, survivable). `0` = immune, `1` = full lethality.
Defaults: mortar shell 250 dmg / 750 radius, grenade 165 / 600, barrel 180 / 650.

Log line to confirm it works: `[S18-BOOM] Mortar shell hit the player for …`.

---

## Still to come (agreed plan)
2. Pause-menu **save-slot picker** (the main menu already lists slots; the pause
   menu was hardcoded to the autosave slot — that is why no slot list opened).
3. Tutorial core: director, first-run skip prompt, step machine, movement lock,
   grey-out + highlight overlay, completed-step marker on the quest bar.
4. Tutorial content: auto-spawned barrels and cans, the guide's grenade demo,
   steps = move → UI walkthrough (full pause) → shoot cans → grenade in barrel →
   درخواست آتیش توپخانه.

---

# Batch 2 of 4 — in-game save slot picker (`S18-SAVE`)

## The bug
`AQuestNativeHUD::SaveGameFromPauseMenu()` called
`SaveSys->SaveGame(SaveSys->GetAutoSaveSlotName())` — a silent write to the
**autosave** slot. There was no slot UI in game at all, which is exactly what
you saw: slots visible in the main menu, nothing when saving.

## What you get now
Pressing **ذخیره وضعیت عملیات** in the pause menu opens a slot picker drawn
inside the same tactical card (same chiselled boxes / Farsi text helpers — no UI
rebuilt from scratch):

- One row per save slot (the save system defines 4: `SquadAISave_Slot0..3`),
  each showing the sector display name and the save timestamp, or `[ خالی ]`
  when empty, plus a "بازنویسی / overwrite" marker on used slots.
- An **autosave** row at the bottom for a quick autosave-slot write.
- **بازگشت / Back** returns to the pause menu; closing the pause menu closes the
  picker automatically.
- Click a row → saves there, toast confirms (`وضعیت عملیات در موقعیت N ذخیره شد.`),
  log line `[S18-SAVE] Pause-menu save to 'SquadAISave_SlotN' -> OK`.

The main menu already lists and loads these same slots, so a game saved to
slot 2 in the field appears as slot 2 in the main menu.

New API: `AQuestNativeHUD::SaveGameToSlotFromPauseMenu(int32 SlotIndex)`
(-1 = autosave) and `TogglePauseSaveSlotPanel(bool)` — both BlueprintCallable.

**Want more than 4 slots?** Say so and I'll raise the loop in
`USquadAISaveLoadSubsystem::GetAllSaveSlots()` (and the main menu reads the same
list, so both grow together).

---

# Batch 3 of 4 — tutorial core (`S18-TUT`)

New files
- `Public/Tutorial/SquadAITutorialSubsystem.h` / `Private/Tutorial/SquadAITutorialSubsystem.cpp`
- HUD layer added to `AQuestNativeHUD` (`DrawTutorialOverlay`, `RegisterTutorialUIRect`).

## Flow
1. **1.5 s after level start** (`StartDelaySeconds`, lets the deployment veil
   finish) the director runs. If the settings profile says the tutorial was
   already completed or skipped, it does nothing.
2. **First play only:** the game **fully pauses** and asks
   «می‌خواهی ابتدا آموزش را ببینی؟» with *شروع آموزش* / *رد کردن آموزش*. The
   answer is written to the settings profile (`bTutorialPromptAnswered`), so the
   question never appears again — it lives in the settings save, not a game
   slot, so new games and slot deletion do not bring it back.
3. **UI walkthrough** (5 beats, game **fully paused**, exactly the hold-V look):
   the screen greys out except the element being taught, which keeps its normal
   colours and gets a gold frame, plus a small explanation box at the bottom.
   Order: نوار مأموریت → وضعیت جوخه → قطب‌نما → سلاح و مهمات → درخواست آتش توپخانه
   (that last card also warns that friendly shells now hurt you).
4. **Hands-on tasks** (full pause + prompt, then **movement locked**):
   حرکت → تیراندازی به قوطی‌ها → نارنجک داخل بشکه → درخواست آتیش توپخانه.
   Look, aim and fire stay available — only the legs are frozen
   (`SetIgnoreMoveInput`), exactly as you asked.
5. **Checklist panel** on the right: each finished beat gets the **grey plate**
   hovering over its row with an `[x]`; the active one is gold.

## Wiring points for batch 4 (the props)
`NotifyCanDestroyed()`, `NotifyBarrelGrenaded()`, `NotifyArtilleryCalled()` —
all BlueprintCallable, so your own actors can call them too. The move task
completes automatically after `MoveTaskDistanceCm` (default 500 cm).

## HUD element ids registered so far
`Objective`, `Squad`, `Compass`, `Weapon` — each panel registers its own rect as
it draws, so the highlight always lands on the real on-screen position at any
resolution. `Artillery` still needs a rect; it is added in batch 4 together with
the fire-support indicator.

## Debug
`[S18-TUT] Step -> …`, `[S18-TUT] Progress …`, `[S18-TUT] Movement LOCKED`.
To replay the tutorial, clear `bTutorialCompleted` / `bTutorialSkipped` in the
settings profile (a console/menu toggle can be added on request).

---

## Batch 4 of 4 — tutorial props + wiring (`S18-TUT`) and the menu video fix (`S18-VIDFIX`)

### New files
- `Public/Tutorial/TutorialRangeActor.h` / `Private/Tutorial/TutorialRangeActor.cpp`

Three actors:

| Actor | Role |
|---|---|
| `ATutorialRangeActor` | Place **one** in the map near the player start. At BeginPlay it spawns the whole practice range and pushes `CanCount` into the subsystem's `CansToShoot` so the two can never disagree. |
| `ATutorialTargetCan` | A small can. Any damage (point or radial) knocks it down with physics and calls `NotifyCanDestroyed()`. Self-destructs 12 s later. |
| `ATutorialGrenadeBarrel` | Polls 5×/s for a live grenade actor inside a 140 cm sphere at its mouth; the first one calls `NotifyBarrelGrenaded()`. Also publishes its location to `CurrentTaskWorldFocus`. |

Range tunables (all on the range actor): `CanCount` (3), `CanSpacingCm` (90), `CanRowOffset` (900, −250, 0), `BarrelOffset` (1400, 450, 0), `CanMeshOverride`, `BarrelMeshOverride`, `bSnapToGround`, `bClearWhenTutorialEnds`.
Defaults use engine shapes so it works with zero setup; drop your Megascans can / `SM_Ind_Storage_Barrel_Metal_Rust_01` into the override slots for the final look. With `bClearWhenTutorialEnds` the range despawns on `OnTutorialFinished`.

### Wiring
1. **Cans** — `Private/Performance/SquadAIPlayerCombatBridge.cpp`: before the pack-enemy path, a hit actor that casts to `ATutorialTargetCan` gets `RegisterHit(TraceDir)` plus a HUD hitmarker, then returns. Cans have no health component, so without this they'd absorb traces silently.
2. **Artillery** — `Private/Tactical/SquadAIFireSupportSubsystem.cpp`: `CallMortarStrike()` calls `NotifyArtilleryCalled()` right before its successful `return true`. Cooldown-rejected calls do not count.
3. **Artillery HUD rect** — `QuestNativeHUD.cpp` now registers `"Artillery"` as the bottom 34 px strip of the weapon status plate, so the `UI_Artillery` beat has something to highlight. All five rects are registered now.

### `S18-VIDFIX` — main-menu background video
The S17 A/B handoff started the standby player up to 0.35 s early and swapped as soon as it had ~2 decoded frames, so the picture cut backwards to the clip start mid-shot — that is the "weird movement" you saw. Fix in `Private/HUD/SquadAIMainMenuHUD.cpp`:
- A/B handoff deleted (`BackgroundVideoPlayerB` / `TextureB` forced null).
- Single player keeps `SetLooping(true)`; the engine wrap is frame-accurate.
- `BackgroundVideoTexture->AutoClear = false` — the last frame holds across the wrap instead of flashing black (the original one-frame stutter).
- `UpdateBackgroundVideoLoop()` is now only a watchdog: if the player is neither playing, preparing, paused nor closed it does a one-shot `SetLooping(true)` + `Seek(0)` + `Play()` and logs `[SquadAIMenu] S18-VIDFIX: background video stalled at the wrap — resumed.`

### Test
1. Place one `ATutorialRangeActor` near the player start, play from the main menu (not PIE-drop-in if you want the skip prompt).
2. Skip prompt → No → four UI beats → artillery beat → walk → shoot 3 cans → grenade in the barrel → call artillery (middle mouse laze + fire). Watch `[S18-TUT]`.
3. Finish once, restart: the tutorial must not reappear (persisted in `FSquadGameSettingsSaveData`). Reset it by deleting `SquadAISettings_Profile`.

---

## Batch 4b — tutorial illustrations + the real video fix

### Illustrations
`assets/TutorialImages/` (ships as its own folder: 6 PNGs + importer only):

| Asset | Used by beat |
|---|---|
| `T_Tut_Welcome` | `UI_Objective` (first card) |
| `T_Tut_Squad` | `UI_Squad` |
| `T_Tut_Move` | `Task_Move` |
| `T_Tut_Shoot` | `Task_ShootCans` |
| `T_Tut_Grenade` | `Task_Grenade` |
| `T_Tut_Artillery` | `UI_Artillery` + `Task_Artillery` |

Style: hand-drawn ink-and-wash field-manual plates on aged ochre paper, Khuzestan 1980s — kahgel walls, olive fatigues, palm silhouettes. No text baked in, so they never need localising.

Wiring:
- `FSquadAITutorialBeat::IllustrationKey` (new `FName`), assigned at the end of `BuildBeats()`.
- `AQuestNativeHUD::GetTutorialIllustration(FName)` lazily `LoadObject`s `/Game/SquadAI/UI/Tutorial/T_Tut_<Key>` and caches it — **a missing asset caches null and the card simply draws text only**, so the build is never broken by an un-imported texture. Log line: `[S18-TUT] Illustration '<path>' -> loaded / MISSING`.
- `DrawTutorialOverlay` draws the plate directly above the instruction card at 16:9, `CardW` wide, with a dark backing and a gold underline, clamped to stay on screen.

Import: run `assets/TutorialImages/SquadAI_ImportTutorialImages.py` from the editor's Python console after setting `SOURCE_DIR`. It sets UI LOD group, sRGB and never-stream. **Do not rename the assets** — the HUD resolves them by name.

### Video — second (and actual) cause
The A/B-handoff removal was necessary but not sufficient. The menu background also ran a **Ken-Burns pan + breathing zoom on top of the video**: a slow sine pan that drifts and then *reverses direction* every few seconds, over footage that already has its own camera move. That is the "weird movement".
Fix in `DrawMenuBackground`: `if (!bUseVideo && !bReducedMenuMotion && MenuState == EMainMenuState::Main)` — stills keep the breathing motion, video is now drawn with a plain aspect-correct centre crop and nothing else.

So the video path is now: single looping player, no handoff, no AutoClear flash, no Ken-Burns, plus a stall watchdog. If you still see movement after this, it is in the MP4 itself.

---

## Batch 4c — photoreal tutorial art, loop-stutter mask, fog hitch

### Tutorial art replaced
The ink-and-wash plates were too stylised next to your renders; they are deleted. `assets/TutorialImages/` now holds six **photoreal in-engine-looking stills** generated against your own screenshot (same cracked ochre Khuzestan ground, sandbag parapets, palm grove, hazy ridge line): `T_Tut_Welcome`, `T_Tut_Squad`, `T_Tut_Move`, `T_Tut_Shoot`, `T_Tut_Grenade`, `T_Tut_Artillery`, 1280×720. Same names, same importer, so no code changed. Long term these should be replaced by real screenshots taken in your level — the HUD path does not care.

### `S18-VIDFIX2` — stutter on repeat
Remaining cause: UE's media player loops by **seeking to zero, which flushes the decoder**, so several frames arrive late at every wrap. No amount of player juggling removes that; it has to be hidden. `DrawMenuBackground` now:
- tracks `BackgroundVideoPlayer->GetTime()` and detects the wrap (time went backwards),
- fades the picture to black over the **last 0.28 s** of the clip and back in over **0.22 s** after the wrap, with an opaque black plate under it,
- so the wrap reads as a deliberate cut instead of a judder.
Combined with the earlier fixes (single player, no A/B handoff, `AutoClear = false`, **no Ken-Burns over video**) the loop should now be clean. If you want it perfectly seamless with no dip, the clip itself must start and end on the same frame — then set `FadeOutLead`/`FadeInTime` to 0.

### `S18-FOGFIX` — fog brings audio + frame stutter
Three real causes in `ASandstormWeatherDirector`:
1. **Audio was spawned when the storm started.** `SpawnSound2D` at that moment forces a synchronous decode — that is the audio hiccup. The howl is now created **once at BeginPlay at volume 0** and never stopped; only its volume multiplier is animated (`bPersistentStormAudio`, default on; the old path is kept behind the flag).
2. **It leaked an audio component per storm cycle** — spawned with `bAutoDestroy = false`, then the pointer was dropped on fade-out. Over a long session that is a growing pile of live components. Now there is exactly one, destroyed in `EndPlay`.
3. **The first storm paid for creating every dust/fog system, material and PSO.** New `bPrewarmStormFX` fires one silent `ApproachingDust` broadcast at level start (intensity pinned at 0) for `PrewarmSeconds` = 1.25 s, so your Blueprint fog/Niagara spawns behind the loading veil, then a `Clear` broadcast. The cost moves to load time.
4. The ramp is now constant-rate over `IntensityRampSeconds` (9 s) instead of `FInterpTo(0.25)`, which front-loaded most of the volumetric-fog cost into the first second.

Watch for: `[WeatherDirector] S18-FOGFIX: storm howl pre-rolled silently…`, `… prewarming storm FX …`, `… prewarm done`.
If a hitch still remains exactly when the dust appears, it is PSO compilation in your fog material — bundle a PSO cache, or set `r.Shaders.Optimize`/precache settings; tell me and I'll add a dedicated prewarm actor that renders the fog material off-screen for one frame.

---

## Batch 5 — `S18-TRWIRE2`: the rest of the pack's wire family

You were right: only 4 of the pack's wire assets were hooked up. The pack ships **7 barbed runs + a wooden X-frame obstacle + iron pigtails + 3 custom coils**; the X-frame — the "cross wooden foundation" the wire actually stands on — was never used at all.

### Now wired in

| Pack asset | Size (cm) | Dresser slot |
|---|---|---|
| `SM_Mil_Trench_Wire_Barbed_Set_B` | 210 | `CustomWireSetMesh` (was) |
| `..._C` | 510 | `CustomWireSetMesh2` (was) |
| `..._F` | 325 | `CustomWireSetMesh3` (was) |
| `..._E` | 264 | `CustomWireSetMesh4` (was) |
| **`..._A`** | 110 | **`CustomWireSetMesh5`** (new) |
| **`..._G`** | 470 | **`CustomWireSetMesh6`** (new) |
| **`SM_Mil_Trench_Equipment_Obstacle_Wood_01`** | 243×137×120 | **`CustomWireObstacleMesh`** (new — the wooden X-frame / knife rest) |
| **`SM_Mil_Trench_Wire_Iron_Pigtail`** | 73 | **`CustomPigtailMesh`** (new) |
| **`SM_Wire_01_B` / `SM_Wire_01_C`** | ~81 / ~77 | **`CustomWireCoilMesh` / `…Mesh2`** (new coils) |

`_D` (100 cm low coil strip) is deliberately left out — it overlaps `_A` and only adds another stamp.

### New behaviour
- **Wire stands on frames.** In `ScatterWireSets`, `WireObstacleFraction` (0.55) of each run now gets 1–6 X-frames placed evenly underneath, inheriting the run's yaw and bedded into the ground — the wire no longer floats. Pickets are skipped on those runs (a frame-carried run doesn't need them).
- **Pigtails replace cube stakes** as wire pickets whenever `CustomPigtailMesh` is set.
- **Loose coils** slump against the belt at ~22 % of runs, random yaw, two mesh variants.
- **New pass `ScatterWireObstacles`** — standalone knife-rest blocks away from the belt: `StandaloneObstacles` (6) groups of 1–3 frames, angled 50–130° *across* the approach (not parallel to the trench) at 260–520 cm beyond the parapet, ~12 % toppled on their side, half of them with a short `_A` run laid over the row. This is the road/communication-trench blocking you see in reference photos.
- The X-frame HISM **collides** (`bSolidProps`) — it is a real obstacle, not decoration. The runs and coils stay non-colliding.
- New toggle `bWireObstacles` (default on). Everything is still mesh-gated: no mesh assigned ⇒ pass does nothing ⇒ old maps unchanged.

### Apply
`2_EditorScripts/RUN_IN_SQUADAI_PROJECT.py` now assigns all ten slots and pushes `wire_set_length_cm5/6`, `wire_obstacles`, `wire_obstacle_length_cm`, `wire_obstacle_fraction`, `standalone_obstacles`. Re-run it, then `Build Details` on the dresser.

---

## Batch 5b — importer paths, poles removed, loop dip removed

### 1. Importers find their own folder
`SOURCE_DIR` is gone from the tutorial importer: all three scripts now resolve **their own directory** (`_this_dir()`), which also works when you paste them with `exec(open(...).read())` — `__file__` is undefined in that case, so it walks the call stack and falls back to the CWD. Nothing to edit: drop the folder anywhere, run the script inside it.

### 2. تیرهای چراغ برق removed
`bCommWire` now defaults to **false** and `RUN_IN_SQUADAI_PROJECT.py` pushes `("comm_wire", False)`. The pole line and its sagging wire no longer build. (Earlier you asked to keep them, hence the default; it is reversed now. Set `bCommWire = true` on the dresser to bring them back — nothing else depends on it.) Poles placed by hand in the level are not touched by this; delete those in the editor.

### 3. `S18-VIDFIX3` — the black screen was mine, it is gone
The fade-to-black I added to hide the wrap was worse than the hitch. Removed completely. What happens now at the loop point:
- `AutoClear = false` keeps the **last decoded frame** on the surface,
- the draw is always fully opaque, no alpha, no black plate, no Ken-Burns,
- so while the decoder refills after the loop seek the picture simply **holds on the same frame for ~0.1 s** and then continues. A brief hold reads as nothing; a dip to black reads as a bug.

That is as far as engine-side code can take it — the remaining pause is the decoder being flushed by the loop seek. To actually remove it, re-encode the clip:
```
ffmpeg -i MenuBackground.mp4 -c:v libx264 -preset slow -crf 20 \
       -g 30 -keyint_min 30 -sc_threshold 0 -bf 0 -pix_fmt yuv420p \
       -movflags +faststart -an MenuBackground_loop.mp4
```
Short GOP (`-g 30`), **no B-frames** (`-bf 0`) and no audio track make the seek-to-zero almost free, and the first frame decodes immediately. Also make the last frame visually match the first.

### 4. `S18-FOGFIX2` — why the prewarm did nothing
The prewarm pulse pinned `StormIntensity` at exactly **0**, so any Blueprint that gates its dust/fog on `Intensity > 0` spawned nothing and nothing got warmed. It now warms at **0.02** (visually nothing, ~2 % density) while the audio stays forced to silence, so the fog systems, materials and PSOs really are created at level start.

If a hitch survives this, it is shader/PSO compilation inside your fog material and it must be fixed with a PSO cache (`r.ShaderPipelineCache.Enabled 1` + a recorded cache) — tell me and I'll add a dedicated off-screen prewarm actor that renders the fog material for one frame.

---

## Batch 6 — `S18-TUT2`: teach it in the game, not on a blue screen

Everything you flagged on the two screenshots:

### 1. No more blue screen — the tutorial never hard-pauses
`UGameplayStatics::SetGamePaused()` was the cause: a paused world stops ticking the HUD panels and most of the scene, so the card floated over an empty background and **the UI element being explained wasn't even drawn**. Replaced with a slow-motion freeze: `SetGlobalTimeDilation(CardTimeDilation)` (default **0.18**) plus `SetIgnoreMoveInput`. The level, your squad, the objective bar, the compass and the weapon plate all keep rendering — the lesson now happens inside the game. Set `CardTimeDilation = 1.0` for no slowdown at all.

### 2. The veil no longer blacks out the level
Highlight veil alpha dropped from **0.82 → 0.45**. The surroundings dim slightly, the highlighted panel stays bright with its gold frame, and the battlefield remains readable behind it.

### 3. Card and picture moved out of the firing line
Card is now **bottom-left** (430×150 at 28 px margin) with the illustration above it at 78 % width, instead of a big plate in the middle of the screen.

### 4. Nothing shoots you while you are locked
New `USquadAITutorialSubsystem::IsTutorialProtectingPlayer()` (toggle `bCombatSafeDuringTutorial`, default on):
- `ASoldierAIController::GetTeamAttitudeTowards` returns **Neutral** for the player while the tutorial runs — enemies don't target, chase or fire at you.
- `USquadAIExplosiveDamageLibrary::ApplyDamageToPlayerPawn` returns early — your own practice grenade and the artillery you are told to call cannot kill you.
Protection lifts automatically at `Finished` / skip.

### 5. The cans spawn themselves
You don't place anything. On entering `Task_ShootCans` / `Task_Grenade` the subsystem calls `EnsurePracticeRange()`: if the level contains no `ATutorialRangeActor` it spawns one **`PracticeRangeDistanceCm` (850 cm) in front of the player**, ground-traced, facing him, with `CansToShoot` cans and the barrel, and sets it as the task focus. A hand-placed range still wins — the auto-spawn is skipped if one exists.

### 6. You can see where the cursor is
The tutorial draws its own cursor whenever a card is up: a gold arrow with a black outline plus a pulsing ring, so it is findable against the desert. Buttons still accept Space/Enter.

### 7. You can see where the task is
While a hands-on step runs, the overlay draws a pulsing gold diamond with a **distance in metres** on `CurrentTaskWorldFocus` (the cans / the barrel), and an edge chevron pointing the way when it is off-screen.

### 8. Tidy-up
The checklist showed "درخواست آتش توپخانه" twice; the UI beat is now "نشانگر پشتیبانی آتش" / "Fire-support indicator".

### Test
Delete `SquadAISettings_Profile` to re-arm the tutorial, play from the main menu: you should see the real HUD behind every card, a visible cursor, enemies ignoring you, and the cans appearing ~8.5 m ahead when the shooting step starts.

---

## Batch 7 — `S18-TUT3`: tutorial quality pass

- **Key chips.** Every beat now carries `KeyHintFa/En`, drawn as a chip under the card: `W A S D + Shift`, `Right mouse = aim / Left mouse = fire`, `G = throw grenade`, `Middle mouse = call for fire`, `Space = continue`. No more guessing which button the lesson means.
- **Hit feedback.** Each counted success flashes a big green **`2 / 3`** at a third of screen height, fading over 1.2 s (`GetProgressPopAlpha()`), so a hit on a can is unmistakable.
- **Skip from anywhere.** A "رد کردن آموزش / Skip training" button sits bottom-right on every beat — previously you could only skip on the first prompt.
- **Replay from the pause menu.** New sixth button "اجرای دوبارهٔ آموزش / Replay training" → `RestartTutorial()`: clears the saved flags, resets state and starts the flow again **without restarting the level**. Pause card grew to 518 px to fit.
- **Console commands.** `SquadAI.Tutorial.Reset` (wipe flags + replay) and `SquadAI.Tutorial.Skip` (end it now) — handy while iterating instead of deleting the settings save.

Localisation keys added: `PauseMenu / BtnTutorial`.

---

## Batch 8 — look pass, guide soldier, tutorial audio

### A. `S18-LOOK` — `ASquadAICinematicLookActor` (the COD/BF image)
New files: `{Public,Private}/Environment/SquadAICinematicLookActor.*`. Drop **one** in the level; press **Apply Look** in the details panel (or let `bApplyOnBeginPlay` run it). It finds the existing sun / sky light / height fog / post volume — spawning fog and an unbound post volume if the level has none — and grades them. `Restore Original Look` puts the sun and fog back.

Presets: **Golden hour** (default), Harsh noon, Dust storm, Cold dawn, Custom.

What it actually changes, and why, against your screenshot:
- **Sun**: pitch 14°, 7.5 lux, 4700 K, yaw 115° — your shadows were short and neutral-white; this gives the long warm raking light that reads as Khuzestan afternoon. `LightSourceAngle 0.75°` softens the shadow edge (razor-sharp shadows are the biggest "this is UE default" tell), `ContactShadowLength 0.035` pins props to the ground, 4 cascades to 200 m with exponent 2.6.
- **Sky light**: 1.15 intensity, warm sand-bounce tint, real-time capture so it follows the sun. Your shadow sides were flat and blue-grey; this is the bounce that was missing.
- **Fog**: density 0.012, falloff 0.09, warm inscattering with a strong directional sun halo (exponent 12, start 1200 cm), start distance 350 cm so it never touches the player's hands, **volumetric fog on** with extinction 0.55 and forward scattering 0.35 → god rays and real distance separation. Your ridge line sat at the same contrast as the foreground; this is the fix.
- **Post**: histogram auto-exposure clamped 0.35–2.4 with −0.25 bias (no more blown sky), bloom 0.55 at threshold 0.9, vignette 0.42, film grain 0.12, chromatic 0.18, saturation 0.94, warm highlight gain + slightly cool shadow offset, contrast 1.06, AO 0.62 @ 120 cm, indirect lighting 1.25, subtle motion blur (0.22), **lens flare forced off** (reads as asset-store).

Every value is an exposed UPROPERTY — tune it live in the editor, the actor is not a black box.

### B. `S18-TUTGUIDE` — `ATutorialGuideActor`
New files: `{Public,Private}/Tutorial/TutorialGuideActor.*`. Place one (no Blueprint needed). If `GuidePawn` is empty he **adopts the nearest friendly `ASoldierCharacter`** to the player — normally your leader.

- Subscribes to `OnTutorialStepChanged` and **speaks a line per step**, Farsi + English, with optional VO per line (`Lines` map, keyed by step). Every step has a built-in fallback line so he is never mute: *"نگاه کن، اینطوری. حالا تو بزن."* / *"Watch — like this. Now you do it."*
- **Physical demonstration** (`bPhysicalDemonstration`): he turns to face the prop, waits `DemoWindUpSeconds` (2 s), then for the shooting step **knocks one can down himself** — deliberately *not* counted, so you still shoot your own three — and for the grenade step draws the throw arc into the barrel. `DemoShotSound` plays the cue.
- HUD draws a **cinematic subtitle band** (speaker name + line, gold edge, fade in/out) plus a small chevron over the speaker so you know who is talking.

### C. `S18-TUTAUDIO` — feedback sounds
Five sound slots on the tutorial subsystem, all optional (null = silence, nothing breaks): `CardOpenSound`, `CardConfirmSound`, `ProgressSound` (per can/barrel/fire mission), `StepCompleteSound`, `TutorialCompleteSound`. Assign them on the subsystem defaults or from Blueprint.

### Setup checklist
1. Place `ASquadAICinematicLookActor` → choose a preset → **Apply Look**.
2. Place `ATutorialGuideActor` (optionally set `GuidePawn` to your leader and fill `Lines` with VO).
3. The practice range still spawns itself; nothing else to place.

---

## Batch 9 — `S18-TUT4`: reference pass against COD / Battlefield

I pulled real references (COD MW HUD captures, GameUIDatabase sheets) and the published design consensus on AAA onboarding. The three rules those games follow that we were breaking:

1. **A shooter never stops the game to teach a physical action.** It teaches while you play. We were freezing (or slowing) the world for every beat.
2. **Instructions are one short imperative line with a keycap glyph** — not a paragraph in a bordered card.
3. **Objective state lives at the top as an all-caps line with a counter**, and the target lives in the world as a waypoint. The player's eyes never leave the centre of the screen.

### What changed
**New `bCinematicPromptMode` (default ON).** Hands-on steps now:
- **never slow time, never veil, never lock movement, never need an acknowledge** — you just play;
- get an **all-caps objective line** top-centre with a live counter (`شلیک به قوطی‌ها 1 / 3`) plus **segment pips** that fill green as you score;
- get a **compact bottom banner** (720 px, translucent, gold top rule) with the short instruction and **real keycap glyphs** — `W A S D SHIFT`, `RMB LMB`, `G`, `MMB` — drawn as physical caps with shadow, edge and top highlight, width fitted to the label (`DrawKeycap`);
- keep the gold world waypoint with metre distance from batch 6.

**Escalating help.** `ShouldEscalateHint()` — after `HintEscalationSeconds` (12 s) with no progress, a pulsing amber line appears with the *how*: "Hold the right mouse button to aim down the sights, then click to fire." Experienced players never see it; stuck players get it without being nagged from frame one.

**The five UI lessons keep the card**, because they genuinely point at the HUD — but they now also draw an **elbow leader line** from the highlighted panel to the card with node dots at both ends, the standard AAA callout. The training checklist is now shown only during those lessons, not over live gameplay.

**Legacy mode** is one bool away: set `bCinematicPromptMode = false` for the old card-and-freeze behaviour.

### Net effect against the two screenshots you sent
- No blue screen, no modal card mid-fight, no "movement locked" nag.
- The picture-in-picture plate no longer sits over the middle of the view during tasks.
- Progress is visible at a glance (counter + pips + green pop), the way COD shows `0/3`.

---

## Batch 10 — `S18-PROMPT` / `S18-INTRO` / `S18-POLISH`

### (a) One prompt language across the whole HUD — `S18-PROMPT`
New shared `AQuestNativeHUD::DrawWorldPrompt(ScreenPos, Key, Text, Font, Alpha, HoldPct, bActive, SubText)` plus `StripKeyTokens()`. Every world prompt now uses the tutorial's visual grammar — soft translucent plate, gold left rule, top highlight, **real keycap glyph**, optional hold bar:
- **Ammo crate** — keycap `E`, dimmed to 55 % out of range.
- **Revive** — `E` with a live **hold-progress bar** across the plate bottom and a "Bandaging…" sub-line; the bleed-out bar stays.
- **First-aid pickup**, **medical station**, **mounted MG** — same treatment.
`StripKeyTokens()` removes the baked-in `[E]` / `[Hold E]` from the old localised strings, so **your `SquadAILocalization.ini` needs no edits** — the key is drawn, not spelled.

### (b) Scripted first-mission intro — `S18-INTRO`
New `{Public,Private}/Tutorial/TutorialIntroSequence.*`. Place one actor; it drives a timed walk instead of disconnected lessons.
- Beat types: **Walk there and speak**, **Wait for the player**, **Just speak**, **Hand off to the tutorial**. Each has a point actor, Farsi + English line, optional VO, radius, dwell and a **timeout safety valve** (35 s) so a blocked navmesh can never strand you.
- **Zero authoring required**: with an empty `Beats` array it builds a five-beat trench walk — *"You made it. Take your rifle and stay behind me."* → *"Walk the boards, not the mud."* → waits for you → *"Wire starts from here."* → *"Now let's see what you know. I've set a few cans out for you."* → hands over to the normal tutorial.
- The guide **waits when you lag** (`PlayerLagDistance` 900 cm) and is pushed to a believable `LeadWalkSpeed` (240 cm/s). Movement uses real navigation (`AAIController::MoveToLocation`), with a straight-line fallback if the guide pawn has no controller.
- While the intro runs the tutorial overlay **stands aside** — only the guide's subtitle band and a top objective line, `FOLLOW THE MAJOR` / `به دنبال سرگرد`.

### (c) Graphical polish — `S18-POLISH`
- **Eased reveal**: the prompt banner slides up 14 px and fades in with a cubic-out curve over 0.35 s on every beat change, and its gold rule **wipes open from the centre**. Static UI is what makes a HUD look cheap.
- **Bottom scrim**: a 10-band soft gradient behind the banner so white text stays legible over bright sand without greying the frame.
- **Live keycaps**: a cap visibly **depresses and glows while you actually hold that key** (LMB/RMB/MMB/Shift/Space/letters) — immediate confirmation the game is reading your input.
- **Depth-aware waypoint**: the task marker line-traces against the camera; when occluded it dims to 45 % and shrinks, when visible it gets a breathing outer ring. Depth now reads correctly instead of markers floating through terrain.

### Placement summary (whole system)
`ASquadAICinematicLookActor` (press Apply Look) · `ATutorialGuideActor` · `ATutorialIntroSequence` · practice range spawns itself.

---

## Batch 11 — `S18-PERF` / `S18-FIX`: audit pass (bugs + performance)

### Real bugs found and fixed
1. **The intro's subtitles were invisible.** `DrawTutorialOverlay` early-returned whenever the tutorial subsystem was inactive — but the scripted intro runs *before* the tutorial starts. The guide would speak his whole opening with nothing on screen. The subtitle band is now its own `DrawGuideSubtitle()` function, drawn in both paths, and the overlay keeps running for the intro layer.
2. **Guide path stutter.** The intro re-issued `MoveToLocation` every tick (20 Hz), cancelling and rebuilding the path each time — the guide would shuffle. Now issued once per destination and refreshed only every 2 s, reset on each beat.
3. **Veterans got walked down the trench again.** The intro only checked the live step enum; it now reads the same saved `bTutorialCompleted` / `bTutorialSkipped` flags the tutorial gates on.
4. **Physics demo on a static mesh.** The guide's "watch me" can-knock called `SetSimulatePhysics` without checking mobility — a warning and nothing visible. Now gated on `Mobility == Movable`.
5. **`PlayerCameraManager` null-deref risk** on the waypoint occlusion trace in the first frames after possession — guarded.
6. **Invalid `FKey` from arbitrary strings** in the keycap press check — now only built for real A–Z letters.

### Performance
- **7 full-level actor sweeps every frame, gone.** `DrawBattlefieldInteractionPrompts` ran a `TActorIterator` over every actor in the map for crates, kits, stations, turrets, barrels — plus two more for the guide and intro — **each frame**. New `GetCachedActorsOfClass()` keeps a weak-pointer list per class, rescanned at most once a second with a jittered refresh so two caches never rebuild on the same frame. On a dressed Khuzestan map this is the single biggest HUD win.
- **Grenade barrel polling** walked every actor in the level 5×/s and string-compared each class name. Replaced with a **sphere overlap against the physics broadphase** — cost is now proportional to what is actually near the barrel.
- **Waypoint occlusion trace** throttled from per-frame to 10 Hz and cached. Invisible to the eye, free in the profile.
- **Idle actors stop ticking.** The guide disables his own tick when no line and no demonstration is pending (re-armed by `Speak` / step change / demonstration); the intro sequence starts with tick disabled and only ticks while actually running.

No behaviour was changed by the performance work — identical visuals, less CPU.

---

## Batch 12 — `S18-TITLE` / `S18-FEEL` / `S18-FIX2`

### `S18-TITLE` — the mission-opening location stamp
Every COD mission opens on a place/date/unit stamp. Added `DrawLocationTitleCard()`:

> **دهلاویه — خوزستان**
> فروردین ۱۳۶۱ — عملیات فتح‌المبین
> گردان تکاور — خط مقدم

Lower-left, typed in over **live gameplay** — no letterbox, no pause, **no black frame** (per your standing rule). A gold rule wipes open under the place name, the three lines fade and slide in staggered (0 / 0.45 / 0.75 s), hold, then fade after 5.2 s. Shown once per level. All six strings and `bShowTitleCard` are editable on the HUD class, English and Farsi separately — change the operation name per mission without touching code.

### `S18-FEEL` — HUD entrance
The squad panel and the objective card now **slide in from off-screen** over 0.55 s, staggered by 0.12 s, with a cubic-out ease, instead of popping into existence on frame one. Position-only — the panels' own drawing code is untouched.

### `S18-FIX2` — conflicts and teardown
- **The hint reel no longer fights the tutorial.** `DrawOnboardingHints` and the tutorial were teaching the same four things at once, stacked over each other at the bottom of the screen. The reel is now suppressed while the tutorial or the scripted intro is running, and its **clock is pushed forward** while hidden — so no hint is silently consumed; the reel resumes from where it was once training ends.
- **Intro `EndPlay`** clears its start timer and drops `bRunning`, so seamless travel can't leave a handle live.

### Audit notes (checked, no change needed)
- `SoldierAIController`'s level scans are one-shot caches behind `CachedFallbackQuestZone` / `CurrentMission`, not per-tick — left alone.
- Hit markers, directional damage indicators, low-health / fire / suppression vignettes and the dynamic reticle **already exist and are good**; per your rule I did not rebuild any of them.
- Actor-owned timers in the grenade/barrel/mortar actors auto-clear on destruction — no leak.

---

## Batch 13 — `S18-FEED`, per-mission title cards, compile-proofing

### `S18-FEED` — combat event ticker
A proper feed in the top-right, under the compass, in the same visual language as everything else: translucent plate, coloured left rule, vector glyph, slide-in from the right, fade after `FeedEntryLifetime` (6 s), **max 5 lines** so a firefight can't flood the corner.

| Kind | Colour | Glyph | Fires on |
|---|---|---|---|
| Kill | red | ✕ | confirmed kill (`NotifyHitConfirmed(true)`) |
| Ally | amber | ✚ | squadmate downed — *"سرگرد رستمی مجروح شد"* |
| Objective | cyan | ◆ | mission alert, success style |
| Supply | green | ✚ | mission alert, info style |
| Warning | yellow | ❗ | mission alert, danger style |

It hooks the events that **already existed** — hit confirm, ally-downed, mission alerts — so nothing was duplicated or rebuilt. The centre-screen alert banner stays as-is; the feed just keeps a short record of what happened after the banner is gone.

### Per-mission title cards
`AMissionZone` gained `TitleCardPlace` / `TitleCardDate` / `TitleCardUnit` (FText, category **Mission|Title Card**). The stamp prefers the active mission's text and falls back to the HUD defaults for any field left empty — so each mission can open on its own place and date with no code change.

### Compile-proofing (I can't build here, so I hardened what I can)
- Dropped `UEnum::GetValueAsString` from the intro log (needs reflection headers that may not be pulled in) — plain `int32` cast instead.
- Added the includes the new code actually needs: `SaveSystem/SquadAISaveGame.h` (for `FSquadGameSettingsSaveData`), `Components/SceneComponent.h`, `CollisionQueryParams.h`, `Engine/OverlapResult.h` (`FOverlapResult` moved there in UE5), `Templates/SubclassOf.h`.
- Verified against the real headers: `USquadAISaveLoadSubsystem::Get` / `GetCachedSettings`, `USquadAITutorialSubsystem::Get`, `AQuestChain::GetCurrentMission`, `ATutorialGuideActor::Speak`, and that `AIModule` + `NavigationSystem` are already in `SquadAI.Build.cs` (needed by the intro's `MoveToLocation`).
- Checked every new/edited file balances braces and that every top-level function in `QuestNativeHUD.cpp` starts at depth 0 — the usual symptom of a bad programmatic edit.
- `BlueprintReadWrite` properties confirmed to sit in a **public** section (UHT rejects them otherwise).

---

## Batch 14 — `S18-LOC` (localisation) + `S18-SETUP` (one-click level setup)

### `S18-LOC` — nothing new is hardcoded any more
Every string I added in the last three batches now goes through the same localisation path as the rest of the HUD, so your **external `SquadAILocalization.ini`** owns them — Arabic included — with no C++ edit:

| Section | Key | Default (FA) |
|---|---|---|
| `TitleCard` | `Place` | دهلاویه — خوزستان |
| `TitleCard` | `Date` | فروردین ۱۳۶۱ — عملیات فتح‌المبین |
| `TitleCard` | `Unit` | گردان تکاور — خط مقدم |
| `Feed` | `EnemyKilled` | دشمن از پا درآمد |
| `Feed` | `AllyDownFmt` | `%s` مجروح شد |
| `Tutorial` | `HelpShoot` | برای نشانه‌روی کلیک راست را نگه دار… |

`AllyDownFmt` is substituted **by hand**, not through `Printf` — a runtime format string from an INI file is a crash waiting to happen, and if the `%s` is missing the name is simply prepended. The intro's objective banner is editable per-actor instead (`ObjectiveFollowFa/En`, `ObjectiveListenFa/En`) since that actor has no localisation dependency.

### `S18-SETUP` — `scripts/SETUP_TUTORIAL_AND_LOOK.py`
You said placing actors by hand is the part you hate. This does it:

1. Spawns `ASquadAICinematicLookActor` and **presses Apply Look** (golden hour — it also creates the fog and post-process volumes if the map has none).
2. Spawns `ATutorialGuideActor` near the player start.
3. Spawns `ATutorialIntroSequence`, **links it to the guide**, auto-start on, 2 s delay — empty beat list, so it runs the built-in five-beat trench walk.
4. Prints a sanity report: directional light, sky light, fog, post-process volume, player start — anything missing is logged as a warning.

**Idempotent**: run it twice and it reuses what already exists instead of duplicating. **Self-locating** — no paths to edit, as per your rule. If the C++ isn't compiled yet it says so plainly instead of dying halfway.

Usage: open the map, Output Log → Cmd → **Python**:
```
exec(open(r"C:\dumps\SETUP_TUTORIAL_AND_LOOK.py").read())
```
then save the level.

---

## Batch 15 — `S18-INTRO2`: persistence + mission-triggered walks

### The opening no longer repeats
Three separate "play it once" problems, all fixed:

1. **Per-level memory.** `FSquadGameSettingsSaveData` gained `TArray<FString> PlayedIntroLevels`. When an intro finishes it writes `MapName::ActorName` into the **settings profile** (not a game slot, so it survives new games and slot deletion) and never plays again. The key includes the actor name, so two intro actors in one level are tracked separately.
2. **Reloading a mid-mission save** no longer replays the walk — same list.
3. **Nor the title card.** The save subsystem now sets a transient `bEnteredLevelFromLoad` when `LoadGame` runs; the HUD **consumes it once** via `ConsumeEnteredLevelFromLoad()` and swallows the opening stamp. Starting the mission fresh still stamps; loading into the middle of it does not. (The subsystem is a game-instance subsystem, so the flag survives the map travel.)

New knobs on `ATutorialIntroSequence`:
- `bPlayOncePerLevel` (default on) — the persistence above.
- `bOnlyBeforeTutorial` (default on) — **turn this OFF** for a later mission's walk, which should play even for a trained player.

### Mission-triggered walks — later missions open like the first one
`TriggerMission` (an `AMissionZone`). Leave it empty for the opening walk at level start; set it and the actor **waits, binds to `OnMissionStateChanged`, and starts its beats the moment that zone goes `Active`**. So mission 3 can have Rostami lead you to the next trench line with its own lines, its own waypoints and its own once-only memory, with zero new code — place a second `ATutorialIntroSequence`, point it at the zone, untick `bOnlyBeforeTutorial`, write the beats.

### Compile notes
`Quest/MissionZone.h` is included in the intro **header** rather than forward-declared: UHT needs the full `AMissionZone` + `EMissionZoneState` to generate the bound `UFUNCTION`, and a forward-declared scoped enum fails there.

---

## Batch 16 — `S18-INTRO3` / `S18-VOX`: nobody talks over anybody

### Briefing → walk, in order
`AQuestNativeHUD::IsReaderCardOpen()` (new, Blueprint-pure) reports whether a fallen-note or S17-STORY **mission-briefing card** is on screen. `ATutorialIntroSequence` gained `bWaitForBriefingCard` (default on): if a briefing is up when the walk is due, it **re-checks twice a second and starts the moment the card closes**. So a mission now plays as one chain — briefing card → the major's walk → the objective — instead of two voices fighting for the screen.

### `S18-VOX` — the guide no longer interrupts himself
- **Line queue.** `Speak()` used to overwrite whatever was on screen; call it twice quickly (step change + demonstration) and the first line vanished mid-sentence. Lines now **queue** (max 6) and play in order; `IsSpeaking()` exposes the state.
- **Optional audio ducking.** Set `DuckingMix` + `DuckingClass` on the guide and gunfire/ambience drop to `DuckedVolume` (0.35) over `DuckFadeSeconds` (0.35 s) while he talks, then come back up — the scripted-mission treatment. **Both fields empty = nothing happens**, so no asset is required and nothing breaks if you never set them.
- **Never leaves the world ducked**: the duck lifts when the queue drains, and `EndPlay` forces it off.
- The guide's tick stays awake while speaking or ducked, and sleeps again afterwards (the `S18-PERF` rule from batch 11 still holds).

### Verification run on the whole module
- Brace balance on every edited file, and every top-level function in `QuestNativeHUD.cpp` still opens at depth 0.
- Swept all public headers for `BlueprintReadWrite` in non-public sections. Every hit was inside a `USTRUCT` (where `struct` members are public by default) — **no real violations**.
